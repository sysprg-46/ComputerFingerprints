<#
-------------------------------------------------------------------- 
 Project: GetBuildsHistory, part GBHUtils                                               
 Version: 1.0                                                        
 FileId:  e:\Delme\!Projects\BuildsHistory\GBHUtils.ps1                    
 When:    13 Dec 2016,  Tuesday,  09:53:54                           
 ©        Oleg Kulikov, sysprg@live.ru                               
-------------------------------------------------------------------- 
 Collection of the GetBuildsHistory project functions.                                                           
--------------------------------------------------------------------
Tuesday, December 13, 2016. Have improved Details presentation:
dates now are vertically aligned. textlog
--------------------------------------------------------------------
#>
<#
----------------------------------------------------------
function use $AllProperties array of the properties names
to access objects of the input array
----------------------------------------------------------
#>
function CountFieldsWidth( $arr )
{
   $ret = @{};
   $PropL = 1;
   for ( $j = 0; $j -lt $AllProperties.Length; $j++ )
   {
      $p = $AllProperties[$j];
      if ( $p.Length -gt $PropL ){$PropL=$p.Length;}
      $ret.$p = $ColNames[$j].Length;
   }
   for ( $j = 0; $j -lt $AllProperties.Length; $j++ )
   {
      $p = $AllProperties[$j];
      for ( $i = 0; $i -lt $arr.Length; $i++ )
      {
         $o = $arr[$i];
         if ( $o.$p )
         {
            $l = ([string]$o.$p).Length;
            if ( $l -gt $ret.$p ){ $ret.$p = $l; } 
         }
      }
   }

   $w = [string[]]@();
   <#
   7.7 * 9 == 69.3
   [Math]::Truncate( 7.7 * 9 ) => 69
   [Math]::Round( 7.7 * 9 )    => 69
   [Math]::Ceiling( 7.7 * 9 )  => 70
   #>

   for ( $j = 0; $j -lt $AllProperties.Length; $j++ )
   {
      $key = $AllProperties[$j];
      $v = [string]$ret.$key;
      if ( $v.Length -lt 2 ) {$v="0$v";}
      $v1 = $ColNames[$j];
      $v2 = $ClassNames[$j];
      $v3 = [Math]::Ceiling( 7.7 * ( 2 + [int]$v ) + 2 );# width in pixels for Consolas
      $w += "$v,$key,$v1,$v2";
###Write-Host "$v,$key,$v1,$v2,$v3";
   }

   $w = ( $w | Sort-Object );
   $r = [Ordered]@{};
   for ( $i = 0; $i -lt $w.Length; $i++ )
   {
      $t = $w[$i] -split ",";
      $l = $t[0];
      $k = $t[1];
      $c = $t[2];
      $d = $t[3];
      $r.$k = @{MaxL=[int]$l;ColName="$c";ClassName="$d"};
   }
   $r.MaxPNameL = $PropL;
   return $r;
}
function Init( $arr )
{
   # Consolas character width for font-size: 14px is equal to 7.70px;
   # It gives an opportunity to count and assign width of the columns
   # which content have nearly the same width for all of the data.
   function Names2Styles( $str )
   {
      $list = $str -split ",";
      for ( $i = 0; $i -lt $list.Length; $i++ )
      {
         $p = $list[ $i ];
         $list[ $i ] = "." + $NamesObj.$p.ClassName;
      }
      return ($list -join ",");
   }
   $p1 = ""+`
   "CurrentBuild,InstallDateString,UpgradeDateString,Minutes,Description,BuildBranch,"+`
   "ProductName,ProductId,ProductId4,ProductId2,BuildLabEx,ProductId3,ProductId5,"+`
   "SkuId,ApplicationID,DefaultProductKey,ProductKey,EditionID,"+`
   "CurrentVersion,ReleaseId,UBR,InstallDate,InstallTime,UpgradeDate,"+`
   "Secret1,Secret2,Secret3,Secret4,PSParentPath,PSChildName,Channel";
   
   $r1 = [Ordered]@{
      "CurrentBuild"="Build";"InstallDateString"="Date1";"UpgradeDateString"="Date2";
      "BuildBranch"="Branch";"ProductName"="Name";"CurrentVersion"="Version";"Minutes"="mmss";
      "ReleaseId"="RelId";
   }
   $p2 = $p1;
   foreach ( $key in $r1.Keys ){$p2=$p2.Replace($key,$r1.$key);}

   $r2 = [Ordered]@{
      "CurrentBuild"="Build";"InstallDateString"="Install Date";"UpgradeDateString"="Upgrade Date";
      "BuildBranch"="Branch";"ProductName"="Product Name";"CurrentVersion"="Ver.";"ReleaseId"="RelId";
   }
   $p3 = $p1;
   foreach ( $key in $r2.Keys ){$p3=$p3.Replace($key,$r2.$key);}

   [string[]]$p1 = $p1 -split ",";  # 31 after Channel added
   [string[]]$p2 = $p2 -split ",";
   [string[]]$p3 = $p3 -split ",";
   
   Set-Variable -Name AllProperties -Scope Script  -Value $p1;
   Set-Variable -Name ClassNames -Scope Script  -Value $p2;
   Set-Variable -Name ColNames -Scope Script  -Value $p3;
   
   [PSobject]$obj = CountFieldsWidth( $arr );
   Set-Variable -Name NamesObj -Scope Script -Value $obj;

   $jso  = [string[]]@("var NamesObj = {};"); 
   
   for ( $i = 0; $i -lt $ColNames.Length; $i++ )
   {
      $c = $ColNames[$i];
      $p = $AllProperties[$i];
      $l = $NamesObj.$p.MaxL;
      if ( $i -eq 0 )
      {
         $jso += "NamesObj.Column0Name=""$c"";";
      }
      $jso += "NamesObj[""$c""]=$l;";
   }   
   Set-Variable -Name JSNamesObj -Scope Script  -Value $jso; 
   
   ### Common global for ALL views, contains all fields names
   # $NarrowScreen is set by Global:GetCompInfo function
   # which is called before building even header style and thus
   # can use $NarrowScreen value. 
   Set-Variable -Name CurrentView -Scope Script -Value "V1";

   if ( $NarrowScreen -or $UseNarrow ) 
   {
      $l1 = "InstallDateString,UpgradeDateString,ProductName,BuildBranch,UBR,ReleaseId,Minutes";
      $l2 = "ProductId2,ProductId,ProductId3";
      $l3 = "Secret1,Secret2,Secret3";
   }
   else
   {
      $l1 = "InstallDateString,UpgradeDateString,ProductName,"+`
      "ProductId2,ProductId,BuildBranch,UBR,ReleaseId,Minutes";
      $l2 = "CurrentVersion,EditionId,BuildlabEx,ProductId3";
      $l3 = "Secret1,Secret2,Secret3,Secret4";
   }
   $l4 = "CurrentBuild,$l1,$l2,$l3" -split ",";
   
   Set-Variable -Name View2List  -Scope Script -Value $l2;

   Set-Variable -Name V1RowProps -Scope Script -Value $l4;

   $NamesObj.List1 = Names2Styles( $l1 );
   $NamesObj.List2 = Names2Styles( $l2 );
   $NamesObj.List3 = Names2Styles( $l3 );
   $NamesObj.List4 = "$l4";
}
function Global:TagIdFromObjDate( $o )
{
   $v   = $CurrentView;
   $i   = "{0:D3}{1:X0}" -f $o.Index, [int]$o.CurrentBuild;  
   return "$v$i"; # "VnIIIBBBB" Build# is necessary for Details Window Title 
}
function Global:FormatNumber( [int64]$num )
{
   if ( $num -lt 13071694150 )
   {
      return ("{0,-19} (0x{0:X0})" -f $num);
   }      
   return ("{0,-19} (0x0{0:X0})" -f $num);
} 
function GetBuildTimeZone( $obj )
{
   $build = $obj.CurrentBuild;
   for ( $i = 0; $i -lt $TimeZoneDefs.Length )
   {
      $def = ($TimeZoneDefs[ $i ]) -split "=";
      if ( $def[0] -eq $build ){return $def[1];}
      elseif( $def[0].IndexOf( "-" ) -eq -1 ) {return "";}
      $lr = $def[0] -split "-";
      if ( [int]$lr[0] -gt [int]$build ){return "";}
      if ( [int]$lr[1] -lt [int]$build ){return "";}
      return $def[1];      
   }
}
function DateStringToSeconds( $obj ) 
{
   $utc   = $obj.PSChildName.Replace( "Source OS (Updated on ", "" ).Replace( ")", "" );
   $tz    = GetBuildTimeZone(  $obj );
   $dt    = [datetime]( "$utc" );
   $epoch = ( Get-Date -Year 1970 -Month 1 -Day 1 -Hour 0 -Minute 0 -Second 0 );### CONST
   $dt | % { $Seconds = [math]::truncate( $_.ToUniversalTime().Subtract( $epoch ).TotalSeconds ) };
   if ( $tz -ne "" )
   {
      $s1 = [int]$CurrentTIMEZONESeconds;
      $s2 = [int]$tz;
      $Seconds += ( $s1 - $s2 );
   }
   return $Seconds;
}
<#
---------------------------------------------------------------------------------
This function is called from GetBuildsHistory.js main code to build Black theme
CSS code. All other themes are built by JS code on base of the Black theme CSS
replacing 4 colors used in Black theme css.
---------------------------------------------------------------------------------
#>
function buildCSS( $colors )
{
   $brdr  = "#999";#"#e5e5e5";
   $dark  = $colors[0];# is used as text color, dark background 
   $light = $colors[1];# is used as text color on dark and background for rows
   $body  = $colors[2];# less intensive then light
   $hover = $colors[3];# intermediate between light and dark

   $css = @(
".theme{color:#ffffff; background-color:$dark;}"
"a{background-color:transparent; -webkit-text-decoration-skip:objects; color:$light; }"
".menubtn_content{color:$dark;border:2px solid $brdr; border-top:none; background-color:$light;}"
".white,.menu-a:hover{color:$dark; background-color:#ffffff;}"
".menudata:hover{background:$hover;color:#ffffff;}"
"body,#V1expandtable,#V1tablecontainer{background-color:$body;}"  
"#V1tablecontainer{background: $light;}"
"#V1expandable{color:$dark;}"
".rowcell,.hdrcell {float:left; border:1px solid $brdr; box-sizing:border-box; border-bottom:none;}"
".rowcell:hover{background:$hover; color:#ffffff;}"
"#V1footBar{border:1px solid $brdr; box-sizing: border-box; border-bottom:2px solid $brdr;}"
".hdrcell{background:$dark;color:$light;}" 
"#menubtn_*:hover{color:$light;}"
"#menubtn_edit,#menubtn_edit a,#menubtn_edit:hover{color:gray; background-color:$dark; cursor:default;}"
   );
   $css = $css -join "";
   return CodeToString( $css );
}
<#
------------------------------------------------------------------------------
Function builds objects for converting long properties name to short ones in PS
and in JS. PS converter is $l2s and is used when building hidden divs to save 
some space. JS convers is used when building Details page html code.
------------------------------------------------------------------------------
#>
function PSArrToJSArr( $arr )
{
   function buildDiv( $obj )
   {
      $p   = $AllProperties;
      $tds = "";
      for ( $i = 0; $i -lt $p.Length; $i++ )
      {
         $q    = $p[$i];
         $v    = $obj.$q;
         if ( "$q" -eq "Description" )
         {
            $v = "%c4;";
         }

         if ( $v -ne $null )
         {
            if ( "InstallDate,InstallTime,UpgradeDate".IndexOf( $q ) -gt -1 )
            {
               $v = FormatNumber( $v );
            }
            elseif ( $q -eq "BuildLabEx" )
            {
               $l = "55041-03308-000-000000-00-1033-15007.0000-0132017".Length;
               $t = $v -split " ",2;
               $v = ( "{0,-$l}" -f $t[0] ) + " " + $t[1].trim(); 
            }
            if ( $v -is [string] )
            {
               $v = $v.trim();
               $v = $v.Replace( " ", "&n;" );
               if ( $v.IndexOf( "\" ) -gt -1 ){$v=$v.Replace( "\", "\\" );}
            }
            $q = $l2s.$q;
            $tds += "%c1;$q%c2;$v%c3;";
         }
         else
         {
            $q = $l2s.$q;
            $tds += "%c1;$q%c2;%c3;";
         }
      }
      return "%c5;$tds%c6;";
   }
   $Props = $AllProperties;
   [psobject]$tl2s = "" | Select $Props; 
   $jsn = @();
   $chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
   for ( $i = 0; $i -lt $Props.Length; $i++ )
   {
      $n = $Props[$i];
      $c = $chars[$i];
      $tl2s.$n = "%$c;";
      $jsn += "replace( /%$c;/m,""$n"")"; 
   }

   Set-Variable -Name l2s -Scope Script -Value $tl2s;

   $c1 = "<tr><td>&nbsp;";                     # "%c1%"
   $c2 = "&nbsp;</td><td class='KB'>&nbsp;";   # "%c2%"
   $c3 = "&nbsp;</td></tr>";                   # "%c3%"
   $c4 = "Microsoft&#174;&nbsp;Windows&#174;&nbsp;Operating&nbsp;System&nbsp;";# "%c4%"
   $c5 = "<div class='h hc'><table><tbody>";   # "%c5%"
   $c6 = "</tbody></table></div>";             # "%c6%" 
   $c7 = "00330-80000-00000-";   
   $jsn += "replace( /&n;/gm,""&nbsp;"")";
   $jsn += "replace( /%c1;/gm,""$c1"")";
   $jsn += "replace( /%c2;/gm,""$c2"")";
   $jsn += "replace( /%c3;/gm,""$c3"")";
   $jsn += "replace( /%c4;/gm,""$c4"")";
   $jsn += "replace( /%c5;/gm,""$c5"")";
   $jsn += "replace( /%c6;/gm,""$c6"")";
   $jsn += "replace( /%c7;/gm,""$c7"")";

   $jst = "function s2l(obj){return obj."+( $jsn -join "." )+";}`n";
   $jst += "var DC=[];`n";
   
   for ( $i = 0; $i -lt $arr.Length; $i++ )
   {
      $o    = $arr[$i];
      $id   = "I"+( TagIdFromObjDate( $o ) ).Substring(2);
      $code = buildDiv( $o );
      $jst += "DC[DC.length]=""$code"";`n";
   }

   return $jst;
}
<#
------------------------------------------------------------------------------
Function receives an array of the Builds objects and return HTML-Body code 
which presents objects properties. Header part of the same HTML code is built
by the GetBuildsHistory and written to the disk.
------------------------------------------------------------------------------
#>
function BuldHTML( $arr )
{
   function BuildMainTable( $arr )
   {     
      function BuildTH( $obj )
      {   
         $tds        = "";
         $lang       = "en";
         $VC         = $CurrentView; 
         $c1         = "topBar"; 
         $c2         = "footBar"; 
         
         if ( $VC -eq "V1" )
         {
            $tooltip = "title=""%tooltip%""";
         }
         $RowOpenTag   = "<div class=""mr hdrcell"" id=""$VC$c1"" $tooltip>$NL";
         $CellCloseTag = $RowCloseTag =  "</div>$N";

         if ( $obj -eq $null )
         {
            $RowOpenTag = $RowOpenTag.Replace( "$VC$c1", "$VC$c2" );
         }
    
         $p = $V1RowProps;
         $tds = "";
         for ( $i = 0; $i -lt $p.Length; $i++ )
         {
            $CellOpenPattern = "<div class=""hdrcell %pn%"">";
            $q = $p[ $i ];
            $a = $NamesObj.$q.ClassName;
            $CellOpenTag = $CellOpenPattern.Replace( "%pn%", "$a" );
            if ( $obj -eq $null )
            {
               $cpy = "&copy;&nbsp;sysprg&`#64;live.ru`,&nbsp;liza.shakh&`#64;gmail`.com&nbsp;";
               $gen = "Created by GetBuildsHistory.ps1, $version&nbsp";
               $tds = "<table class=""copyr""><tbody><tr>"+`
               "<td style=""text-align:left;"">&nbsp;$cpy&nbsp;</td>"+`
               "<td style=""text-align:center;"">&nbsp;$gen&nbsp;</td>"+`
               "<td style=""text-align:right; font-weight: bold;"">"+`
               "&nbsp;&nbsp;$OSEdition&nbsp;&nbsp;</td>"+`
               "</tr></tbody></table>";                      
               break;
            }         
            elseif ( ($NarrowScreen -or $UseNarrow) -and $q -eq "Secret3" )
            {
               $v1 = "Secret3";
               $v2 = "Secret4";
               $v  = "<div style=""float:left;"" onclick=""switchUnknowns();"">&nbsp;$v1&nbsp;</div>"+`
               "<div style=""float:right;"" onclick=""switchUnknowns();"">&nbsp;$v2&nbsp;</div>";
            }             
            else
            {
               $v = $NamesObj.$q.ColName;
            }
            $x1 = "<!--EndOfHeader-->";
            if ( $i -eq 0 ){$x1 = "<!--EndOfFooter-->";}
            $tds += "$CellOpenTag&nbsp;$v&nbsp;$CellCloseTag";
         }
         return "$RowOpenTag$tds$RowCloseTag$x1$NL$BreakLine$NL";      
      }
      function BuildTD( $tobj )
      {
         $CellOpenPattern = "<div class=""rowcell %pn%"">";
         $CellCloseTag = "</div>$NL";
         $p = $tobj.PropName;
         $a = $NamesObj.$p.ClassName;
         $CellOpenTag = $CellOpenPattern.Replace( "%pn%", "$a" ); 
         $v = $tobj.Value.ToString().trim();
         if ( $a -and $a.Contains( "Date" ) )
         {
            if ( $v.Contains( "," ) )
            {
               $v  = $v -split ",";
               $v0 = ($v[0]).trim();
               $v1 = ($v[1]).trim();
               $v  = "$v1&nbsp;$v0";
            }
         }
         elseif ( $p -eq "ProductId3" -or $p -eq "BuildLabEx" )
         {
            $v = $v -replace( " ", "&nbsp;" );
            $v = "<span class=""fw"">$v</span>";
         }
         elseif ( $p -eq "Secret1" -or $p -eq "Secret2" )# Jan 25, 2017
         {
            $v = "<span class=""fw"">$v</span>";
         }            
         elseif ( ($NarrowScreen -or $UseNarrow) -and $p -eq "Secret3" )
         {
            $v1 = $v;
            $v2 = ($CurrentObj).Secret4; 
            $v  = "<div><span class=""fw"">&nbsp;$v1&nbsp;</span></div>"+`
            "<div><span class=""fw"">&nbsp;$v2&nbsp;</span></div>";
         }
         elseif ( !($NarrowScreen -or $UseNarrow) -and "Secret3,Secret4".indexOf( $p ) -gt -1 )
         {
            $v  = "<span class=""fw"">$v</span>";
         }      
         
         return "$CellOpenTag&nbsp;$v&nbsp;$CellCloseTag";
      }
      function BuildRow( $obj )
      { 
         Set-Variable -Name CurrentObj -Scope Script -Value $obj;
         $tds = "";
         $p   = $V1RowProps;
         for ( $i = 0; $i -lt $p.Length; $i++ )
         {
            $q    = $p[ $i ];
            $v    = $obj.$q;
            $tds += BuildTD( @{PropName="$q";Value="$v";} );
         }
         
         $id = TagIdFromObjDate( $obj );# rowcell
         return "<div class=""mr rowcell"" id=""$id"">$NL$tds</div><!--EndOfMR-->$NL";     
      }
      $V1th1  = BuildTH( $V1RowProps );   
      $V1rows = $arr | %{BuildRow( $_ )};
      $V1th2  = BuildTH( $null );
      $V1vid  = $CurrentView; 
      $c1 = "tablecontainer"; 
      $c2 = "expandable";
      $menuTop   = BuildMenuTop;
      $menuHidd  = BuildMenuHidden;
      
      return ""+`
      "<div id=""$V1vid$c1"">$menuTop$NL$menuHidd$NL$V1th1<div id=""$V1vid$c2"">"+`
      "$NL$V1rows</div><!--V1Expandable-->$NL"+`
      "$V1th2</div><!--V1tablecontainer-->$NL";
  
   }# End-Of-BuildMainTable( $arr ), central function
   
   function BuildBottomTable
   {
      $sz = $FSZ + 1;
      $comp = "";
      for ( $i = 0; $i -lt $CompInfo.Length; $i++ )
      {
         $lr = $CompInfo[$i] -split ":";
         $l  = $lr[0].trim();
         $r  = $lr[1].trim();
         $comp += "<tr><td>&nbsp;$l&nbsp;</td><td>&nbsp;$r&nbsp;</td></tr>$NL";
      }
      $sz = $FSZ + 1;
      $lcell =  "<table id=""Computer"" style=""font-size:$sz$px;"">$NL$comp</table>";
      [string[]]$stamps = [string[]]$TimeStamps;
      $stamps += TimeStamp( "HTML creation is finished" );
      $stmp = "";
      for ( $i = 0; $i -lt $stamps.Length; $i++ )
      {
         $v = $stamps[$i] -Split "]";
         $stmp += "<tr><td>&nbsp;" + $v[0].Substring( 1 ) + "&nbsp;</td>" +`
                   "<td>&nbsp;" + $v[1] + "&nbsp;</td></tr>$NL"
      }
      $rcell = "<table id=""RunStamps"" style=""font-size:$sz$px;"">$stmp</table>"; 
      return "<table><tr><td>$lcell</td><td>$rcell</td></tr></table>";      
   }

   function BuildMenuTop()
   {
      $code = '
<ul class="menu theme wide" id="MenuContainer">
 <li class="menubtns">
  <a class="menu-a padded" id="menubtn_file" href="#">FILE&nbsp;
  <span class="caret">6</span></a>
 </li>
 <li class="menubtns">
  <a class="menu-a padded" id="menubtn_view" href="#">VIEW&nbsp;
   <span class="caret">6</span></a>
 </li>
 <li class="menubtns">
  <a class="menu-a padded" id="menubtn_theme" href="#">THEME&nbsp;
   <span class="caret">6</span></a>
 </li>
 <li class="menubtns">
  <a class="menu-a padded" id="menubtn_lang" href="#">LANGUAGE&nbsp;
   <span class="caret">6</span></a>
 </li>
 <li class="menubtns" id="IgnoreMe">
  <a class="menu-a padded disabled" id="menubtn_edit" href="#">EDIT&nbsp;
   <span class="caret">6</span></a>
 </li>
 <li class="right" id="About">
  <a class="menu-a padded right" title="%version%" href="#">
   <i>About</i></a>
 </li>
</ul>
<!--<br/>-->
';
      return $code.Replace( "%version%", "$Version" );
   }
   function BuildMenuHidden()
   {
      $ret = '
<div class="menubtn_content" id="menubtn_file_content">
 <div class="menudata">&nbsp;SAVE CURRENT SETTINGS&nbsp;</div> 
 <div class="menudata">&nbsp;SAVE VIEW AS TEXT FILE&nbsp;</div>
 <div class="menudata">&nbsp;EXIT&nbsp;</div>
</div>
<div class="menubtn_content" id="menubtn_view_content">
 <div class="menudata">&nbsp;Default&nbsp;</div>
 ';
 $ret += "<div class=""menudata"">&nbsp;Build,$View2List&nbsp;</div>";
 $ret += '

 <div class="menudata">&nbsp;Build,Secret1,Secret2,Secret3,Secret4&nbsp;</div>
</div>
<div class="menubtn_content" id="menubtn_theme_content">
 <div class="menudata" id="Black">&nbsp;BLACK&nbsp;</div>
 <div class="menudata" id="Green">&nbsp;GREEN&nbsp;</div>
 <div class="menudata" id="Blue">&nbsp;BLUE&nbsp;</div>
 <div class="menudata" id="Brown">&nbsp;BROWN&nbsp;</div>
 <div class="menudata" id="Orange">&nbsp;ORANGE&nbsp;</div>
 <div class="menudata" id="Pink">&nbsp;PINK&nbsp;</div>
</div>
<div class="menubtn_content" id="menubtn_lang_content">
';
   $arr = $LangMenu;
   for ( $i = 0; $i -lt $arr.length; $i++ )
   {
      $l = $arr[$i];
      $ret += "<div class=""menudata"">&nbsp;$l&nbsp;</div>$NL";
   }
   $ret += '
</div>
<div class="menubtn_content" id="menubtn_edit_content">
 <div class="menudata" onclick="createDebugWin();">&nbsp;ColorPicker&nbsp;</div>
 <div class="menudata" onclick="alert(this.innerText);">&nbsp;Drevoloz&nbsp;</div>
</div>
';
      return $ret;
   }
   $visible   = $DefaultView;
   $Default   = "Black"; ### should be defined by INI file !
   $Scheme    = $ColorSchemes.$Default;
   $ColorScheme = "<style id=""ColorScheme"">$Scheme</style>";
   $Visibility = "<style id=""Visibility"">$visible</style>";
   $MainTable = BuildMainTable( $arr );
   $Container = "<div id=""MainContainer"">";
   $bottom    = BuildBottomTable;
  
   return "<body>$NL$ColorScheme$NL$Visibility$NL"+`
   "<div id=""MainContainer"">$NL$MainTable$bottom</div>$NL"+`
   "<!--MainContainer-->$NL</body></html>";  
}
################### Part parseIniUtils.ps1 #####################################

function TestBuildNumber( $build )
{
   $reg1 = "\d{4,5}";#"[0-9]{4,5}";
   if ( ! $build -match $reg1 )
   {
      $INILog += "TIMEZONE definition parser: Incorrect Build number $build";
      return $false;
   }
   if ( [int]$build -lt 7601 )
   {
      $INILog += "TIMEZONE definition parser: Build number .$build. is too small";
      return $false;
   }
   if ( [int]$build -gt 15999 )
   {
      $INILog += "TIMEZONE definition parser: Build number .$build. is too big";
      return $false;
   }
   return $true;
}
# is called from GetBuildsHistory, if ( Test-Path $fn ), line ~ 213
function GetIniSettings()
{
   [byte[]]$enc = get-content -Encoding byte -ReadCount 4 -TotalCount 4 $fn
   $data = @();
   # $config = [io.file]::ReadAllLines($fn)
   $config = Get-Content $fn;
   if ( $enc[0] -ne 35 -or $enc[1] -ne 45 -or $enc[2] -ne 45 -or $enc[3] -ne 45 )
   {
      $config | Set-Content -Encoding "Ascii" $fn;
      $config = Get-Content $fn;
   }
   for( $i = 0; $i -lt $config.Length; $i++ )
   {
      $line = ( $config[$i] -split "`#" )[0];
      if ( $line.Length )
      {
         $data += $line;
      }
   }
   return $data;
}

function ParseTimeZoneDefinition( $d )
{
   # TIMEZONE.7601-10576.IsInsider = +03:00
   $lr   = $d -split "=";
   $zone = ($lr[1]).Replace( "utc", "" ).trim();
   $reg1 = "[+-]\d{1,2}";#"[+-][0-9]{1,2}";
   $reg2 = "$reg1\:[03]0";
   $znh  = ( $zone.Substring( 1 ) -split ":" )[0];
   if ( !  ( $zone -match $reg1 -or `
              $zone -match $reg2 -or `
              $znh -gt 12 ) )
   {
      return "*Incorrect TIMEZONE value $zone";         
   }
   $lr   = ($lr[0]).trim();     
   $def  = $lr -split "\.";
   if ( ! $def -is [system.array] ){return "";}
   if ( $def.Length -lt 2 )
   {
      return "*Incorrect TIMEZONE definition $lr (def.Length<2)";
   }      
   if ( $def.Length -eq 3 )
   {
      if ( "Insider,Stable".IndexOf( $def[ 2 ] ) -eq -1 )
      {
        return "*Only ""Insider, Stable"" are permitted in TIMEZONE definition $lr";
      }
      if ( $def[ 2 ] -eq "Insider"  -and ! $IsInsider )
      {
         return "*Definition is ignored as runnnig Stable system";
      }
      if ( $def[ 2 ] -eq "Stable" -and   $IsInsider )
      {
         return "*Definition is ignored as running Insider system";
      }
   }      
   $region = $def[ 1 ] -split "-"; 
   $t = TestBuildNumber( $region[0] );
   if ( ! $t  ){return "";}
   elseif ( $region.Length -eq 2 )
   {
      $t = TestBuildNumber( $region[1] );
      if( ! $t ){return "*???";}        
      if( [int]$region[1] -lt [int]$region[0] )
      { 
         return "*Incorrect Builds region $region";
      }
   }
   $seconds = ( zone2seconds( $zone ) ).ToString();
   return $def[ 1 ] + "=$seconds";           
}
function BuildJS()
{
   $fn  = "GetBuildsHistory.Langs.txt";
   [string[]]$arr = Get-Content $fn;
   [string[]]$langs = @();
   $js = '
var LangStrings={};
LangStrings.en={};
';
   [string[]]$LMenu = @();
   $sNames = "LC,NativeName,FileCreated,FileUpdated,Title,Details,Tooltip,ReRun,SaveSettings,SaveView,"+`
   "Exit,File,View,Theme,Language,Default,Edit,Pink,Black,Green,Blue,Brown,Orange";
   $pcl = "";
   for ( $i = 0; $i -lt $arr.Length; $i++ )
   {
      $line = ($arr[$i] -split "`#" )[0].trim();
      if ( ! $line.Length ) {continue;}

      $ll   = $line.ToLower();

      if ( $line.IndexOf( "=" ) -gt -1 )
      {
         $lr = $line -split "=";
         $ls = $lr[0].trim();
         $rs = $lr[1].trim();
      }

      if ( $ll.StartsWith( "[lang-" ) )
      {
         $langdef = "";
         $cl = $ll.Substring( 6, $ll.Length - 7 );
         if ( $cl -and $cl.Length -eq 2 )
         {
            $langs += "`"$cl`"";
            $js += "LangStrings.$cl={};$NL";
            continue;
         }
      }
      elseif ( $sNames.IndexOf( $ls ) -gt -1 )
      {
         if ( $ls -eq "LC" )
         {
            $langdef += "[$rs] ";
         }
         elseif( $ls -eq "NativeName" )
         {
            $langdef += "$rs";
            $langdef = $langdef.Replace( '"', "" );
            if ( $pcl -ne $cl )
            {
               $LMenu += $langdef;
               $pcl = $cl;
            }
         }
         $js += "LangStrings.$cl.$ls=$rs;$NL";
      }
      elseif ( $ll.StartsWith( "[" ) )
      {
         break;
      }
   }#End-Of-For-loop
   Set-Variable -Name LangMenu -Scope Script -Value $LMenu;
   $allLangs = ( $langs -join "," );
   $js = "var LangsPresent=[$allLangs];$NL$js";
   return $js;
}
################### Part Utils.ps1         #####################################

function Global:zone2seconds( $zone )
{
   $parts   = $zone -split ":";
   $hours   = [int]( $parts[0] );
   $seconds = $hours * 3600;
   if ( $parts.Length -eq 2 -and "00" -ne $parts[1] )
   {
      $seconds += 60 * ( [int]( $part[1] ) );
   }
   return $seconds;
}

function Global:FileTimeToString( [int64]$qw )
{
   return ( [datetime]::fromFileTime( $qw ) ).ToString( "ddd, dd.MM.yyyy HH:mm:ss" );
}

<#
---------------------------------------------------------------------------------
Function converts Reg_DWORD DateTime which presents number of the seconds since 
01.01.1970 00:00:00 into QWORD FileTime number. Constant which is used in
calculations is the number of the 100 nanosecond intervals since 01.01.1601 
till 01.01.1970. 
1 second = 1000 milliseconds = 10000 of 100-ns intervals
---------------------------------------------------------------------------------
the UNIX Epoch is January 1st, 1970 at 12:00 AM (midnight) UTC
#>
function Global:RegDWDateToFileTime( [int32]$dw )
{  
   return [int64]( ( 1000 * $dw + 11644473600000 ) * 10000 );
}
function Global:FiletimeToDWDate( [int64]$ft )
{
   return [int32]([math]::truncate( $ft - 116444736000000000 ) / 10000000 );
}
function Global:TicksToFileTime( [int64] $ticks )
{
   return $ticks - 504911376000000000;
}
function Global:TicksToString( [int64]$ticks )
{
   return FileTimeToString( TicksToFileTime( $ticks ) );
}
function Global:TimeStamp( $action )
{
   $dt = (get-date);
   $ms = ($dt.Millisecond).ToString().PadLeft(3,"0");
   $dt = $dt.ToString( "dd.MM.yyyy HH:mm:ss" );
   if ( ! $action ) {return $dt;}
   return "[$dt.$ms] $action";
}
<#
---------------------------------------------------------------
This function is called before all other functions which build
HTML code. It sets $NarrowScreen value on base of the
screen width detected.
---------------------------------------------------------------
#>
function Global:GetCompInfo
{ 
   function GetRAMSize 
   {
      $q = "select Capacity From Win32_PhysicalMemory";
      $dimms = gwmi -Query $q | select @( "Capacity" );
      $ram = 0;
      $dimms | % { $ram += $_.Capacity };
      $ram = $ram / 1024 / 1024 / 1024;
      return [string]$ram + " GB";
   } 
   # detect current video resolution
   <#   
   $d = (Get-ItemProperty -Path "hklm:\SYSTEM\CurrentControlSet\Enum\DISPLAY\*\1&8713bca&0&UID0").HardwareID
   $d = $d.substring( "MONITOR\".Length );
   $d = (Get-ItemProperty -Path "hklm:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Configuration\$d*\00\00");
   $r = [string]($d."ActiveSize.cx")+"x"+[string]($d."ActiveSize.cy");
   #>
   $d = (gwmi Win32_VideoController).VideoModeDescription -split " X ";

   $w = $d[0];
   $h = $d[1];
   $t = [int]$w -le 1400;

   Set-Variable -Name ScreenWidth  -Scope Script -Value $w; 
   Set-Variable -Name ScreenHeight -Scope Script -Value $h; 
   Set-Variable -Name NarrowScreen -Scope Script -Value $t;

   $r = $d[0] + " x " + $d[1];

   $Comp  = Get-ItemProperty -Path "HKLM:\HARDWARE\DESCRIPTION\System\BIOS"; 
   $stone = Get-ItemProperty -Path "HKLM:\HARDWARE\DESCRIPTION\System\CentralProcessor\0";
   $Disk0 = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Disk\Enum").0;
   $d     = (Get-ItemProperty -Path "hklm:\system\CurrentControlSet\Enum\$disk0").FriendlyName;
   
   [string]$CompID = "";
   if ( $Comp.BaseBoardManufacturer  -ne $null ) { $CompID += $Comp.BaseBoardManufacturer + " "; }
   elseif ( $Comp.SystemManufacturer -ne $null ) { $CompID += $Comp.SystemManufacturer    + " "; }
   if ( $Comp.SystemVersion          -ne $null ) { $CompID += $Comp.SystemVersion         + " "; }
   elseif ( $Comp.SystemFamily       -ne $null ) { $CompID += $Comp.SystemFamily          + " "; }  
   if ( $Comp.SystemProductName      -ne $null ) { $CompID += $Comp.SystemProductName; }
   
   $Platform  = ( $CompID  -replace "\s\s*", " " );
   $Processor = ( $stone.ProcessorNameString.trim() -replace "\s\s*", " " ); 
   $DiskDrive = ( $d  -replace "\s\s*", " " );
   $RAMSize   = GetRAMSize;
   $Monitor   = "$r ( Current resolution )";

   $ML   = "DiskDrive".Length;
   $ret  = @();
   $ret += "{0,-$ML}: {1}" -f "Platform",  $Platform;
   $ret += "{0,-$ML}: {1}" -f "Processor", $Processor;
   $ret += "{0,-$ML}: {1}" -f "DiskDrive", $DiskDrive;
   $ret += "{0,-$ML}: {1}" -f "RAMSize",   $RAMSize;
   $ret += "{0,-$ML}: {1}" -f "Monitor",   $Monitor;
   
   return $ret;
}
function Global:GetRidOfBlanks( [string] $code )
{
   $s = $code -replace '([0-9a-zA-Z"]) ([0-9a-zA-Z"])','$1%%$2';
   $s = $s -replace " `#", "%%#";
   $s = $s    -replace '([0-9])\s([0-9])','$1%%$2'
   return $s -replace "%%"," ";
}
function Global:CodeToString( [string] $code )
{
   $s = $code -replace '([0-9a-zA-Z"]) ([0-9a-zA-Z"])','$1%%$2';
   $s = $s -replace " `#", "%%#";
   <#
   ----------------------------------------------------------------------
   "margin:           5px 0 9 0px;" => "margin:           5px%%0 9%%0px;"
   Thus following replace is necessary
   ----------------------------------------------------------------------
   #>
   $s = $s    -replace '([0-9])\s([0-9])','$1%%$2'
   $s = $s -replace '\s*','';
   return $s -replace "%%"," ";
}
<#--End-of-File-DTConverters------------------------------------------#>

################### Part CreateTextLog.ps1 #####################################  

function BuildTextLog( $arr )
{
<#
CurrentBuild      : 15025
InstallDateString : Thu, 02.02.2017 10:34:26
UpgradeDateString : Wed, 08.02.2017 22:33:14
Minutes           : 33:03
Description       : Microsoft(R) Windows(R) Operating System, Retail channel
ProductName       : Windows 10 Pro Insider Preview
ProductId         : 00330-80000-00000-AA260
ProductId4        : 00330-80000-00000-AA991
ProductId2        : [TH]X19-98841
BuildLabEx        : 15025.1000.amd64fre.rs_prerelease.170127-1750     (Fri, 27.01.2017)
ProductId3        : 55041-03308-000-000000-00-1033-15025.0000-0332017 (Thu, 02.02.2017)
ProductId5        : 00000-03308-000-000000-00-1033-14393.0000-0272017 (Fri, 27.01.2017)
SkuId             : 4de7cb65-cdf1-4de9-8ae8-e3cce27b9f2c
ApplicationID     : {55c92734-d682-4d71-983e-d6ec3f16059f}
DefaultProductKey : VK7JG-NPHTM-C97JM-9MPGT-3V66T
ProductKey        : VK7JG-NPHTM-C97JM-9MPGT-3V66T
EditionID         : Professional
CurrentVersion    : 6.3
ReleaseId         : 1607
UBR               : 1000
InstallDate       : 1486017266          (0x5892D2F2)
InstallTime       : 131304908662564524  (0x01D27D1E6618E6AC)
UpgradeDate       : 1486578794          (0x589B646A)
PSParentPath      : SYSTEM\Setup
PSChildName       : Source OS (Updated on 2/8/2017 22:33:15)
Secret1          : 0A0793585CFEDB6E00
Secret2          : 1E3BBCB3
Secret3          : 58ED3820FBF01D2CF44D615860CE274A3CF5AF8470D167F54B2113F4A7DFC119
Secret4          : BA3FBE8C1C575AB9F5493C95D2E87AE3FEDC851A50C32375A137802261702FB1
#>
   $ShowProps = $AllProperties;
   $MaxL = "UpgradeDateString".Length;
   $Derived = "InstallDateS,InstallTimeS,UpgradeDateS";
   $out = @();              
   for ( $i = 0; $i -lt $arr.Length; $i++ )
   {
      $o = $arr[ $i ];     
    
      for ( $j = 0; $j -lt $ShowProps.Length; $j++ )
      {
         $p = $ShowProps[ $j ];
         $v = $o.$p;

         if ( "InstallDate,InstallTime,UpgradeDate".IndexOf( $p ) -gt -1 )
         {
            if ( $v )
            {
               $v  = FormatNumber( [int64]$v );
            }
         }
         if ( $o.$p -ne $null )
         {
            $out += "{0,-$MaxL} : {1}" -f $p, $v;
         }
      }
      $out += "$NL$NL";
   }
   $out += $CompInfo+"$NL$NL";
   return $out;
}
