﻿<#
--------------------------------------------------------------------------------- 
Project: BuildsHistory                                               
Version: 1.0                                                         
FileId:  f:\Delme\CleanBCD\BuildsHistory                             
When:    October 10, 2016,  Monday,  09:28, Windows build 14942                             
©        Oleg Kulikov, sysprg@live.ru                                                                                          
--------------------------------------------------------------------------------- 
This is PShell version of the BuildsHistory.js which was finished at
October 7, 2016, some hours before Build 14942 became available at WU servers.
--------------------------------------------------------------------------------- 
10.0.14393.321
[MAJOR VERSION].[MINOR VERSION].[BUILD NUMBER].[REVISION NUMBER]
---------------------------------------------------------------------------------
ESD/ISO names structure
<build>.<revision>.<architecture>.<branch>.<timestamp>_<skufamily>_<sku>_<language>.ESD
8250.0.amd64chk.winmain_win8beta.120217-1520_client_professional_en-us.iso
---------------------------------------------------------------------------------
2016.12.11 Set encoding UNICODE to enable opportunity to handle Russian strings
TicksToFileTime and TicksToString functions implemented
File c:\$WINDOWS.~BT\Sources\SetupPlatform.ini contains timestamps in ticks which
can be read and analyzed.
--
Monday,   December 12, 2016 23:21:00
Function Show is excluded as XML and HTA are created. But it appereared that
XML Export decides that obj.InstallDate, obj.InstallTime, obj.UpgradeDate
are integers despite these properties were already converted to strings and
Show log, HTA demonstrate it. Thus it is necessary to change type of these
data in the AddProperties function.
--
Tuesday, December 13, 2016. Have splitted source on 3-parts: 
Utils.ps1    - collection of project independent functions
GBHUtils.ps1 - BuildsHistory functions. Former Show function was renamed
to BuildTextLog and included into GBHUtils.ps1 with some changes according
to 3 new properties defined and with exclusion of the FormatNumber calls as
this function is called from AddProperties.
GetBuildsHistory.ps1 - this one.
Created 3 new properties: InstallDateS, InstallTimeS, UpgradeDateS which
are renamed to the same without trailing 'S' in the text-log and in HTA.
These properties are not exporeted into XML.
All of the code from the loop in Main section which was run AFTER call
of the AddProperties, were moved into the AddProperties.
Improved Details presentation by changes in GBHUtils.
--
Wednesday, December 14, 2016. Well, HTA is started by the last line
of this code. GBHUtils have improved footer line.
Saturday, December 17, 2016. GBHColorSchemes.ps1 implemented. All color
styles are placed now in the body Style tag. JS code can now change
ColorSchemes replacing innerHTML of that Style tag.
--
Wednesday, December 22, 2016. All problems with implementing toolbar
was fixed and Color Theme selection runs fine.
--
Friday, December 23, 2016. INI-file changed: some new sections were
implemented and commented. PLAN: create and implement ASAP Views to
edit and TEST color scheme parameters ( colors ) and GEOMETRY which
strongly depends on the language selection for non-latin alphabeth languages.
Remove all the native language strings from the PShell code to INI-file
and JS-code which HAS NO problems with keeping and handling Unicode strings.
HAD to finish till NY.
--
Saturday, December 24, 2016. 17:23. Color inversion for HOVER items enabled as 
in Toolbar as in Maintable. The same border color is used for MainTable header,
footer and data rows -> one color less. But minor problems:
1. header borders are 1-2 pixels left of those of data rows
2. for the toolbar HOVER items only text content gets necessary color
3. toolbar has no border at all though SHOULD HAS.
4. Yet don't know which width toolbar should have: MainTable WITH or WITHOUT
   scrollbar. Seems better WITH scrollbar width but what about toolbar 
   border in this case?
--
Monday, January 09, 2017. Current Build number is still 14986 but can be
changed this week. What was implemented, improved since December 24:
1. color-picker page ( color.html ) was created but is not yet ready to
   change colors of the parent page;
2. drevolaz had to be rewritten
3. due to 1 & 2, Debugger item in menu is shown as disabled
4. One main color is used now
5. Details are presented in popup window.
 
What is not yet implemented:
1. Onload update of the Language strings and usage of those strings in HTML DONE
2. Saving of the current view as a text                                     DONE
3. additional views.
4. Reading & using previously created XML
5. Some more themes.                                                        DONE
6. background URL / Image support
Item 1 - is implemented for the titles and tooltip which is also a title :)
language selection runs fine though got a lot of time and required creation
of an external JS-code which has encoding Unicode. 
Have saved two of the sources which were in encoded Unicode as ascii.
--
Wednesday, January 11, 2017, Build 15002 was issued at Monday, had to finish
this week. New plans:
1. Ini-file editor in a new window.
2. DIAGCAB instead of cmd-file!
3. Additional views.
--
Saturday, January 14, 2017. Today got at last WHY generated HTA runs fine when
is generated and run from GetHistory.cmd and IE returns NULL from window.open
if generated HTA is clicked or even generated and run from the PShell console
with . .\GetBuildsHistory. It appeared that IE returns correct window handler
provided HTA is runned with administrator privileges and returns NULL otherwise.
Besides have splitted GetBuildsHistory.ini to two files: GetBuildsHistory.ini which
is ascii-encoded and contains only settings + GetBuildsHistory.Lang.txt which
is encoded UNICODE and contains Language string only. 2nd one is read by PShel and
on base of it's content, JS langStrings object is built and written into the
HTA header together with CSS and othe JS code. Today all runs fine and it is clear
what should be done:
1. Save current settings function.
2. Edit Timezones function.
3. Additional views.
--
Monday, January 16, 2017, 03:00. V2, second view - runs nearly fine.
--
Tuesday, January 17, 2017. All three views runs fine including V3
with Secret3/Secret4 visibility switching. Well, postponing some
planned Editors ( colors, TimeZones, Drevolaz ) the only code which need
to be fixed today is "Save current settings" function.
have changed Black -> #999 for the borders in my own themes and improved Orange
Good day:
1. INI-file editor WAD
2. PShell detects INI-file Encoding and rewrites in encoding ASCII if necessary
3. PShell creates INI-file with default settings and system Language if
   INI-file was absent
4. TRY/Catch implemented to prevent "The RPC server is unavailable"
5. Secret3/Secret4 swinching view
6. Save as file for V3
7. Have improved styling ( font-family ) for Secret1,...,Secret4
Thus had to:
add Lang strings for some Menu items and enable JS-code to support them
--
Wednesday, January 18, 2017. Localization is finished, Debug item in menu
replaced by disabled Edit-item, ReadMe-document nearly finished BUT one more
item yet not is not implemented: reading of the XML-files created at the 
previous builds and including of the properties from these builds into the
current collection. Thus starting implementaion.
--
Thursday, January 19, 2017. Have published at nearly 19:00. Have added version
into the copiright string, implemented reading of the old XML-files, fixed
a bug in file names definition: I've hardcoded my R500D for all instead of
$env:computername. Reading of XMLs need to be somewhat improved. Have started
but when looked at the time then decided to postpone this code as new build
can appear today and improvement can be postponed till tomorrow. Besides
it is necessary to write second part of the README with description of the 
properties.
--
Friday, January 20, 2017. Extremal customers problems were fixed today. All availabe
XMLs are read which is not optimal and had to be improved: since 15014 only
last XML had to be read and some objects from this XML used to update properties
of the old builds. Bulgarian translation on the Bulgarian site appeared to be
perfect, no one remark from Veselin. BuildsHistory-1.021.15014.zip is
the last one and seems for long.
--
Tuesday, January 24, 2017. Refactoring performed since Jan 20, have enabled:
1. RunHta.cmd became BuildNumber & Machine-name independent and thus is not
   anymore created at any run of the GetBuildsHistory.js. BUT it became clear
   that it could be improved to run ANY HTA at list in the current directory
   receiving as the only argument full name of the HTA to run or just the Build#.
2. Hidden Divs are not present in the HTML-code generated. Instead an array
   of the JS-string is build in which each of the strings presents compressed
   html-code of the datails window. Ai 1-st I've thought about creating an
   array of the objects but it has no any sense as the there is the only task
   to build by JS Details Window and thus the method of the building should be
   as simple as possible and the length of the source code of the data should
   be as short as possible. I don't know UNZIP algorithm in JS and thus
   is realized as a serial of replaces operations each of which replaces short
   parameter in the form of "%n;" into the string corresponding to the parameter
   value. n is a character of "0123456789ab...zAB...Z" and correstonding strings
   are the names of the properties. Additional parameters of the form "%cm;"
   presents html-substrings and CONSTANT properies values.
3. INI-parser was improved and now there are definitions of the timezones in my
   INI-file for the both, Insider and Stable systems at R500. But unfortunarly
   nor for the HP and this should be done by implementing unique disk-id.
As a result of the refactoring the size of the page generated have reduced 30%.
Next steps of the refactoring are:
a) exclude multiple VIEW-generation and enable any view by the lists of the
   visible properties.
b) make all geometry in percents instead of the pixels ( failed yesterday )
c) make vertical size of the main window corresponding to the full number
   of the strings presented and
d) enable scrolling-correction to present fixed number of the strings.
e) enable smart "onresize" method
Because of the BUG in the SET-commands execution in the IF-block, have lost
a lot of time debugging RunHTA. But as soon as finished debugging, have got
MY old code to enable Admin which runs times faster then OLD RunHTA I've used.
See serious problems when implementing  a) and need to start with adding ONE
more HIDDEN column to the V1-view. I'm afraid that display:none had to be
present in the tags.
--
Thursday, January 26. Yesterday was big step ahead to "Ideal GridView":
1. was excluded idiotic FixGeometry function and likewise actions in the
SetView function.
2. was enabled pretty borders for the View3 which uses monospace font which
have produced ugly borders.
3. Unfortunarly I've failed to enable background for the mr-rows without
setting to those rows additional class-name, rowcell.
4. Today SmartScroll will be implemented as a 1st step as it became clear
how to enable it. Step 2 will be ONE view table with a columns visibility
given by the lists V1, V2, V3.
--
Friday, January 27. Yesterday saved the version in which two old problems
as with geometry as with background color for data-rows as a new problem
which was yesterday detected with zero-height for the column names row
were fixed by the CORRECT ASSIGNMENT of the class-names for all of the
row-content conteiners. Have spent today some time describing problems
and solution. Besides yesterday had done some steps in the direction of
the Smart-Scrolling.
Fixed problems with border at the bottom, one table with all data items
is realized. JS-code and lists had to be improved to permit new lists.
--
Sunday, January 29. Just have finished "accurate scrolling" and cleaned
debug code. Too many time have got fixTop(e) function and scroll event
tracing. Set version to 1.022.15019. This is final for the "Ideal GRIDVIEW"
interface and start of the creation PShell class to generate task-independent
"Ideal GRIDVIEW" for the other tasks.
--
Tuesday, January 31. Have implemented GetDataFromXML which reads last created
XML-file and builds an object for all of the builds not less then 14986. Old
XML-support code was deleted. This is finish.
--
Thursday, February 2. Visible row index evaluation was implemented. Correctness
of the prediction is 50% and thus two row-candidates had to be evaluated in the 
half of the cases. This happens due to the float-point values of the rectangle
properties top, bottom, height.
--
Friday, February 3. dateString & timeStamp JS functions were implemented to
enable one more timestamp in timestamps table: page became visible.
-----------------------------------------------------------------------------
#>
Set-StrictMode -Version Latest

. '.\GBHUtils.ps1'        # Load collection of the project functions
  
#----------------- Define and set some variables with a Global scope ---------------------------
$ts = TimeStamp( "" );
$version = "1.023.15031"; 
Set-Variable Version -Scope Script -Value $version; 

[string]$n = ([char]0x0d)+([char]0x0a);
   
Set-Variable -Name NL  -Scope Script -Value $n;
Set-Variable -Name FSZ -Scope Script -Value 14;   # font size. Only Computer & TimeStamps use 15
Set-Variable -Name px  -Scope Script -Value "px";
                                                                                        
$p = "HARDWARE\DESCRIPTION\System\MultifunctionAdapter\0\DiskController\0\DiskPeripheral\0\";  
$Disk1 = ( get-itemproperty -path HKLM:\$p ).Identifier;                            
Set-Variable DiskId    -Scope Script -Value $Disk1; 

$p  = "SOFTWARE\Microsoft\Windows NT\CurrentVersion";
$cv = ( get-itemproperty -path HKLM:\$p ).CurrentBuild;
Set-Variable CurrentBuild -Scope Script -Value $cv;
$cn = $env:computername.Replace(" ", "_");
Set-Variable LogFN     -Scope Script -Value "$cn$cv"; 

$arr = @();
Set-Variable CompInfo  -Scope Script -Value $arr;
Set-Variable RunLog    -Scope Script -Value $arr;
Set-Variable TimeZones -Scope Script -Value $arr;
Set-Variable TimeZoneDefs -Scope Script -Value $arr;

$dt   = get-date;
$zone = "{0:zzz}" -f $dt;
Set-Variable CurrentTIMEZONE -Value $zone -Scope Script;
$dw   = "{0:x}" -f ( FiletimeToDWDate( $dt.ToFileTime() ) );
Set-Variable StartTime -Scope Script -Value $dw;
$seconds = ( zone2seconds( $CurrentTIMEZONE ) ).ToString();
Set-Variable CurrentTIMEZONESeconds -Value $seconds -Scope Script;

$p = "SOFTWARE\Microsoft\WindowsSelfHost\Applicability";
$p = ( get-itemproperty -path HKLM:\$p ).IsBuildFlightingEnabled;

Set-Variable IsInsider -Scope Script -Value $p;
Set-Variable LANG      -Scope Script -Value "en";
Set-Variable THEME     -Scope Script -Value "Black";
Set-Variable UseNarrow -Scope Script -Value 0;
Set-Variable INILog    -Scope Script -Value $arr; 

$CompInfo = GetCompInfo; # sets screen properties and $NarrowScreen var

<#
--------------------------------------------------------------
Reading and parsing INI-file if it is present in the current
directory: GetBuildsHistory.ini should be created in the
directory in which GetBuildsHistory.ps1 resides.
--------------------------------------------------------------
#>
$fn = "GetBuildsHistory.ini";### Current path is supposed
if ( Test-Path $fn )
{
   $config = GetIniSettings( $fn );
   $TimeZoneDefs = @();
   $inSettings = $false;
   for( $i = 0; $i -lt $config.Length; $i++ )
   {
      $line = $config[$i].trim().ToLower();
      if ( $line -eq "[settings]" )
      {
         $inSettings = $true;
         break;
      }     
   }
   $j = $i + 1;
   for( $i = $j; $i -lt $config.Length; $i++ )
   {
      $line = $config[$i];
      if ( ! $line.trim() ){continue;}
      $ll   = $line.ToLower();     
      if ( $inSettings )
      {
         if( $ll.IndexOf( "=" ) -eq -1 ) 
         {
            $INILog += "Incorrect statement: |$line|";
            continue;
         }
         $val = ( $ll -split "=" )[1].trim(); 
         if ( $ll.StartsWith( "timezone." ) )     
         { 
            $val = ParseTimeZoneDefinition( $line );
            if ( $val.StartsWith( "*" ) )
            {
               $INILog += "$line " + $val.Substring(1);
            }
            else
            {
               $INILog += "TIMEZONE definition $line is assigned";
               $TimeZoneDefs += $val;
            }
         }
         elseif ( $ll.StartsWith( "textlog" ) )
         {
            if ( $val -match "[01]" -and [int]$val -le 1 )
            {
               Set-Variable TEXTLOG -Scope Script -Value $val;
               $INILog += "TEXTLOG assigned value $val"
            }
            else
            {
               $INILog += "Incorrect TEXTLOG value: $val";
            }
         }
         elseif ( $ll.StartsWith( "usenarrow" ) )
         {
            if ( $val -match "[01]" -and [int]$val -le 1 )
            {
               Set-Variable UseNarrow -Scope Script -Value $val;
               $INILog += "UseNarrow assigned value $val"
            }
            else
            {
               $INILog += "Incorrect UseNarrow value: $val";
            }
         }
         elseif ( $ll.StartsWith( "lang" ) )
         {
            if ( $val.Length -eq 2 -and $val -match '[a-zA-Z]' )
            {
               Set-Variable LANG -Scope Script -Value $val;
               $INILog += "LANG assigned value $LANG";
            }
            else
            {
               $INILog += "Incorrect language definition: $line";
            }
         }
         elseif ( $ll.StartsWith( "productkey" ) )
         {
            if ( $val -match "[01]" -and [int]$val -le 1 )
            {
               Set-Variable PRODUCTKEY -Scope Script -Value $val;
               $INILog += "PRODUCTKEY assigned value $val"
            }
            else
            {
               $INILog += "Incorrect value for the productkey: $val";
            }
         }
         elseif ( $ll.StartsWith( "theme" ) )
         {
            $supported = @("black","green","blue","brown","orange","pink");
            $color = "Black";
            for ( $j = 0; $j -lt $supported.Length; $j++ )
            {
               if ( "$val" -eq $supported[$j] )
               {
                  $color = $val.Substring( 0, 1 ).ToUpper() + 
                  $val.Substring( 1 ).ToLower();
                  break;
               }
            }
            if ( $j -eq $supported.Length )
            {
               $INILog += "Incorrect value for the theme: $val";
            }
            Set-Variable THEME -Scope Script -Value "$color";
            $INILog += "THEME assigned value $THEME"
         }
      }#End-Of-If-inSettings;   
   }#End-Of-For-Config-lines-Loop;
}#End-Of-if(Test-Path $fn);
else
{
   Set-Variable TEXTLOG -Scope Script -Value 0;
   $syslang = (get-culture).Name.Substring( 0, 2 );
   Set-Variable LANG    -Scope Script -Value $syslang;
   Set-Variable THEME   -Scope Script -Value "Black";
   Set-Variable PRODUCTKEY -Scope Script -Value 0;
   $ini = @(
   "[settings]$NL"
   "productkey = 0   # 0 - show partial key, 1 - show full key$NL"
   "textlog    = 0   # 1 - create full text log, 0 - omit creation$NL"
   "lang       = $LANG  # en,ru,uk,ge$NL"
   "theme      = $THEME # pink,black,blue,green,brown,orange$NL"
   );
   $ini | Set-Content -Encoding "Ascii" .\GetBuildsHistory.ini;
}
if ( $INILog.length )
{
   $INILog | Set-Content -encoding "ascii" .\GetBuildsHistory-INI-parse.log;
   $INILog = @();   
}
#----------------------End-of-Globals-----------------------------

function Global:GetDataFromXML
{
   [PSObject]$res = @{};
   if ( ! (Test-Path -path .\*.xml) ){return $null;}
   $xmls = (get-item *.xml).Name | 
   %{ $t=$_.substring($_.Length-9,5); if($t -ne $CurrentBuild){"$t$_";} } | 
   sort -Descending;

   $need = @( 
      "CurrentBuild"
      "ApplicationID"
      "ProductId4"
      "ProductId5"
      "DefaultProductKey" 
   );
   if (  ! $xmls.Length ) {return $null;}

   $n = $xmls[0].Substring( 5 );
   $a = Import-Clixml -literalpath .\$n;
   for ( $j = $a.Length - 1; $j -ge 0; $j-- )
   {
      $o = ( $a[$j] | Select $need );
      $b = $o.CurrentBuild;
      if ( $b -eq $CurrentBuild ){continue;}
      if ( [int]$b -lt 14986 ){ break; }
      Add-Member -InputObject $res -type NoteProperty -name "b$b" -value $o;
   }
   return $res;
}
<#
-------------------------------------------------------------------------
Fuction is called after an array of the objects is already sorted.
Function creates some properties for the objects returned from the
Registry. It also changes some propeties values. 
-------------------------------------------------------------------------
#>
function AddProperties( [pscustomobject]$o )
{
   function DecryptWindowsKey( [byte[]]$ByteArray )
   {              #0-9abcdef01234567
      $TrTable = "BCDFGHJKMPQRTVWXY2346789"
      $TrTabL  = $TrTable.Length;
      $RawData = $ByteArray;
      $Last    = $RawData.Length - 1;
      
      [bool]$isWin8 = ( ( $RawData[ $Last ] -shr 3 ) -band 1 );                                                           
      $RawData[ $Last ] = $RawData[ $Last ] -band 0xF7; 
       
      $PK = "";                                                                                    
      for ( $i = $TrTabL; $i -ge 0; $i-- )                                                                   
      {                                                                                                 
         $TrTabIndex = 0;                                                                                        
         for ( $j = $Last; $j -ge 0; $j-- )                                                                
         {
            $TrTabIndex = $TrTabIndex -shl 8 -bxor $RawData[ $j ];                                                      
            $RawData[ $j ] = [Math]::Truncate( $TrTabIndex / $TrTabL );            
            $TrTabIndex = $TrTabIndex % $TrTabL            
         }                                                                                              
         $PK = $TrTable[ $TrTabIndex ] + $PK;                                                                    
      }                                                                                                                                                                                        
                                                                                                        
      if ( $isWin8 )                                                                              
      {
         $i = $TrTable.indexOf( $PK.Substring( 0, 1 ) );                                                                                                                                       
         $PK = $PK.Substring( 1 ).Insert( $i,'N' );                                                                                  
      }                                                                                                 
                                                                                                        
      return "" +`                                                                                      
             $PK.Substring(  0, 5 ) + "-" +`                                                            
             $PK.Substring(  5, 5 ) + "-" +`                                                            
             $PK.Substring( 10, 5 ) + "-" +`                                                            
             $PK.Substring( 15, 5 ) + "-" +`                                                            
             $PK.Substring( 20, 5 );                              
   }#End-of-DecryptWindowsKey 
   function DeleteCurlyBra( $str )
   {
      if ( $str.StartsWith( "{" ) )
      {
         return $str.Substring( 1, "55c92734-d682-4d71-983e-d6ec3f16059f".Length );
      }
      return $str;
   }
   function ByteArrayToString( [byte[]]$arr )
   {
      return ([char[]]$arr -join "").Replace( "`0", "" );
   }
   function GetProductId3( [byte[]]$arr ) 
   {
      $d   = ByteArrayToString( $arr ); 
      $t   = $d.split( "-" )[ 7 ];
      $day = [int]$t.Substring( 0, 3 ) - 1;
      $dat = [datetime]( "01/01/" + $t.Substring( 3 ) );
      $t   = (Get-Date $dat).AddDays( $day ).ToString( "ddd, dd.MM.yyyy" );
      $l   = "55041-01781-051-124375-01-1033-10049.0000-0902015".Length;
      return "{0,-$l} ({1})" -f $d, $t; 
   }
   function GetBuildLabExDate( $str )
   {  # 9600.17668.amd64fre.winblue_r8.150127-1500
      $dt = $str.split( "." )[4];
      $dt = $dt.Substring( 4, 2 ) + "." + $dt.Substring( 2, 2 ) + "." +`
      "20" + $dt.Substring( 0, 2 ) + " " + $dt.Substring( 7, 2 ) + ":" +`
      $dt.Substring( 9, 2 ) + ":00";
      return ( get-date $dt ).ToString( "ddd, dd.MM.yyyy" );
   }
   function ArrayToHexString( $a )
   {
      return [System.BitConverter]::ToString( $a ).Replace( "-", "" );
   }
   
   function AddPropsFromXML( $o )
   {
      $xml = [PSObject]$xmlData;
      if ( ! $xml ) {return $o;}
      $b   = $o.CurrentBuild;
      $key = "b$b";
      $o1  = $xml.$key;
      if ( $o1 )
      {
         Add-Member -InputObject $o -type NoteProperty -name ApplicationID -value "";
         Add-Member -InputObject $o -type NoteProperty -name ProductId4 -value "";
         Add-Member -InputObject $o -type NoteProperty -name ProductId5 -value "";
         Add-Member -InputObject $o -type NoteProperty -name DefaultProductKey -value "";
         $o.ApplicationID     = DeleteCurlyBra( $o1.ApplicationID );
         $o.ProductId4        = $o1.ProductId4;
         $o.DefaultProductKey = $o1.DefaultProductKey;
         $o.ProductId5        = $o1.ProductId5;
      }
      return $o;
   }
   Add-Member -InputObject $o -type NoteProperty -name Minutes            -value "";
   Add-Member -InputObject $o -type NoteProperty -name UpgradeDate        -value "";
   Add-Member -InputObject $o -type NoteProperty -name UpgradeDateString  -value "";
   Add-Member -InputObject $o -type NoteProperty -name InstallDateString  -value "";
   Add-Member -InputObject $o -type NoteProperty -name InstallDateS       -value "";
   Add-Member -InputObject $o -type NoteProperty -name InstallTimeS       -value "";
   Add-Member -InputObject $o -type NoteProperty -name UpgradeDateS       -value "";
   Add-Member -InputObject $o -type NoteProperty -name Description        -value "";
   Add-Member -InputObject $o -type NoteProperty -name ProductId2         -value "";
   Add-Member -InputObject $o -type NoteProperty -name ProductId3         -value "";
   Add-Member -InputObject $o -type NoteProperty -name SkuId              -value "";
   Add-Member -InputObject $o -type NoteProperty -name ProductKey         -value "";
   Add-Member -InputObject $o -type NoteProperty -name Secret1           -value "";
   Add-Member -InputObject $o -type NoteProperty -name Secret2           -value "";
   Add-Member -InputObject $o -type NoteProperty -name Secret3           -value "";
   Add-Member -InputObject $o -type NoteProperty -name Secret4           -value "";
   Add-Member -InputObject $o -type NoteProperty -name Channel             -value "";
   
   $o.ProductId2  = ByteArrayToString( $o.DigitalProductID[0x024..0x033]  );
   $o.ProductKey  = DecryptWindowsKey( $o.DigitalProductId[0x034..0x042]  ); 
   $o.Secret1     = ArrayToHexString(  $o.DigitalProductId[0x048..0x050]  );
   $o.Secret2     = ArrayToHexString(  $o.DigitalProductId[0x0a0..0x0a3]  );

   $o.ProductId3  = GetProductId3(     $o.DigitalProductID4[0x008..0x06C] );
   $o.SkuId       = ByteArrayToString( $o.DigitalProductID4[0x088..0x0D0] ); 
   $o.Secret3     = ArrayToHexString(  $o.DigitalProductId4[0x338..0x357] );
   $o.Secret4     = ArrayToHexString(  $o.DigitalProductId4[0x358..0x377] );
   $o.Channel     = ByteArrayToString( $o.DigitalProductID4[0x3f8..0x46f] );

   $o.Description = "Microsoft(R) Windows(R) Operating System";
  
   if ( $o.PSPath.EndsWith( "CurrentVersion" ) )
   {
      $cv = "SOFTWARE\Microsoft\Windows NT\CurrentVersion";
      $p  = "$cv\SoftwareProtectionPlatform\GenuineApps\";
      $d  = ( get-childItem hklm:\"$p*" ).Name.Substring( "HKEY_LOCAL_MACHINE\$p".Length );
      $d  = DeleteCurlyBra( $d );
      Add-Member -InputObject $o -type NoteProperty -name ApplicationID -value $d;
      $Need = @( "ProductId", "DigitalProductId", "DigitalProductId4" );
      $od   = ( get-itemproperty HKLM:\"$cv\DefaultProductKey" -Name $Need );
      Add-Member -InputObject $o -type NoteProperty -name ProductId4 -value "";
      Add-Member -InputObject $o -type NoteProperty -name ProductId5 -value "";
      Add-Member -InputObject $o -type NoteProperty -name DefaultProductKey -value "";
      $o.ProductId4        = $od.ProductId;
      $o.ProductId5        = GetProductId3( $od.DigitalProductID4[008..108] );
      $o.DefaultProductKey = DecryptWindowsKey( $od.DigitalProductId[0x034..0x042]  );     
   } 

   if ( [int]$o.CurrentBuild -lt 10122 )
   {
      $tmp = $o.BuildLabEx.split( "." );
      $ubr = $tmp[ 1 ];
      $bb  = $tmp[ 3 ];
      Add-Member -InputObject $o -type NoteProperty -name UBR -value $ubr;
      Add-Member -InputObject $o -type NoteProperty -name BuildBranch -value " $bb";
   } 
   if ( [int]$o.CurrentBuild -lt 9841 )#( $o.InstallTime -eq $null )## BuildNumber less them 9841
   {
      Add-Member -InputObject $o -type NoteProperty -name InstallTime -value 1427802253;   
      $o.InstallTime = RegDWDateToFileTime( $o.InstallDate ); 
   } 
   $o.UBR = $o.UBR.ToString(); 
   $o.InstallDateString = FileTimeToString( $o.InstallTime );  
   # Update property BuildLabEx
   $d = GetBuildLabExDate( $o.BuildLabEx );
   $l = "10074.1.amd64fre.fbl_impressive_cxe.150425-1755".Length;
   $o.BuildLabEx = ("{0,-$l} ({1})" -f $o.BuildLabEx, $d); 
   $pp = "Microsoft.PowerShell.Core\Registry::HKEY_LOCAL_MACHINE\".Length; 
   $o.PSParentPath = $o.PSParentPath.Substring( $pp );
   if ( $o.PSChildName.Substring( 0, 3 ) -eq "Sou" )
   {
      $o.UpgradeDate       = DateStringToSeconds( $o );
      $o.UpgradeDateString = FileTimeToString( RegDWDateToFileTime( $o.UpgradeDate ) );
   }

   if ( [int]$o.CurrentBuild -ge 14986 -and [int]$o.CurrentBuild -lt [int]$CurrentBuild )
   {
      $o = AddPropsFromXML( $o );     
   }
   
   return $o;
}

## https://www.tutorialspoint.com/xaml/xaml_layouts.htm
#------------------------- Builds objects collecting starts ---------------------------------
[string[]]$t = @();
Set-Variable -Name TimeStamps -Scope Script -Value $t;
[string[]]$TimeStamps += TimeStamp( "PShell script started" );   

$temp  = [psobject[]]( get-itemproperty HKLM:\SYSTEM\Setup\"Source OS*" -EA SilentlyContinue ); 
$temp += ( get-itemproperty HKLM:\SOFTWARE\Microsoft\"Windows NT\CurrentVersion" );

[PSObject]$t = GetDataFromXML;
Set-Variable -Name xmlData -Scope Script -Value $t;

$TimeStamps += TimeStamp( "Builds objects collecting finished" );
                     
### SORT an array of the Build objects
$temp = ( $temp | Sort-Object -Property InstallDate );
for ( $i = 0; $i -lt $temp.length; $i++ )
{
   Add-Member -InputObject $temp[$i] -type NoteProperty -name Index -value $i;
}

$MaxL  = "Windows 10 Pro Technical Preview".Length;
$DateL = "13.10.2016 21:23:31".Length;
$FreeUpgrade = [int]$temp[0].CurrentBuild -lt 9841;

for ( $i = 0; $i -lt $temp.Length; $i++ )
{
   $obj = AddProperties( [pscustomobject]$temp[ $i ] );
   
   if ( [int]$obj.CurrentBuild -le 10240 )
   {
      if ( $FreeUpgrade -and $temp[ $i ].ProductKey.Split( "-" )[ 4 ] -eq `
      $temp[ 0 ].ProductKey.Split( "-" )[ 4 ] )
      {
         if ( $PRODUCTKEY -eq 0 )
         {
            $p = $temp[ $i ].ProductKey.Substring( 24 );
            $temp[ $i ].ProductKey = "XXXXX-XXXXX-XXXXX-XXXXX-$p";
         }
      }
   }
   if ( $i -gt 0 )
   {
      $obj.Minutes = [math]::truncate( ( $obj.InstallDate - $temp[ $i - 1 ].UpgradeDate ) / 60 );
      $seconds     = ( $obj.InstallDate - $temp[ $i - 1 ].UpgradeDate ) % 60;
      $seconds     = $seconds.ToString().PadLeft( 2, "0" ); 
      $obj.Minutes = $obj.Minutes.ToString() + ":" + $seconds;
   }   
   $temp[ $i ] = $obj; # update Array element   
}

$edid  = $temp[0].EditionID + ", " + $temp[0].Channel;# is defined AFTER AddProperties
Set-Variable -Name OSEdition -Scope Script -Value $edid;

Init( $temp ); #CountFieldsWidth( $temp );
 
############################################################################
# Building HTML code starts here                                           #
############################################################################

$HeaderStyle = '
html    { box-sizing: border-box; }
*, *::before, *::after { box-sizing: inherit; }
html    { overflow-x: hidden; }
body    { margin:0; font-family: "Segoe UI"; letter-spacing:0px; font-size: 14px; }
.wide   { letter-spacing:2px; }
.menu   { list-style-type:none; margin:0; padding:0; overflow:hidden; }
.padded { padding-top: 8px; padding-bottom: 8px; }
.menu   { position: relative; z-index:4; }
.menu a { text-decoration: none; }
.right  { float: right !important; }
.menu li { float: left; }
.menu li a, .menuitem, .menu li { display: block; padding: 8px 16px; }
.caret  { font-family: Webdings; }
.menubtn_content {display:none; position:absolute; top:50px; padding:5px; letter-spacing:2px;} 
.menudata { padding-top: 2px; padding-bottom: 2px; }    
.menu-a, .mr, .menudata, #V1expandable { cursor:pointer; }

#menubtn_file_content  { left: 022px; }
#menubtn_view_content  { left: 146px; } 
#menubtn_theme_content { left: 279px; }
#menubtn_lang_content  { left: 426px; }
#menubtn_edit_content  { left: 602px; }

.hdrcell, .rowcell { float: left; }
.ProductId3 span,.fw{font-family:Consolas; border:none;}
.mr{cursor:pointer; border: none;}
.footbarClass {border: none;}

#MainContainer { padding: 0px; margin: 0px; overflow: hidden; }   
#V1tablecontainer { width: 98%; height: 98%; margin: 0 auto; padding: 0px; max-height: 0452px; }
#V1expandable{ margin:5px 0 0 0px; overflow-x:hidden; overflow-y:auto; width: 100%; border-bottom: none; }

.Build      {text-align:right;  width: 046px;}          
.Date1      {text-align:left;   width: 180px;}           
.Date2      {text-align:left;   width: 180px;}           
.Name       {text-align:left;   width: 250px;}           
.Branch     {text-align:left;   width: 125px;}/*140*/           
.UBR        {text-align:right;  width: 060px;}/*099*/
.RelId      {text-align:center; width: 054px;}           
.mmss       {text-align:center; width: 071px;}/* sum = 966 + 2 border pixels*/  
.ProductId  {text-align:left;   width: 192px;}
.ProductId2 {text-align:left;   width: 122px;}
.Secret1    {text-align:left;   width: 148px;}  
.Secret2    {text-align:left;   width: 074px;}
';

if ( $NarrowScreen -or $UseNarrow )
{
   $HeaderStyle +='
#MainContainer { width: 1030px; heigth: 760px; max-width: 1170px; }
#V1expandable  { height: 372px; } 
.copyr {width: 966px;}        
.menu  {width: 968px;}
.ProductId3 {text-align: left;  width: 606px;}
.Secret3    {text-align: left;  width: 698px;} 
';
}
else
{
   $HeaderStyle +='
#MainContainer { width: 1354px; heigth: 800px; max-width: 1380px; }  
#V1expandable  { height: 412px; }
.copyr {width:1280px;}
.menu {width:1282px;}       
.ProductId3 {text-align:left;  width: 554px;}
.Secret3    {text-align:left;  width: 503px;}
.Secret4    {text-align:left;  width: 509px;}
.Version    {text-align:left;  width: 055px;}
.EditionId  {text-align:left;  width: 095px;}
.EditionID  {text-align:left;  width: 095px;}
.BuildLabEx {text-align:left;  width: 530px;}
.BuildLabEx span,.Secret4,.fw{font-family:Consolas; border:none;}
';
}

$HeaderStyle = GetRidOfBlanks( $HeaderStyle );#get rid of blanks BUT KEEP \n
$bgRose = "http://webneel.com/wallpaper/sites/default/files/images/01-2014/20-flower-wallpaper.preview.jpg";
<#
::-webkit-scrollbar{width:5px!important;}
::-webkit-scrollbar-thumb{background: #0000ff!important;}
above strings doesn't work for IE
#>
$ColorSchemePink = '
.menubtn_content { color:#ef7a8f; border:2px solid #ef7a8f; border-top:none; background-color:#fff; }
.menu-a:hover {color:#000; background-color:#fff;}
.menudata:hover{background:#ef7a8f;color:#fff;}
#menubtn_*:hover{ color:#7d10b5; }
#menubtn_edit,#menubtn_edit a,#menubtn_edit:hover{color:gray;background-color:#ef7a8f;cursor:default;}
.theme  { color:#fff; background-color:#ef7a8f; }
a { background-color:transparent; -webkit-text-decoration-skip: objects; color:#fff; } 
body, #V1expandable, #V1tablecontainer { background-color:#f6e2f9; }
#V1expandable{color:#a914a9;} 
.hdrcell, .rowcell { border: 1px solid #999000; box-sizing: border-box; border-bottom: none;}
.hdrcell { background-color:#ef7a8f; color: #fff; }
#V1footBar{border:1px solid #999000; box-sizing: border-box; border-top: none;border-bottom:2px solid #999000;}
.rowcell:hover {background-color:#a914a9; color:#f6e2f9;}
'; # Colors used: #ef7a8f; #7d10b5; #f6e2f9; #a914a9; #999000; #fff;

$ColorSchemePink = CodeToString( $ColorSchemePink );

$brdr  = "#999";#"#e5e5e5";
$dark  = "#2f4f4f";# is used as text color, dark background 
$light = "#d3d3d3";# is used as text color on dark and background for rows
$body  = "#dcdcdc";# less intensive then light
$hover = "#778899";# intermediate between light and dark

$ColorSchemeBlack = @"
.menubtn_content{color:$dark;border:2px solid $brdr; border-top:none; background-color:$light;}
.menudata:hover{background:$hover;color:#ffffff;}
#menubtn_*:hover{color:$light;}
#menubtn_edit,#menubtn_edit a,#menubtn_edit:hover{color:gray; background-color:$dark; cursor:default;}
.theme{color:#ffffff; background-color:$dark;}
a{background-color:transparent; -webkit-text-decoration-skip:objects; color:$light; }
.white,.menu-a:hover{color:$dark; background-color:#ffffff;}
body,#V1expandtable,#V1tablecontainer{background-color:$body;}
#V1tablecontainer{background: $light;}
#V1expandable{color:$dark;}
.rowcell,.hdrcell {float:left; border:1px solid $brdr; box-sizing:border-box; border-bottom:none;}
.rowcell:hover{background:$hover; color:#ffffff;}
#V1footBar{border:1px solid $brdr; box-sizing: border-box; border-bottom:2px solid $brdr;}
.hdrcell{background:$dark;color:$light;}
"@;

$ColorSchemeBlack = CodeToString( $ColorSchemeBlack );

$schemes = ( "" | Select HeaderStyle,Black,Pink );#RoseFlowers

Set-Variable ColorSchemes -Scope Script -Value $schemes;

$ColorSchemes.Pink  = "$ColorSchemePink";
$ColorSchemes.Black = "$ColorSchemeBlack";
### OTHER SCHEMES are produced from the Black by JS-code ###
<#
Geometry:    http://javascript.info/tutorial/metrics;
ColorNames:  http://www.w3schools.com/colors/colors_names.asp;
Characters names: http://www.ascii.cl/htmlcodes.htm
#>
$jsBuildsArr = PSArrToJSArr( $temp );
$head =@"
<!DOCTYPE html><html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=11">
<title>Builds History</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<style type="text/css">
$HeaderStyle
</style>
<script type=""text/javascript"">
var version="$Version";
if ( typeof( repeat ) == "undefined" )
{
   String.prototype.repeat = function( n )                               
   { 
      var tmp = ""; 
      for ( var i = 0; i < n; i++ ) tmp += this;                                                                         
      return tmp;
   } 
} 
String.prototype.left = function( n, char )                               
{ 
   if ( typeof( char ) == "undefined" ) char = " ";  
   if ( this.length >= n ) return this.substr( 0, n );
   return this + char.repeat( n - this.length );
}
String.prototype.right = function( n, char )                               
{
   if ( typeof( char ) == "undefined" ) char = " ";   
   if ( this.length > n ) return this.substr( this.length - n );
   return char.repeat( n - this.length ) + this;
}
String.prototype.strip = function()                                         
{                                                                           
   return this.replace( /^(\s*)/, "" ).replace( /(\s*)$/, "" );               
}
String.prototype.html2text = function()
{
   return this.replace( /</gm, "&lt;" ).replace( />/gm, "&gt;" );
}
Date.prototype.dateString = function( ms, dvd )
{
   ms  = ms  || true;
   dvd = dvd || ".";
   var td = (this.getDate()).toString().right(2,"0");
   var tm = (this.getMonth()+1).toString().right(2,"0");
   var ty = (this.getFullYear()).toString();
   var hh = (this.getHours()).toString().right(2,"0");
   var mm = (this.getMinutes()).toString().right(2,"0");
   var ss = (this.getSeconds()).toString().right(2,"0");
   var ms = (this.getMilliseconds()).toString().right(3,"0");
   var bv = td+dvd+tm+dvd+ty+" "+hh+":"+mm+":"+ss;
   if ( ms ) bv += "."+ms;
   return bv;
}
function timeStamp( dobj, dvd )
{
   if ( ! dobj ) dobj = new Date();
   return dobj.dateString( "dd.mm.yyyy hh:MM:ss.ms" ); 
}
function getEvent()
{
   var evt = event || window.event;
   evt.cancelBubble = true;
   evt.returnValue  = false;
   if ( evt.cancelable ) evt.preventDefault();
   return evt;
}
 
var lastShownItem    = null;
var lastShownContent = null;
var lastShownCaret   = null;
var caretDown = "6", caretUp = "5";

function showMenuContent( o )
{
   var Event = getEvent();// call it to prevent event propagation
   obj = o.currentTarget;

   if ( lastShownItem )
   {
      lastShownContent.style.display = "none";
      lastShownItem.getElementsByTagName( "span" )[0].innerText = caretDown;
   }

   if ( obj.id == "IgnoreMe" ) return false;// specially for disabled Edit menu item;

   var id                = obj.getElementsByTagName( "a" )[0].id;
   var content           = document.getElementById( id + "_content" );
   var caret             = obj.getElementsByTagName( "span" )[0];
   content.style.display = "inline-block";
   caret.innerText       = caretUp;
   lastShownItem         = obj;
   lastShownCaret        = caret;
   lastShownContent      = content;
   return false;
}
function hideMenuContent()
{
   var ev = getEvent();
   if ( ! lastShownItem ) return false;
   lastShownContent.style.display = "none";
   lastShownItem                  = null;
   if ( lastShownCaret )
   {
      lastShownCaret.innerText = caretDown;
      lastShownCaret = null;
   }    
   return false;   
}
$jsBuildsArr
var activeTheme = "$THEME"; 
var currentLang = "$LANG"; 
var TEXTLOG     = $TEXTLOG; 
var PRODUCTKEY  = $PRODUCTKEY; 
var ViewLists   = {}; 
var ScreenWidth = $ScreenWidth; 
var ScreenHeight = $ScreenHeight; 
var UseNarrow = $UseNarrow;
"@;

$vlists = @( $NamesObj.List1, $NamesObj.List2, $NamesObj.List3 );

for ( $i = 1; $i -le $vlists.length; $i++ )
{
   $l = $vlists[$i-1];
   $head += "ViewLists.V$i = ""$l"";$NL";
}

$head += $JSNamesObj -join "$NL";
$head += "$NL";

$l1 = $vlists[0];
$ll = $vlists.Length - 1; 

$lj = $vlists[1..$ll] -join ",";
$v = "$l1{display:block;}$lj{display:none;};"
Set-Variable -Name DefaultView -Scope Script -Value $v;

$head += @"
var childWindows = [];  // keep all child windows handlers
var currentV     = "V1" // prefix for the current View

/*
---------------------------------------------------------------------
Function to switch View: it makes invisible ( display:none )
current GridView and makes visible requested View ( display: block )
----------------------------------------------------------------------
*/
function setView( viewId )
{
   var ev = getEvent();
   currentV = viewId;
   var code = "", u = [];
   for ( var p in ViewLists )
   {
      if ( p == viewId ) 
      {
         code = ViewLists[p] + "{display:block;}";
      }
      else u[ u.length ] = ViewLists[p]; 
   }
   code += u.join(",") + "{display:none;}";
   document.getElementById("Visibility").innerHTML = code;
   hideMenuContent();
   return false;
}
var ColorScheme =
{
   "Black": "$ColorSchemeBlack",
   "Pink": "$ColorSchemePink" 
};
var popColors = 
{//             dark      light     border    body 
   "Black":   ["#2f4f4f","#d3d3d3","#dcdcdc","#778899"],
   "Pink":    ["#a914a9","#f7dede","#f6e2f9"],
   "Green":   ["#006400","#90ef90","#98fb98","#00ff00"],
   "Blue":    ["#0000cd","#add8d6","#8fcefa","#6495ed"],
   "Brown":   ["#8b4516","#ffe4c4","#f5deb3","#cd853f"],
   "Orange":  ["#C96","#ffffe0","#ffcacd","#ff8c00"]//#C96 
 //             dark      light     body      hover
 //"Orange":  ["#ff4500","#ffffe0","#ffcacd","#ff8c00"]//#C96 #ff8c00
}
/*
--------------------------------------------------------
Two color schemes, Pink and Black, are kept in an array
ColorScheme. Other shemes are presented by the objects
in an array popColors. These objects are used to create
any but Pink color scheme from the Black-theme colors.   
--------------------------------------------------------
*/
function setTheme( schemeName )
{
   var ev = getEvent();
   if ( typeof( schemeName ) == "string"
   &&   schemeName == activeTheme ) return false;
   if ( typeof( schemeName ) == "object" ) schemeName = schemeName.id;
   schemeName = schemeName.substr(0,1).toUpperCase() +
   schemeName.substr(1).toLowerCase();
   var scheme = null;
   if ( "Pink,Black".indexOf( schemeName ) > -1 )
   {
      scheme = ColorScheme[ schemeName ];
   }
   else
   {
      scheme = ColorScheme.Black;
      var colors = popColors[ schemeName ];
      scheme = scheme.replace( /#2f4f4f/gi, colors[0] );
      scheme = scheme.replace( /#d3d3d3/gi, colors[1] );
      scheme = scheme.replace( /#dcdcdc/gi, colors[2] );
      scheme = scheme.replace( /#778899/gi, colors[3] );
   }
   document.getElementById( "ColorScheme" ).innerHTML = scheme;
   activeTheme = schemeName;
   hideMenuContent();
   return false; 
}
function ShowDetails( row )
{
   var ev = getEvent();
   var win  = null;
   var colors = popColors[ activeTheme ];
   var themeDependent = ".hc{color:%color1;background-color:%color2;border:1px solid %color1;}"+
   "body{background-color:%color3;}";

   themeDependent = themeDependent.replace( /%color1/g, colors[0] );
   themeDependent = themeDependent.replace( "%color2", colors[1] );
   themeDependent = themeDependent.replace( "%color3", colors[2] );

   var html = ""+  
"<!DOCTYPE html><html><head><meta content=\"IE=11.0000\" http-equiv=\"X-UA-Compatible\">"+
"<title>" + LangStrings[currentLang].Details + "</title>"+    
"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"><style type=\"text/css\">"+
".h{font-family:MS Serif;letter-spacing:0px;}.KB{font-family:Consolas;letter-spacing:0px;}"+
themeDependent + "</style></head><body>";
   // after implementing Vn-prefix in row-ids, following substr had to be changed, 17.01.2017;
   // 27.01.2017, new format of the id: "VnIIIBBBB", III - index of the row in MainTable 
   var bld = ( parseInt( "0x" + row.id.substr( 5, 4 ) ) ).toString();
   html = html.replace( "%bld%", bld );
   var indx = parseInt( row.id.substr(2, 3) );
   var code = s2l( DC[ indx ] );
   html += code + "</body></html>";
   var options = "width=810,height=720,scrollbars=1,resizable=1,status=0,toolbar=0,"+
  	"left=200,top=1200,titlebar=0,menu=0";

	win = window.open( "empty.html", "", options );//should be run as administrator

   if( win )
   {
      win.document.write( html );     
      childWindows[ childWindows.length ] = win;
   }
   else// null-handler was returned by IE, 
   {   // needs Adminitrator privileges to create popup windows
      alert( LangStrings[ currentLang ].ReRun );     
   }

   return false; 
}
function closeAllWindows()
{
   var ev = getEvent();
   for( var i = 0; i < childWindows.length; i++ )
   {
      var h = childWindows[ i ];
      if ( h ) 
      {
         // this try/catch are necessary because of SOMETIMES
         // rather strange error "The RPC-server is unavalable"
         // is ussued
         try
         {
            h.window.close();
         }
         catch(e){}
      }
   }
   window.close();
} 
function closePopUps()
{
   var Event = getEvent();
   if ( Event.keyCode == "27" )// Escape;
   {
      hideMenuContent();
   }
   return false;
}
"@;

if ( $NarrowScreen -or $UseNarrow )
{
   $head +='
function switchUnknowns()
{
   var pnodes = document.getElementsByClassName("rowcell Secret3");
   for ( var i = 0; i < pnodes.length; i++ )
   {
      var childs = pnodes[i].getElementsByTagName( "div" );
      var left  = childs[0];
      var right = childs[1];
      left.style.display  = left.style.display  == "block" ? "none" : "block";
      right.style.display = right.style.display == "block" ? "none" : "block";
   }
   var ev = getEvent();
   return false;
}
';
}

$head += @"
/*
-------------------------------------------------------
Runs correctly only for ANSI encoding
PShell code sets ascii encoding provided other one
was used.
Code logic:
1. list of the current setting keys is compared with
   the same keys in the ini-file
2. INI-file string are selected in the loop from the
   last one to the top one.
3. As soon as a key from the input list is compared
   with a key in INI-file, this key id deleted from
   the list regardless results of the values comparison.
4. Loop is terminated as soon as an input list became empty.
List of the input keys names is hard-coded but can easily
became an input argument.
-------------------------------------------------------
*/
function SaveSettings()
{
   var ev = getEvent();
   var rk = [];
   function Repl( line, ov, nv )
   {
      var p = line.indexOf( "=" ) + 1;
      var l = line.substr( 0, p );
      var r = line.substr( p ).replace( ov, nv );
      return l + r;
   }
   function addRK( keyn )
   {
      rk[rk.length] = keyn;
      return rk.length;
   }
	var fso  = new ActiveXObject( "Scripting.FileSystemObject" );
   var path = location.pathname.substr( location.pathname.indexOf( ":" ) - 1 );
   var fn   = fso.GetFileName( path );
	var inif = path.replace( fn, "GetBuildsHistory.ini" );

	var fin  = fso.OpenTextFile( inif, 1 );
   var content = fin.ReadAll().replace( /\r/g, "" ).split( "\n" );
   fin.Close();
   
   var tl = TEXTLOG;
   var pk = PRODUCTKEY;
   var cl = currentLang.toLowerCase();
   var at = activeTheme.toLowerCase();

   var line, ll, key, v, nc = 0;
   var keys = "textlog,theme,lang,productkey".split(",");
   var nlines = content.length;
   
   for( var i = content.length - 1; i >= 0; i-- )
   {
      line = content[i];      
      line = line.split("#")[0].strip();
      if ( line == "" 
      ||   line.indexOf( "=" ) == -1 ) continue;
      ll   = line.split( "=" );
      line = content[i];
      key  = ll[0].strip().toLowerCase();
      ov   = ll[1].strip();
      v    = ov.toLowerCase();
      var dk = -1;

      for ( var j = 0; j < keys.length; j++ )
      {
         if ( keys[j] == key )
         {
            switch( key )
            {
               case "textlog":    if ( v != tl ) { content[i]=Repl( line, ov, tl ); nc=addRK(key); } break;
               case "lang":       if ( v != cl ) { content[i]=Repl( line, ov, cl ); nc=addRK(key); } break;
               case "theme":      if ( v != at ) { content[i]=Repl( line, ov, at ); nc=addRK(key); } break;
               case "productkey": if ( v != pk ) { content[i]=Repl( line, ov, pk ); nc=addRK(key); } break;
            }
            dk = j; 
            break;
         }
      }
      if ( dk > -1 ) keys.splice( dk, 1 );
   }
   // add keys which were absent in INI-file or incorrectly defined
   for ( var j = 0; j < keys.length; j++ )
   {
      switch( key )
      {
         case "textlog":    { content[content.length] = "textlog="    + tl; nc=addRK(key); } break;
         case "lang":       { content[content.length] = "lang="       + cl; nc=addRK(key); } break;
         case "theme":      { content[content.length] = "theme="      + at; nc=addRK(key); } break;
         case "productkey": { content[content.length] = "productkey=" + pk; nc=addRK(key); } break;
      }
   }
   if ( nc )
   {
      fin  = fso.OpenTextFile( inif, 2 );//Write( out );
      var out = content.join( "\n\r" );
      fin.Write( out );
      fin.Close(); 
      var msg = LangStrings[ currentLang ].FileUpdated.replace( "%fn%", inif );
      for ( var i = 0; i < rk.length; i++ )
      {
         msg += "\n" + rk[i]; 
      }
      alert ( msg );
   }
   hideMenuContent();
   return false;
}
/*
-------------------------------------------------------
Step 1: array of the indexes corresponding to the
        visible columns is created together with an
        arrays of the column names, max-width ( in chars ),
        and alignments. At the end of the loop, names 
        array is used to prepare and output header line.
Step 2: Loop on the visible columns prepared on the Step 1
        is executed in the loop on the rows.
Task-dependance is in handling ( Secret3, Secret4 ) in
Narrow mode.
-------------------------------------------------------
*/
function MainTableToText()
{
   function formatAndJoin( arr, lengs, aligns )
   {
      var out = "", el, ln, al;
      for ( var i = 0; i < arr.length; i++ )
      {
         el = arr[i];
         ln = lengs[i];
         al = aligns[i];
         el = ( al == "left" ) ? el.left( ln ) : el.right( ln );
         out += el + "  ";
      }
      return out + '\n';
   }
	var fso   = new ActiveXObject( "Scripting.FileSystemObject" );
	var path  = location.pathname.substr( location.pathname.indexOf( ":" ) - 1 );
   var outp  = path.replace( ".hta", currentV+".log" );
   var out   = ""; 
   var MTHNames = MTHeader.getElementsByTagName("div");

   var cols     = MTHNames;
   var names = [], lengs = [], aligns = [], indxes = [], row, classn, al;
   var list = "." + NamesObj.Column0Name + "," + ViewLists[ currentV ];
   var ncols = list.split( "," ).length;
   for ( var i = 0; i < cols.length; i++ )
   {
      classn = cols[i].className.replace( "hdrcell ", "." );
      if ( ! classn ) continue; // do no understand what happens BUT happens after
      if ( list.indexOf( classn ) == -1 ) continue;   
      indxes[ indxes.length ] = i;     
      al = cols[i].style.textAlign   ? cols[i].style.textAlign : 
      cols[i].currentStyle.textAlign ? cols[i].currentStyle.textAlign : "undef"; 
      if ( ( UseNarrow || ScreenWidth < 1400 ) 
      &&   currentV == "V3" && classn == ".Secret3" )
      {
         aligns[ aligns.length ]="left"; lengs[ lengs.length ]=64; names[ names.length ]="Secret3";
         aligns[ aligns.length ]="left"; lengs[ lengs.length ]=64; names[ names.length ]="Secret4";
         break;
      }
      aligns[ aligns.length ] = al;
      colnam = cols[i].innerText.strip();
      names[ names.length ] = colnam;
      lengs[ lengs.length ] = NamesObj[ colnam ];
      --ncols;
      if ( ! ncols ) break;
   }

   out += formatAndJoin( names, lengs, aligns );

   tmp = MTHRows;

   for ( var i = 0; i < tmp.length; i++ )//
   {
      row = tmp[i].getElementsByTagName("div");
      var data = [];

      for ( var k = 0; k < indxes.length; k++ )
      {
         var j = indxes[k];
         if ( ( UseNarrow || ScreenWidth < 1400 ) 
         &&   currentV == "V3" && names[ k ] == "Secret3" )
         {
            var childs = row[j].getElementsByTagName("span");
            data[ data.length ] = childs[0].innerText.strip();
            data[ data.length ] = childs[1].innerText.strip();
            break;
         }
         data[ data.length ] = row[j].innerText.strip();
      }
      out += formatAndJoin( data, lengs, aligns );
   }
   var fut = fso.CreateTextFile( outp, true );
   fut.Write( out );
   fut.Close();
   var msg = LangStrings[ currentLang ].FileCreated.replace( "%fn%", outp );
   hideMenuContent();
   alert ( msg );
   return false;
}

function Logger()
{
   var dbgdata = [];
   this.count  = 0;
   this.putLog = function( data )
   {
      dbgdata[ dbgdata.length ] = data;
      this.count = dbgdata.length;
      return dbgdata.length;
   }
   this.saveLog = function()
   {
      var fso  = new ActiveXObject( "Scripting.FileSystemObject" );
      if ( ! this.count ) return false;
      var fut  = fso.CreateTextFile( ".\\Debug.log", true );
      for ( var i = 0; i < dbgdata.length; i++ )
      {
         fut.WriteLine( dbgdata[ i ] );
      }
      fut.close();
      return false;
   }
}

var log = new Logger();
// log methods:
// log.putLog( data )
// log.saveLog()

var scrollActive = false;
var scrollTimer  = 0;
var scrollCount  = 0;
var timeout      = 300;
var scrollStartTimestamp = null;
var MTHeader     = null;
var Expandable   = null;
var MTHRows      = null;
var MTHeaderTop  = null;

function fixTop(e)
{
   ++scrollCount;
   var e  = e || window.event;
   var eu = typeof( e ) == "undefined";
   if ( ! scrollActive && ! eu )
   {
      scrollActive = true;
      scrollStartTimestamp = e.timeStamp;
      scrollTimer  = setTimeout( function(e){return fixTop(e);}, timeout );
   }
   else if ( ! scrollTimer && ! eu )
   {
      scrollTimer = setTimeout( function(e){return fixTop(e);}, timeout );
   }
   else if ( eu )
   {
      scrollActive = false;
      while ( scrollTimer )
      {
         scrollTimer = clearTimeout( scrollTimer );
      }

      var ScrollTarg = Expandable;
      var MTHRows  = ScrollTarg.getElementsByClassName( "mr rowcell" );
      var hdrrect  = MTHeader.getBoundingClientRect();
      var hdrbot   = hdrrect.bottom;

      ScrollTarg.onscroll = function(){return false;};

      var line1r   = MTHRows[0].getBoundingClientRect();
      var i = Math.round( ( hdrbot - line1r.top ) / line1r.height );
      var j = i;
      if ( i > 0 ) j--;

      for ( i = j; i < MTHRows.length; i++ )
      {
         var rect = MTHRows[i].getBoundingClientRect();
         if ( rect.bottom - hdrbot > 1 && rect.top < hdrbot )
         {
            MTHRows[i].scrollIntoView(true);
            break;
         }
      }

      ScrollTarg.onscroll = function(e){return fixTop(e);};
      return false;
   }
   return false;
}

window.onload = function()
{
   var loaded = new Date();
   setView( "V1" );
   MTHeader   = document.getElementById( "V1topBar" );
   Expandable = document.getElementById( "V1expandable");
   MTHRows    = Expandable.getElementsByClassName( "mr rowcell" );
   MTHeaderTop = MTHeader.offsetTop;
   
   function setMenuItemsOnClick()
   {
      var t;
      t = document.getElementById("menubtn_file_content").getElementsByTagName("div");
      t[0].onclick = function(){return SaveSettings();};
      t[1].onclick = function(){return MainTableToText();};
      t[2].onclick = function(){return closeAllWindows();};  
      t = document.getElementById("menubtn_view_content").getElementsByTagName("div");
      t[0].onclick = function(){return setView("V1");};
      t[1].onclick = function(){return setView("V2");};
      t[2].onclick = function(){return setView("V3");};
      
      t = document.getElementById("menubtn_theme_content").getElementsByTagName("div");        
      for ( var i = 0; i < t.length; i++ )
      {
         t[i].onclick = function(){return setTheme(this);};
      } 
  
      t = document.getElementById("menubtn_lang_content").getElementsByTagName("div");
      for ( var i = 0; i < t.length; i++ )
      {
         t[i].onclick = function(){return setLang(this);};
      }

      if ( ScreenWidth < 1400 || UseNarrow )
      {
         t = document.getElementsByClassName("rowcell Secret3");
         var cld;
         for ( var i = 0; i < t.length; i++ )
         {
            cld = t[i].getElementsByTagName( "div" );
            cld[0].style.cssText = "float:left;display:block;";
            cld[1].style.cssText = "float:right;display:none;";
         }
      }
      return false;
   }
   var ev = getEvent();
   if ( ScreenWidth < 1400 || UseNarrow )
   {
      window.resizeTo( 1100, 760 );
   }
   else
   {
      window.resizeTo( 1380, 800 );
   }
   document.onkeydown  = function(){return closePopUps();}
   // Assign onclick handlers for menu items;
   var o, id, items = ["file","view","theme","lang","edit"];
   for ( var i = 0; i < items.length; i++ )
   {
      id = "menubtn_" + items[i];
      o = document.getElementById( id ).parentNode;
      o.onclick = function(o){return showMenuContent(o);}
   }

   document.body.onclick = function(e)
   {
      var Event = getEvent();
      return hideMenuContent();
   }
   var t = document.getElementsByClassName( "mr rowcell" );
   for ( var i = 0; i < t.length; i++ )
   {
      t[i].onclick = function(){return ShowDetails(this)};
   }
   setMenuItemsOnClick();
   implementLangStrings();
   setLang( currentLang );
   setTheme( activeTheme );
   document.body.onbeforeunload = function()
   {
      if ( log.count ) log.saveLog();
      return closeAllWindows();
   }

   document.getElementById("V1expandable").onscroll = function(e){return fixTop(e);};
   // add one timestamp 
   var tt = document.getElementById("RunStamps").getElementsByTagName("tbody")[0];
   var bv = timeStamp();
   tt.innerHTML = tt.innerHTML + "<tr><td>&nbsp;"+bv+"&nbsp;</td>"+
   "<td>&nbsp;&nbsp;Became visible</td></tr>";
 
   // following function was used for debugging.
   function tester()
   {
      function offsets( o )
      {
         var rect = o.getBoundingClientRect();
         return "offTop="+o.offsetTop + ", offHeight="+o.offsetHeight+
         ", rect(top,bottom,height)=("+rect.top + ", "+rect.bottom+", "+rect.height + ")"; 
      }
      var MTHeader = document.getElementById( "V1topBar" );
      var ScrollTarg = document.getElementById( "V1expandable");
      var MTHRows  = ScrollTarg.getElementsByClassName( "mr rowcell" );
      log.putLog( "--- Header line properties ---" );
      log.putLog( offsets( MTHeader ) );
      log.putLog( "--- Lines properties ---" );
      
      for ( var i = 0; i < 10; i++ )
      {
         log.putLog( offsets( MTHRows[i] ) );
      }
      var obj = document.getElementById( "menubtn_lang_content" );
      log.putLog( "--- menubtn_lang_content properties ---" );
      log.putLog( offsets( obj ) );
      var childs = obj.getElementsByTagName("div");
      for ( var i = 0; i < childs.length; i++ )
      {
         log.putLog( offsets( childs[i] ) );
      }
      obj = document.getElementById("MenuContainer");
      log.putLog( "--- MenuContainer properties ---" );
      log.putLog( offsets( obj ) );
      var m1, m2, ids= ["MenuContainer","MainContainer","Main","V1tablecontainer","V1expandable"];
      for ( var i = 0; i < ids.length; i++ )
      {
         m1 = document.getElementById("MenuContainer");
         m2 = m1.getBoundingClientRect();
         log.putLog( ids[i]+ " offsetWidth="+m1.offsetWidth+", rectW="+m2.width );
      }
      m1 = document.getElementsByClassName("mr rowcell")[0];
      m2 = m1.getBoundingClientRect();
      log.putLog( "mr rowcell offsetWidth="+m1.offsetWidth+", rectW="+m2.width );
      m1 = document.getElementById( "MenuContainer" );
      log.putLog( "MenuContainer offsetWidth="+m1.offsetWidth+", m1.offsetHeight="+m1.offsetHeight );
   }
   //tester();
}
"@;

$head = GetRidOfBlanks( $head );# get rid of blanks BUT KEEP \n

## Encodings: Unicode, UTF8, UTF32, Ascii
$nbld  = $temp.Length;
$nupg  = $nbld - 1;
$date1 = $temp[ 0 ].InstallDateString;
$date2 = $temp[ $temp.Length - 1 ].InstallDateString;
$langs = BuildJS;

$head += @"
`n`r$langs
var NUpgrades=$nupg;
var date1="$date1";
var date2="$date2";
var lang;
for(var i = 0; i < LangsPresent.length; i++ )
{
   lang=LangsPresent[i];
   LangStrings[lang].Title=LangStrings[lang].Title.replace("%NN%",NUpgrades);
   LangStrings[lang].Title=LangStrings[lang].Title.replace("%date1%",date1);
   LangStrings[lang].Title=LangStrings[lang].Title.replace("%date2%",date2);
   LangStrings[lang].Tooltip=LangStrings[lang].Tooltip.replace(/,/g,'\n');
}
// set lang value to system language
lang=(window.navigator.userLanguage||window.navigator.language).substr(0,2).toLowerCase();
function implementLangStrings()
{
   document.getElementById("V1topBar").title = LangStrings[lang].Tooltip;
   document.getElementsByTagName("title")[0].innerText = LangStrings[lang].Title; 
   var langMenuItems = document.getElementById("menubtn_lang_content").getElementsByClassName("menudata");
   for ( var i = 0; i < langMenuItems.length; i++ )
   {
      var o = langMenuItems[i];
      var t = o.innerText;
      var l = t.substr( 1 + t.indexOf( "(" ), 2 ).toLowerCase();
      if( LangStrings[l] ) o.innerText += LangStrings[l].NativeName;
   }
}
function setLang( lang )
{
   var ev = getEvent();
   if ( typeof( lang ) == "object" )
   {
       lang = lang.childNodes[0].data.substr( 2, 2 ).toLowerCase();
   }
   document.getElementById("V1topBar").title = LangStrings[lang].Tooltip;
   document.getElementsByTagName("title")[0].innerText=LangStrings[lang].Title;
   currentLang = lang;// global variable
   var l = LangStrings[lang], t;
 
   document.getElementById("menubtn_file").childNodes[0].data = l.File;
   document.getElementById("menubtn_view").childNodes[0].data = l.View;
   document.getElementById("menubtn_theme").childNodes[0].data = l.Theme;
   document.getElementById("menubtn_lang").childNodes[0].data = l.Language;
   document.getElementById("menubtn_edit").childNodes[0].data = l.Edit; 

   t = document.getElementById("menubtn_file_content").getElementsByTagName("div");
   t[0].childNodes[0].data = l.SaveSettings;
   t[1].childNodes[0].data = l.SaveView;
   t[2].childNodes[0].data = l.Exit;
  
   t = document.getElementById("menubtn_view_content").getElementsByTagName("div");
   t[0].childNodes[0].data = l.Default;

   t = document.getElementById("menubtn_theme_content").getElementsByTagName("div");
   for ( var i = 0; i < t.length; i++ )
   {
      t[i].childNodes[0].data = l[ t[i].id ];
   }
   hideMenuContent();
   return false;
}
</script></head>
"@;

$head | Set-Content -Encoding utf8 .\$LogFN.hta; ### Created header of the HTA-file
# Create Empty.html
"<html><head></head><body></body></html>" | Set-Content -Encoding utf8 .\empty.html;

$t = "History contains $nupg upgrades since $date1 till $date2";
Set-Variable -Name Title -Scope Script -Value $t;
$RunLog = [string[]]@("$Title$NL");

$TimeStamps += TimeStamp( "Builds objects array is ready to be logged" );

if ( $TEXTLOG -eq 1 )
{
   $RunLog += BuildTextLog( $temp ); ### create full log
   $RunLog += "$NL";
   $TimeStamps += TimeStamp( "Text log creation is finished" );
}

if ( Test-Path .\out.xml ){ Remove-Item .\out.xml -Force }
$temp | Select $AllProperties | Export-Clixml -Path .\out.xml;
if ( Test-Path .\$LogFN.xml ){ Remove-Item .\$LogFN.xml -Force }
Rename-Item -Path ".\out.xml" -NewName ".\$LogFN`.xml";
$TimeStamps += TimeStamp( "XML creation is finished" );

BuldHTML( $temp ) | Add-Content .\$LogFN.hta;

if ( $TEXTLOG -eq 1 )
{
   $TimeStamps += TimeStamp( "HTML creation is finished" );
   $RunLog | Set-Content -Encoding ascii .\$LogFN.log;
}

& .\$LogFN.hta; # run HTA

<#
--------------------------------------------------------------------------------------------
HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SoftwareProtectionPlatform -
DefaultProductKeyBackup + a lot of othe usefull names and data in the blob
See also sku, SkuId, and some other ids in setupact.logs
--------------------------------------------------------------------------------------------
if ($items.$architecture.SetupESDs -is [system.array])
$sw = [System.Diagnostics.Stopwatch]::StartNew();
[long]$secselapsed = [long]($sw.elapsedmilliseconds.ToString())/1000; 
$sw.Stop(); 
$sw.Reset();
#>