<#
--------------------------------------------------------------------------------- 
Project: BuildsHistory                                               
Version: 1.0                                                         
FileId:  f:\Delme\CleanBCD\BuildsHistory                             
When:    October 10, 2016,  Monday,  09:28, Windows build 14942                             
©        Oleg Kulikov, sysprg@live.ru                                                                                          
--------------------------------------------------------------------------------- 
This is PShell version of the BuildsHistory.js which was finished at
October 7, 2016, some hours before Build 14942 became available at WU servers.
--------------------------------------------------------------------------------- 
10.0.14393.321
[MAJOR VERSION].[MINOR VERSION].[BUILD NUMBER].[REVISION NUMBER]
---------------------------------------------------------------------------------
ESD/ISO names structure
<build>.<revision>.<architecture>.<branch>.<timestamp>_<skufamily>_<sku>_<language>.ESD
8250.0.amd64chk.winmain_win8beta.120217-1520_client_professional_en-us.iso
---------------------------------------------------------------------------------
2016.12.11 Set encoding UNICODE to enable opportunity to handle Russian strings
TicksToFileTime and TicksToString functions implemented
File c:\$WINDOWS.~BT\Sources\SetupPlatform.ini contains timestamps in ticks which
can be read and analyzed.
--
Monday,   December 12, 2016 23:21:00
Function Show is excluded as XML and HTA are created. But it appereared that
XML Export decides that obj.InstallDate, obj.InstallTime, obj.UpgradeDate
are integers despite these properties were already converted to strings and
Show log, HTA demonstrate it. Thus it is necessary to change type of these
data in the AddProperties function.
--
Tuesday, December 13, 2016. Have splitted source on 3-parts: 
Utils.ps1    - collection of project independent functions
GBHUtils.ps1 - BuildsHistory functions. Former Show function was renamed
to BuildTextLog and included into GBHUtils.ps1 with some changes according
to 3 new properties defined and with exclusion of the FormatNumber calls as
this function is called from AddProperties.
GetBuildsHistory.ps1 - this one.
Created 3 new properties: InstallDateS, InstallTimeS, UpgradeDateS which
are renamed to the same without trailing 'S' in the text-log and in HTA.
These properties are not exporeted into XML.
All of the code from the loop in Main section which was run AFTER call
of the AddProperties, were moved into the AddProperties.
Improved Details presentation by changes in GBHUtils.
--
Wednesday, December 14, 2016. Well, HTA is started by the last line
of this code. GBHUtils have improved footer line.
Saturday, December 17, 2016. GBHColorSchemes.ps1 implemented. All color
styles are placed now in the body Style tag. JS code can now change
ColorSchemes replacing innerHTML of that Style tag.
--
Wednesday, December 22, 2016. All problems with implementing toolbar
was fixed and Color Theme selection runs fine.
--
Friday, December 23, 2016. INI-file changed: some new sections were
implemented and commented. PLAN: create and implement ASAP Views to
edit and TEST color scheme parameters ( colors ) and GEOMETRY which
strongly depends on the language selection for non-latin alphabeth languages.
Remove all the native language strings from the PShell code to INI-file
and JS-code which HAS NO problems with keeping and handling Unicode strings.
HAD to finish till NY.
--
Saturday, December 24, 2016. 17:23. Color inversion for HOVER items enabled as 
in Toolbar as in Maintable. The same border color is used for MainTable header,
footer and data rows -> one color less. But minor problems:
1. header borders are 1-2 pixels left of those of data rows
2. for the toolbar HOVER items only text content gets necessary color
3. toolbar has no border at all though SHOULD HAS.
4. Yet don't know which width toolbar should have: MainTable WITH or WITHOUT
   scrollbar. Seems better WITH scrollbar width but what about toolbar 
   border in this case?
--
Monday, January 09, 2017. Current Build number is still 14986 but can be
changed this week. What was implemented, improved since December 24:
1. color-picker page ( color.html ) was created but is not yet ready to
   change colors of the parent page;
2. drevolaz had to be rewritten
3. due to 1 & 2, Debugger item in menu is shown as disabled
4. One main color is used now
5. Details are presented in popup window.
 
What is not yet implemented:
1. Onload update of the Language strings and usage of those strings in HTML DONE
2. Saving of the current view as a text                                     DONE
3. additional views.
4. Reading & using previously created XML
5. Some more themes.                                                        DONE
6. background URL / Image support
Item 1 - is implemented for the titles and tooltip which is also a title :)
language selection runs fine though got a lot of time and required creation
of an external JS-code which has encoding Unicode. 
Have saved two of the sources which were in encoded Unicode as ascii.
--
Wednesday, January 11, 2017, Build 15002 was issued at Monday, had to finish
this week. New plans:
1. Ini-file editor in a new window.
2. DIAGCAB instead of cmd-file!
3. Additional views.
--
Saturday, January 14, 2017. Today got at last WHY generated HTA runs fine when
is generated and run from GetHistory.cmd and IE returns NULL from window.open
if generated HTA is clicked or even generated and run from the PShell console
with . .\GetBuildsHistory. It appeared that IE returns correct window handler
provided HTA is runned with administrator privileges and returns NULL otherwise.
Besideshave splitted GetBuildsHistory.ini to two files: GetBuildsHistory.ini which
is ascii-encoded and contains only settings + GetBuildsHistory.Lang.txt which
is encoded UNICODE and contains Language string only. 2nd one is read by PShel and
on base of it's content, JS langStrings object is built and written into the
HTA header together with CSS and othe JS code. Today all runs fine and it is clear
what should be done:
1. Save current settings function.
2. Edit Timezones function.
3. Additional views.
--
Monday, January 16, 2017, 03:00. V2, second view - runs nearly fine.
--
Tuesday, January 17, 2017. All three views runs fine including V3
with Unknown3/Unknown4 visibility switching. Well, postponing some
planned Editors ( colors, TimeZones, Drevolaz ) the only code which need
to be fixed today is "Save current settings" function.
have changed Black -> #999 for the borders in my own themes and improved Orange
Good day:
1. INI-file editor WAD
2. PShell detects INI-file Encoding and rewrites in encoding ASCII if necessary
3. PShell creates INI-file with default settings and system Language if
   INI-file was absent
4. TRY/Catch implemented to prevent "The RPC server is unavailable"
5. Unknown3/Unknown4 swinching view
6. Save as file for V3
7. Have improved styling ( font-family ) for Unknown1,...,Unknown4
Thus had to:
add Lang strings for some Menu items and enable JS-code to support them
--
Wednesday, January 18, 2017. Localization finished, Debug item in menu
replaced by disabled Edit-item, ReadMe-document nearly finished BUT one more
item yet not is not implemented: reading of the XML-files created at the 
previous builds and including of the properties from these builds into the
current collection. Thus starting implementaion.
--
Thursday, January 19, 2017. Have published at nearly 19:00. Have added version
into the copiright string, implemented reading of the old XML-files, fixed
a bug in file names definition: I've hardcoded my R500D for all instead of
$env:computername. Reading of XMLs need to be somewhat improved. Have started
but when looked at the time then decided to postpone this code as new build
can appear today and improvement can be postponed till tomorrow. Besides
it is necessary to write second part of the README with description of the 
properties.
-----------------------------------------------------------------------------
#>
. '.\GBHUtils.ps1'        # Load collection of the project functions

<#
if ($items.$architecture.SetupESDs -is [system.array])
$sw = [System.Diagnostics.Stopwatch]::StartNew();
[long]$secselapsed = [long]($sw.elapsedmilliseconds.ToString())/1000; 
$sw.Stop(); 
$sw.Reset();
#>  
#----------------- Define and set some variables with a Global scope ---------------------------
$version = "1.021.15014"; 
Set-Variable Version -Scope Global -Value $version;                                                                                         
$p = "HARDWARE\DESCRIPTION\System\MultifunctionAdapter\0\DiskController\0\DiskPeripheral\0\";  
$Disk1 = ( get-itemproperty -path HKLM:\$p ).Identifier;                            
Set-Variable DiskId    -Scope Global -Value $Disk1; 

$p  = "SOFTWARE\Microsoft\Windows NT\CurrentVersion";
$cv = ( get-itemproperty -path HKLM:\$p ).CurrentBuild;
Set-Variable CurrentBuild -Scope Global -Value $cv;
$cn = $env:computername.Replace(" ", "_");
Set-Variable LogFN     -Scope Global -Value "$cn$cv"; 

$arr = @();
Set-Variable CompInfo  -Scope Global -Value $arr;
Set-Variable RunLog    -Scope Global -Value $arr;
Set-Variable TimeZones -Scope Global -Value $arr;
Set-Variable TimeZoneDefs -Scope Global -Value $arr;

$dt   = get-date;
$zone = "{0:zzz}" -f $dt;
Set-Variable CurrentTIMEZONE -Value $zone -Scope Global;
$dw   = "{0:x}" -f ( FiletimeToDWDate( $dt.ToFileTime() ) );
Set-Variable StartTime -Scope Global -Value $dw;
$seconds = ( zone2seconds( $CurrentTIMEZONE ) ).ToString();
Set-Variable CurrentTIMEZONESeconds -Value $seconds -Scope Global;

$p = "SOFTWARE\Microsoft\WindowsSelfHost\Applicability";
$p = ( get-itemproperty -path HKLM:\$p ).IsBuildFlightingEnabled;

Set-Variable IsInsider -Scope Global -Value $p;
Set-Variable LANG      -Scope Global -Value "en";
Set-Variable THEME     -Scope Global -Value "flowers";
Set-Variable INILog    -Scope Global -Value $arr; 

[string]$n = ([char]0x0d)+([char]0x0a);  
Set-Variable -Name NL -Scope Global  -Value $n;

$CompInfo = GetCompInfo;
<#
--------------------------------------------------------------
Reading and parsing INI-file if it is present in the current
directory: GetBuildsHistory.ini should be created in the
directory in which GetBuildsHistory.ps1 resides.
--------------------------------------------------------------
#>
$fn = "GetBuildsHistory.ini";### Current path is supposed
if ( Test-Path $fn )
{

   $config = GetIniSettings;
   $TimeZoneDefs = @();
   $inSettings = $false;
   for( $i = 0; $i -lt $config.Length; $i++ )
   {
      $line = $config[$i].trim().ToLower();
      if ( $line -eq "[settings]" )
      {
         $inSettings = $true;
         break;
      }     
   }
   $j = $i + 1;
   for( $i = $j; $i -lt $config.Length; $i++ )
   {
      $line = $config[$i];
      if ( ! $line.trim() ){continue;}
      $ll   = $line.ToLower();     
      if ( $inSettings )
      {
         if( $ll.IndexOf( "=" ) -eq -1 ) 
         {
            $INILog += "Incorrect statement: |$line|";
            continue;
         }
         $val = ( $ll -split "=" )[1].trim(); 
         if ( $ll.StartsWith( "timezone." ) )     
         { 
            $val = ParseTimeZoneDefinition( $line );
            if ( $val )
            {
               $TimeZoneDefs += $val;
            }
            else
            {
               $INILog += "Incorrect TimeZone Definition: $line";
            }
         }
         elseif ( $ll.StartsWith( "textlog" ) )
         {
            if ( $val -match "[01]" -and [int]$val -le 1 )
            {
               Set-Variable TEXTLOG -Scope Global -Value [int]$val;
               $INILog += "TEXTLOG assigned value $val"
            }
            else
            {
               $INILog += "Incorrect TEXTLOG value: $val";
            }
         }
         elseif ( $ll.StartsWith( "lang" ) )
         {
            if ( $val.Length -eq 2 -and $val -match '[a-zA-Z]' )
            {
               Set-Variable LANG -Scope Global -Value $val;
               $INILog += "LANG assigned value $LANG";
            }
            else
            {
               $INILog += "Incorrect language definition: $line";
            }
         }
         elseif ( $ll.StartsWith( "productkey" ) )
         {
            if ( $val -match "[01]" -and [int]$val -le 1 )
            {
               Set-Variable PRODUCTKEY -Scope Global -Value $val;
               $INILog += "PRODUCTKEY assigned value $val"
            }
            else
            {
               $INILog += "Incorrect value for the productkey: $val";
            }
         }
         elseif ( $ll.StartsWith( "theme" ) )
         {
            $supported = @("flowers","black","green","blue","brown","orange");
            $color = "Flowers";
            for ( $j = 0; $j -lt $supported.Length; $j++ )
            {
               if ( "$val" -eq $supported[$j] )
               {
                  $color = $val.Substring( 0, 1 ).ToUpper() + 
                  $val.Substring( 1 ).ToLower();
                  break;
               }
            }
            if ( $j -eq $supported.Length )
            {
               $INILog += "Incorrect value for the theme: $val";
            }
            Set-Variable THEME -Scope Global -Value "$color";
            $INILog += "THEME assigned value $THEME"
         }
      }#End-Of-If-inSettings;   
   }#End-Of-For-Config-lines-Loop;
}#End-Of-if(Test-Path $fn);
else
{
   Set-Variable TEXTLOG -Scope Global -Value 0;
   $syslang = (get-culture).Name.Substring( 0, 2 );
   Set-Variable LANG    -Scope Global -Value $syslang;
   Set-Variable THEME   -Scope Global -Value "Flowers";
   Set-Variable PRODUCTKEY -Scope Global -Value 0;
   $ini = @(
   "[settings]$NL"
   "productkey = 0   # 0 - show partial key, 1 - show full key$NL"
   "textlog    = 0   # 1 - create full text log, 0 - omit creation$NL"
   "lang       = $LANG  # en,ru,uk,ge$NL"
   "theme      = $THEME # flowers,black,blue,green,brown,orange$NL"
   );
   $ini | Set-Content -Encoding "Ascii" .\GetBuildsHistory.ini;
}
if ( $INILog.length )
{
   $INILog | Set-Content -encoding "ascii" .\GetBuildsHistory-INI-parse.log;
   $INILog = @();   
}
#----------------------End-of-Globals-----------------------------

<#
---------------------------------------------------------------------------------
Function receives Builds object and return string presenting 
ProductKey or 5 groups of "BBBBB" separated by dash.
November 23, 2016. Adopt version of the same function which is used in
\!Projects\ProductKey\ShowProductKey.ps1
---------------------------------------------------------------------------------
#>
Function GetProductKey( $obj )                                                    
{                                                                                           
   function DecryptWindowsKey( [byte[]]$ByteArray )
   {              #0-9abcdef01234567
      $TrTable = "BCDFGHJKMPQRTVWXY2346789"
      $TrTabL  = $TrTable.Length;
      $RawData = $ByteArray;
      $Last    = $RawData.Length - 1;
      
      [bool]$isWin8 = ( ( $RawData[ $Last ] -shr 3 ) -band 1 );                                                           
      $RawData[ $Last ] = $RawData[ $Last ] -band 0xF7; 
       
      $PK = "";                                                                                    
      for ( $i = $TrTabL; $i -ge 0; $i-- )                                                                   
      {                                                                                                 
         $TrTabIndex = 0;                                                                                        
         for ( $j = $Last; $j -ge 0; $j-- )                                                                
         {
            $TrTabIndex = $TrTabIndex -shl 8 -bxor $RawData[ $j ];                                                      
            $RawData[ $j ] = [Math]::Truncate( $TrTabIndex / $TrTabL );            
            $TrTabIndex = $TrTabIndex % $TrTabL            
         }                                                                                              
         $PK = $TrTable[ $TrTabIndex ] + $PK;                                                                    
      }                                                                                                                                                                                        
                                                                                                        
      if ( $isWin8 )                                                                              
      {
         $i = $TrTable.indexOf( $PK.Substring( 0, 1 ) );                                                                                                                                       
         $PK = $PK.Substring( 1 ).Insert( $i,'N' );                                                                                  
      }                                                                                                 
                                                                                                        
      return "" +`                                                                                      
             $PK.Substring(  0, 5 ) + "-" +`                                                            
             $PK.Substring(  5, 5 ) + "-" +`                                                            
             $PK.Substring( 10, 5 ) + "-" +`                                                            
             $PK.Substring( 15, 5 ) + "-" +`                                                            
             $PK.Substring( 20, 5 );                              
   }#End-of-DecryptWindowsKey 
   
   return DecryptWindowsKey( $obj.DigitalProductId[52..66] );  
}#-end-of-GetProductKey

<#
-------------------------------------------------------------------------
Fuction is called after an array of the objects is already sorted.
Function creates some properties for the objects returned from the
Registry. It also changes some propeties values. 
-------------------------------------------------------------------------
#>
function AddProperties( [pscustomobject]$o )
{
   $Global:thisObj = $o;
   function ByteArrayToString( [byte[]]$arr )
   {
      return ([char[]]$arr -join "").Replace( "`0", "" );
   }
   function GetProductId3( [byte[]]$arr ) 
   {
      $d   = ByteArrayToString( $arr ); 
      $t   = $d.split( "-" )[ 7 ];
      $day = [int]$t.Substring( 0, 3 ) - 1;
      $dat = [datetime]( "01/01/" + $t.Substring( 3 ) );
      $t   = (Get-Date $dat).AddDays( $day ).ToString( "ddd, dd.MM.yyyy" );
      $l   = "55041-01781-051-124375-01-1033-10049.0000-0902015".Length;
      return "{0,-$l} ({1})" -f $d, $t; 
   }
   function GetBuildLabExDate( $str )
   {  # 9600.17668.amd64fre.winblue_r8.150127-1500
      $dt = $str.split( "." )[4];
      $dt = $dt.Substring( 4, 2 ) + "." + $dt.Substring( 2, 2 ) + "." +`
      "20" + $dt.Substring( 0, 2 ) + " " + $dt.Substring( 7, 2 ) + ":" +`
      $dt.Substring( 9, 2 ) + ":00";
      return ( get-date $dt ).ToString( "ddd, dd.MM.yyyy" );
   }
   function ArrayToHexString( $a )
   {
      return [System.BitConverter]::ToString( $a ).Replace( "-", "" );
   }
   function GetXML-Path( $n )
   {
      $cn = $env:computername.Replace(" ", "_");
      $f1 = "$cn$n`.xml";
      $f2 = "R500D$n`.xml";
      $fn = "";
      if (    Test-Path $f1 ) {$fn=$f1;}
      elseif( Test-Path $f2 ) {$fn=$f2;}
      return $fn;
   }
   function AddPropsFromXML( $o )
   {
      $fn  = GetXML-Path( $o.CurrentBuild );

      if ( $fn )
      {
         $arr = Import-Clixml -literalpath .\$fn;
         $o1  = $arr[ $arr.Length - 1 ];
         if ( ! $o.ApplicationID )
         {
            Add-Member -InputObject $o -type NoteProperty -name ApplicationID -value "";
            Add-Member -InputObject $o -type NoteProperty -name ProductId4 -value "";
            Add-Member -InputObject $o -type NoteProperty -name ProductId5 -value "";
            Add-Member -InputObject $o -type NoteProperty -name DefaultProductKey -value "";
            $o.ApplicationID     = $o1.ApplicationID;
            $o.ProductId4        = $o1.ProductId4;
            $o.DefaultProductKey = $o1.DefaultProductKey;
            $o.ProductId5        = $o1.ProductId5;
         }
      }
      return $o;
   }
   Add-Member -InputObject $o -type NoteProperty -name Minutes            -value "";
   Add-Member -InputObject $o -type NoteProperty -name UpgradeDate        -value [int32]0;
   Add-Member -InputObject $o -type NoteProperty -name UpgradeDateString  -value "";
   Add-Member -InputObject $o -type NoteProperty -name UpgradeDateS       -value "";
   Add-Member -InputObject $o -type NoteProperty -name InstallDateString  -value "";
   Add-Member -InputObject $o -type NoteProperty -name InstallDateS       -value "";
   Add-Member -InputObject $o -type NoteProperty -name InstallTimeS       -value "";
   Add-Member -InputObject $o -type NoteProperty -name Description        -value "";
   Add-Member -InputObject $o -type NoteProperty -name ProductId2         -value "";
   Add-Member -InputObject $o -type NoteProperty -name ProductId3         -value "";
   Add-Member -InputObject $o -type NoteProperty -name LicensingProductID -value "";
   Add-Member -InputObject $o -type NoteProperty -name ProductKey         -value "";
   Add-Member -InputObject $o -type NoteProperty -name Unknown1           -value "";
   Add-Member -InputObject $o -type NoteProperty -name Unknown2           -value "";
   Add-Member -InputObject $o -type NoteProperty -name Unknown3           -value "";
   Add-Member -InputObject $o -type NoteProperty -name Unknown4           -value "";
   
   $o.ProductId2         = ByteArrayToString( $o.DigitalProductID[36..51] );
   $o.ProductId3         = GetProductId3(     $o.DigitalProductID4[008..108] );
   $o.LicensingProductID = ByteArrayToString( $o.DigitalProductID4[136..208] ); 
   $c = ByteArrayToString(                    $o.DigitalProductID4[0x3f8..0x46f] );
   $o.Description        = "Microsoft(R) Windows(R) Operating System, $c channel";
   $o.ProductKey         = GetProductKey( $o );

   $o.Unknown1 = ArrayToHexString( $o.DigitalProductId[0x048..0x050]  );
   $o.Unknown2 = ArrayToHexString( $o.DigitalProductId[0x0a0..0x0a3]  );
   $o.Unknown3 = ArrayToHexString( $o.DigitalProductId4[0x338..0x357] );
   $o.Unknown4 = ArrayToHexString( $o.DigitalProductId4[0x358..0x377] ); 
  
   if ( $o.PSPath.EndsWith( "CurrentVersion" ) )
   {
      $cv = "SOFTWARE\Microsoft\Windows NT\CurrentVersion";
      $p  = "$cv\SoftwareProtectionPlatform\GenuineApps\";
      $d  = ( get-childItem hklm:\"$p*" ).Name.Substring( "HKEY_LOCAL_MACHINE\$p".Length );
      Add-Member -InputObject $o -type NoteProperty -name ApplicationID -value $d;
      $Need = @( "ProductId", "DigitalProductId", "DigitalProductId4" );
      $od   = ( get-itemproperty HKLM:\"$cv\DefaultProductKey" -Name $Need );
      Add-Member -InputObject $o -type NoteProperty -name ProductId4 -value "";
      Add-Member -InputObject $o -type NoteProperty -name ProductId5 -value "";
      Add-Member -InputObject $o -type NoteProperty -name DefaultProductKey -value "";
      $o.ProductId4        = $od.ProductId;
      $o.ProductId5        = GetProductId3(     $od.DigitalProductID4[008..108] );
      $o.DefaultProductKey = GetProductKey( $od );      
   } 

   if ( [int]$o.CurrentBuild -lt 10122 )
   {
      $tmp = $o.BuildLabEx.split( "." );
      $ubr = $tmp[ 1 ];
      $bb  = $tmp[ 3 ];
      Add-Member -InputObject $o -type NoteProperty -name UBR -value $ubr;
      Add-Member -InputObject $o -type NoteProperty -name BuildBranch -value " $bb";
   } 
   if ( $o.InstallTime -eq $null )## BuildNumber less them 9841
   {
      Add-Member -InputObject $o -type NoteProperty -name InstallTime -value 1427802253;   
      $o.InstallTime = RegDWDateToFileTime( $o.InstallDate ); 
   } 
   $o.UBR = $o.UBR.ToString(); 
   $o.InstallDateString = FileTimeToString( $o.InstallTime );  
   # Update property BuildLabEx
   $d = GetBuildLabExDate( $o.BuildLabEx );
   $l = "55041-01781-051-124375-01-1033-10049.0000-0902015".Length;
   $o.BuildLabEx = ("{0,-$l} ({1})" -f $o.BuildLabEx, $d); 
   $pp = "Microsoft.PowerShell.Core\Registry::HKEY_LOCAL_MACHINE\".Length; 
   $o.PSParentPath = $o.PSParentPath.Substring( $pp );
   $o.InstallDateS = FormatNumber( $o.InstallDate );
   $o.InstallTimeS = FormatNumber( $o.InstallTime ); 
   if ( $o.PSChildName.Substring( 0, 3 ) -eq "Sou" )
   {
      $o.UpgradeDate       = DateStringToSeconds( $o );
      $o.UpgradeDateString = FileTimeToString( RegDWDateToFileTime( $o.UpgradeDate ) );
      $o.UpgradeDateS      = FormatNumber( $o.UpgradeDate );
   }

   if ( [int]$o.CurrentBuild -ge 14986 )
   {
      if ( [int]$o.BuildNumber -lt [int]$CurrentBuild )
      {
         $o = AddPropsFromXML( $o );
      }      
   }
   
   return $o;
}

## https://www.tutorialspoint.com/xaml/xaml_layouts.htm
#------------------------- Builds objects collecting starts ---------------------------------

$Global:Stamps = @();
$Global:Stamps += TimeStamp( "Started" );   

$temp  = [psobject[]]( get-itemproperty HKLM:\SYSTEM\Setup\"Source OS*" -EA SilentlyContinue ); 
$temp += ( get-itemproperty HKLM:\SOFTWARE\Microsoft\"Windows NT\CurrentVersion" );

$Global:Stamps += TimeStamp( "Builds objects collecting finished" );
                     
### SORT an array of the Build objects
$temp = ( $temp | Sort-Object -Property InstallDate );

$MaxL  = "Windows 10 Pro Technical Preview".Length;
$DateL = "13.10.2016 21:23:31".Length;
$FreeUpgrade = [int]$temp[0].CurrentBuild -lt 9841;

for ( $i = 0; $i -lt $temp.Length; $i++ )
{
   $obj = AddProperties( [pscustomobject]$temp[ $i ] );
   
   if ( [int]$obj.CurrentBuild -le 10240 )
   {
      if ( $FreeUpgrade -and $temp[ $i ].ProductKey.Split( "-" )[ 4 ] -eq `
      $temp[ 0 ].ProductKey.Split( "-" )[ 4 ] )
      {
         if ( ! $PRODUCTKEY )
         {
            $p = $temp[ $i ].ProductKey.Substring( 24 );
            $temp[ $i ].ProductKey = "XXXXX-XXXXX-XXXXX-XXXXX-$p";
         }
      }
   }
   if ( $i -gt 0 )
   {
      $obj.Minutes = [math]::truncate( ( $obj.InstallDate - $temp[ $i - 1 ].UpgradeDate ) / 60 );
      $seconds     = ( $obj.InstallDate - $temp[ $i - 1 ].UpgradeDate ) % 60;
      $seconds     = $seconds.ToString().PadLeft( 2, "0" ); 
      $obj.Minutes = $obj.Minutes.ToString() + ":" + $seconds;
   }   
   $temp[ $i ] = $obj; # update Array element   
}
############################################################################
# Building HTML code starts here                                           #
############################################################################
<#
---------------------------------------------------------------------------- 
 Project: GetBuildsHistory, part GBHColorSchemes                                               
 Version: 1.0                                                        
 FileId:  e:\Delme\!Projects\BuildsHistory\GBHColorSchemes.ps1                    
 When:    13 Dec 2016,  Tuesday,  09:53:54                           
 ©        Oleg Kulikov, sysprg@live.ru                               
---------------------------------------------------------------------------- 
Creates Style tags for HTA creation by GBHUtils.ps1 BuldHTML function                                                           
----------------------------------------------------------------------------
ATTENTION: contains Unicode strings, must be saved as Unicode !
----------------------------------------------------------------------------
Saturday, December 17, 2016. Created from the code from GBHUtils
----------------------------------------------------------------------------
The CSS3 box-sizing property allows us to include the padding and border in 
an element''s total width and height. If you set box-sizing: border-box; 
on an element padding and border are included in the width and height:
----------------------------------------------------------------------------
Read about webkit at:
stackoverflow.com/questions/1256258/div-scrollbar-any-way-to-style-it
----------------------------------------------------------------------------
#>

$HeaderStyle = '

html    { box-sizing: border-box; }
*, *::before, *::after { box-sizing: inherit; }
html    { overflow-x: hidden; }
body    { margin: 0; font-family: "Segoe UI"; letter-spacing:0px;}

.wide   { letter-spacing: 2px; }
.navbar { list-style-type: none; margin: 0; margin-left: 10px; padding: 0; width: 968px; overflow: hidden; }
.padding-8 { padding-top: 8px !important; padding-bottom: 8px !important; }
.navbar { position: relative; z-index: 4; font-size: 14px; }
.navbar a { text-decoration: none !important; }
.right { float: right !important; }
.navbar li { float: left; }
.navbar li a, .navitem, .navbar li { display: block; padding: 8px 16px; }
.caret   { font-family: Webdings; }
.navbtn_content { 
           display:     none; 
           position:    absolute; top: 50px;
           padding:        5px;
           font-size:     15px;
           letter-spacing: 2px;           
}
.hover-white{ cursor:pointer; }
.ContentItem { padding-top: 2px; padding-bottom: 2px; cursor:pointer;}
.topbarClass{ cursor:pointer; }

/* HAD TO BE CHANGED IF LOCALIZED */
#navbtn_file_content  { left: 022px; }
#navbtn_view_content  { left: 146px; } 
#navbtn_theme_content { left: 279px; }
#navbtn_lang_content  { left: 426px; }
#navbtn_edit_content  { left: 602px; }

#MainContainer
{
   width:      1030px; 
   heigth:     760px;
   max-width:  1170px;
   padding:    0px;  
   margin:     0px;
   overflow:   hidden;
   font-size:  14px;
}
#Main
{ 
   width:      98%; 
   padding:    0px;  
   margin:     0px;  
} 
     
#V1expandable, #V1tablecontainer, #V2expandable, #V2tablecontainer, #V3expandable, #V3tablecontainer 
{
   height:      98%;
   margin:      0;
   padding:     0;
   border:      none;
   overflow-y:  hidden;
}
   
#V1tablecontainer, #V2tablecontainer, #V3tablecontainer 
{
   width:       98%;
   margin:      0 auto;
   padding:     0px;
   max-height:  0450px;
}

#V2tablecontainer,#V3tablecontainer{display:none;}

#V1expandable, #V2expandable, #V3expandable
{
   margin:           5px 0 0 0px;
   overflow-x:       hidden;
   overflow-y:       auto;
   height:           370px;
   width:            100%;
   border-bottom:    none;
   cursor:           hand;
}
.Unknown1,.Unknown2,.Unknown3,.Unknown4{font-family:Consolas;letter-spacing:0px;}
.colname{font-family:"Segoe UI"!Important; letter-spacing:0px!important;}
::-webkit-scrollbar{width:5px!Important;}
::-webkit-scrollbar-thumb{background: #0000ff;}
.mr{cursor:pointer;border:none;}
.h{display:none;}     
.Build  {text-align:right;  width: 045px;} 
.Date1  {text-align:left;   width: 180px;}
.Date2  {text-align:left;   width: 180px;}
.Name   {text-align:left;   width: 250px;}
.Branch {text-align:left;   width: 140px;}
.UBR    {text-align:left;   width: 100px;}
.mmss   {text-align:center; width: 071px;}
.copyr  {width:968px;}
.ProductId  {text-align:left; width: 190px;}
.ProductId2 {text-align:left; width: 120px;}
.ProductId3 {text-align:left; width: 611px;}
.Unknown1{text-align:left; width: 155px;}
.Unknown2{text-align:left; width: 081px;}
.Unknown3{text-align:left; width: 685px;}
.KeepBlanks{font-family:Consolas;letter-spacing:0px;}
';
<#
CurrentBuild = "Build";      # 15007
ProductId2   = "ProductId2"; # [Blue]res-v2600
ProductId    = "ProductId";  # 00260-00709-22436-AA664
ProductId3   = "ProductId3"; # 00000-02600-070-922436-00-1033-9200.0000-3102015  (Fri, 06.11.2015)

Unknown1     = "Unknown1"    # C2E71155DF60C65C01
Unknown2     = "Unknown2"    # 99706075
Unknown3     = "Unknown3"    # 1EB0A1573BA73F900AA7F7C8CA577B1EB793A369FF41BC4D93A98B2DA5217F54
Unknown4     = "Unknown4"    # 02FE14A75482EDF8E8E74B51DE5D936A65CE2A3B7EF6A3AFA3EC2033A335EAA8
#>
$HeaderStyle = GetRidOfBlanks( $HeaderStyle );#get rid of blanks BUT KEEP \n
$bgRose = "http://webneel.com/wallpaper/sites/default/files/images/01-2014/20-flower-wallpaper.preview.jpg";
<#
--------------------------------------------------------
colors definition REQUIRES !important at list for HOVER 
---------------------------------------------------------
.white,.hover-white:hover{color:#000!important; background-color:#fff!important;}
#>
$ColorSchemeRoseFlowers = '
.navbtn_content { 
   color:            #ef7a8f;
   border: 2px solid #ef7a8f; border-top: none;
   background-color: #ffffff;
}
.theme  { color:#fff !important; background-color:#ef7a8f !important; }
a { background-color:transparent; -webkit-text-decoration-skip: objects; color:#ffffff; }
.white,.hover-white:hover {color:#000!important; background-color:#fff!important;}
.ContentItem:hover{background:#ef7a8f;color:#ffffff;}
  
body, #V1expandable, #V2expandable, #V1tablecontainer, #V2tablecontainer
{ 
   background-color:#f6e2f9;
   background:url(%BGImage%);
   background-size:cover;
}  
#V1tablecontainer,#V2tablecontainer{background: rgba(247,222,222,0.82);}
#V1expandable,#V2expandable{color:#a914a9;} 
.divcell { float: left; border: 1px solid #999000; box-sizing: border-box; border-bottom:none;}
.colname { float: left; border: 1px solid #999000; box-sizing: border-box; border-bottom:none;}
.divcell:hover{background:#a914a9; color:#f6e2f9;} 
.topbarClass,.footbarClass,.colname{background:#ef7a8f;color:#ffffff;} 
#navbtn_*:hover{ color:#7d10b5; }
#navbtn_debug,#navbtn_debug a,#navbtn_debug:hover{color:gray!important;background-color:#ef7a8f!important;cursor:default;}
';
$ColorSchemeRoseFlowers = CodeToString( $ColorSchemeRoseFlowers );
$ColorSchemeRoseFlowers = $ColorSchemeRoseFlowers -replace "%BGImage%", "$bgRose";

#                                  dark      light     body      hover
$ColorSchemeBlack  = buildCSS( @("#2f4f4f","#d3d3d3","#dcdcdc","#778899") );

$schemes = ( "" | Select HeaderStyle,RoseFlowers,Black );

Set-Variable ColorSchemes -Scope Global -Value $schemes;

$ColorSchemes.RoseFlowers = "$ColorSchemeRoseFlowers";
$ColorSchemes.Black       = "$ColorSchemeBlack";
### OTHER SCHEMES are produced from the Black by JS-code ###
<#
Geometry:    http://javascript.info/tutorial/metrics;
ColorNamesTo #-values: http://www.w3schools.com/colors/colors_names.asp;
Characters names: http://www.ascii.cl/htmlcodes.htm
AllAboutMouseEvents http://javascript.info/tutorial/mouse-events describes drag-n-drop
#>
$head ='
<head>
<meta http-equiv="X-UA-Compatible" content="IE=11">
<title>Builds History</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<style type="text/css">%HeaderStyle%</style>
<script type="text/javascript">
var version="%version%";
if ( typeof( repeat ) == "undefined" )
{
   String.prototype.repeat = function( n )                               
   { 
      var tmp = ""; 
      for ( var i = 0; i < n; i++ ) tmp += this;                                                                         
      return tmp;
   } 
} 
String.prototype.left = function( n, char )                               
{ 
   if ( typeof( char ) == "undefined" ) char = " ";  
   if ( this.length >= n ) return this.substr( 0, n );
   return this + char.repeat( n - this.length );
}
String.prototype.right = function( n, char )                               
{
   if ( typeof( char ) == "undefined" ) char = " ";   
   if ( this.length > n ) return this.substr( this.length - n );
   return char.repeat( n - this.length ) + this;
}
String.prototype.strip = function()                                         
{                                                                           
   return this.replace( /^(\s*)/, "" ).replace( /(\s*)$/, "" );               
}
String.prototype.html2text = function()
{
   return this.replace( /</gm, "&lt;" ).replace( />/gm, "&gt;" );
}
function getEvent()
{
   var evt = event || window.event;
   evt.cancelBubble = true;
   evt.returnValue  = false;
   if ( evt.cancelable ) evt.preventDefault();
   return evt;
}
 
var lastShownItem    = null;
var lastShownContent = null;
var lastShownCaret   = null;
var caretDown = "6", caretUp = "5";

function showMenuContent( o )
{
   var Event = getEvent();// call it to prevent event propagation
   obj = o.currentTarget;

   if ( lastShownItem )
   {
      lastShownContent.style.display = "none";
      lastShownItem.getElementsByTagName( "span" )[0].innerText = caretDown;
   }

   if ( obj.id == "IgnoreMe" ) return false;// specially for disabled Edit menu item;

   var id                = obj.getElementsByTagName( "a" )[0].id;
   var content           = document.getElementById( id + "_content" );
   var caret             = obj.getElementsByTagName( "span" )[0];
   content.style.display = "inline-block";
   caret.innerText       = caretUp;
   lastShownItem         = obj;
   lastShownCaret        = caret;
   lastShownContent      = content;
   return false;
}
function hideMenuContent()
{
   var ev = getEvent();
   if ( ! lastShownItem ) return false;
   lastShownContent.style.display = "none";
   lastShownItem                  = null;
   if ( lastShownCaret )
   {
      lastShownCaret.innerText = caretDown;
      lastShownCaret = null;
   }    
   return false;   
}
';

$head += @(
"var activeTheme = ""$THEME"";$NL" 
"var currentLang = ""$LANG"";$NL"
"var TEXTLOG     = ""$TEXTLOG"";$NL"
"var PRODUCTKEY  = ""$PRODUCTKEY"";$NL"
);

$head +='
var childWindows = [];         // keep all child windows handlers
var currentV     = "V1"        // prefix for the current View
var isFixedV2    = false;      // had to fix Geometry if false
var isFixedV3    = false;      // had to fix Geometry if false

/*
Function to switch View: it makes invisible ( display:none )
current GridView and makes visible requested View ( display: block )
It also fixes Geometry for the View which became visible for the 1st time.
*/
function setView( viewId )
{
   var ev = getEvent();
   var id1 = currentV + "tablecontainer";
   var id2 = currentV + "expandable";
   var o1  = document.getElementById( id1 );
   var o2  = document.getElementById( id2 );
   var id3 = viewId + "tablecontainer";
   var id4 = viewId + "expandable";
   var o3  = document.getElementById( id3 );
   var o4  = document.getElementById( id4 );
   o1.style.display = "none";
   o2.style.display = "none";
   o3.style.display = "block";
   o4.style.display = "block";
   currentV = viewId;
   var container, el;
   // no need to fix Geometry for the V1 as it is fixed by onload
   // call of FixGeometry. Geometry can be fixed for the Views
   // which became display:block.
   if ( currentV == "V2" && ! isFixedV2 )
   {
      container = document.getElementById( "V2tablecontainer" );
      el = container.getElementsByClassName("colname Build")[0];
      el.style.width = (el.offsetWidth + 1)+"px";
      el = container.getElementsByClassName( "colname ProductId3" )[0];
      el.style.width = (el.offsetWidth + 1)+"px";
      isFixedV2 = true;
   }
   else if ( currentV == "V3" && ! isFixedV3 )
   {
      container = document.getElementById( "V3tablecontainer" );
      el = container.getElementsByClassName("colname Build")[0];
      el.style.width = (el.offsetWidth + 1)+"px";
      el = container.getElementsByClassName( "colname Unknown3" )[0];
      el.style.width = (el.offsetWidth + 1)+"px";
      isFixedV3 = true;
   }
   return false;
}
var ColorScheme =
{
   "Flowers": "%RoseFlowers%",
   "Black":   "%Black%"
};
var popColors = 
{
   "Flowers": ["#a914a9","#f7dede","#f6e2f9"],
   "Black":   ["#2f4f4f","#d3d3d3","#dcdcdc","#778899"],
   "Green":   ["#006400","#90ef90","#98fb98","#00ff00"],
   "Blue":    ["#0000cd","#add8d6","#8fcefa","#6495ed"],
   "Brown":   ["#8b4516","#ffe4c4","#f5deb3","#cd853f"],
   "Orange":  ["#C96","#ffffe0","#ffcacd","#ff8c00"]//#C96 
 //             dark      light     body      hover
 //"Orange":  ["#ff4500","#ffffe0","#ffcacd","#ff8c00"]//#C96 #ff8c00
}
function setTheme( schemeName )
{
   var ev = getEvent();
   schemeName = schemeName.substr(0,1).toUpperCase() +
   schemeName.substr(1).toLowerCase();
   var Event  = getEvent();
   var scheme = null;
   if ( "Flowers,Black".indexOf( schemeName ) > -1 )
   {
      scheme = ColorScheme[ schemeName ];
   }
   else
   {
      scheme = ColorScheme.Black;
      var colors = popColors[ schemeName ];
      scheme = scheme.replace( /#2f4f4f/gi, colors[0] );
      scheme = scheme.replace( /#d3d3d3/gi, colors[1] );
      scheme = scheme.replace( /#dcdcdc/gi, colors[2] );
      scheme = scheme.replace( /#778899/gi, colors[3] );
   }
   document.getElementById( "ColorScheme" ).innerHTML = scheme;
   activeTheme = schemeName;
   hideMenuContent();
   return false; 
}
function writeHTML( code, fn )
{
	var fso  = new ActiveXObject( "Scripting.FileSystemObject" );
	var path = ".\\";
   var fut  = fso.CreateTextFile( path + fn, true );
   fut.Write( code );
   fut.close();
   return false;
}
function ShowDetails( row )
{
   var ev = getEvent();
   var win  = null;
   var id  = "div" + row.id.substr(2);// skip V1/V2
   var colors = popColors[ activeTheme ];
   var themeDependent = ".hc{color:%color1;background-color:%color2;border:1px solid %color1;}"+
   "body{background-color:%color3;}";

   themeDependent = themeDependent.replace( /%color1/g, colors[0] );
   themeDependent = themeDependent.replace( "%color2", colors[1] );
   themeDependent = themeDependent.replace( "%color3", colors[2] );

   var html = ""+//%bld%  
"<!DOCTYPE html><html><head><meta content=\"IE=11.0000\" http-equiv=\"X-UA-Compatible\">"+
"<title>" + LangStrings[currentLang].Details + "</title>"+    
"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"><style type=\"text/css\">"+
".h{font-family:MS Serif;letter-spacing:0px;}.KeepBlanks{font-family:Consolas;letter-spacing:0px;}"+
themeDependent + "</style></head><body>";
   // after implementing Vn-prefix in row-ids, following substr had to be changed, 17.01.2017;
   var bld = ( parseInt( "0x" + row.id.substr( 2, 4 ) ) ).toString();
   html = html.replace( "%bld%", bld );
   html += document.getElementById( id ).outerHTML + "</body></html>";
   var options = "width=810,height=660,scrollbars=1,resizable=1,status=0,toolbar=0,"+
  	"left=200,top=1200,titlebar=0,menubar=0";

	win = window.open( "empty.html", "", options );//should be run as administrator

   if( win )
   {
      win.document.write( html );     
      childWindows[ childWindows.length ] = win;
   }
   else// null-handler was returned by IE, 
   {   // needs Adminitrator privileges to create popup windows
      alert( LangStrings[ currentLang ].ReRun );     
   }

   return false; 
}
function closeAllWindows()
{
   var ev = getEvent();
   for( var i = 0; i < childWindows.length; i++ )
   {
      var h = childWindows[ i ];
      if ( h ) 
      {
         // this try/catch are necessary because of SOMETIMES
         // rather strange error "The RPC-server is unavalable"
         // is ussued
         try
         {
            h.window.close();
         }
         catch(e){}
      }
   }
   window.close();
} 
function closePopUps()
{
   var Event = getEvent();
   if ( Event.keyCode == "27" )// Escape;
   {
      hideMenuContent();
   }
   return false;
}
function switchUnknowns()
{
   var pnodes = document.getElementsByClassName("divcell Unknown3");
   for ( var i = 0; i < pnodes.length; i++ )
   {
      var childs = pnodes[i].getElementsByTagName( "div" );
      var left  = childs[0];
      var right = childs[1];
      left.style.display  = left.style.display  == "block" ? "none" : "block";
      right.style.display = right.style.display == "block" ? "none" : "block";
   }
   var ev = getEvent();
   return false;
}
/*
This is, I HOPE, temporary function which fixes 1 pixel lost
at the 1st item of the V1topBar and, as appeared 1 pixel at the
last item. DON''t UNDERSTAND WHY thease pixels are lost.
*/ 
function fixGeometry()
{
   var container = document.getElementById( "V1tablecontainer" );
   var el = container.getElementsByClassName("colname Build")[0];
   el.style.width = (el.offsetWidth + 1)+"px";
   el = container.getElementsByClassName( "colname mmss" )[0];
   el.style.width = (el.offsetWidth + 1)+"px";
   return false;
}
var CreateColorDebugWin = false;
var debugWin = null;
function createDebugWin()
{
   var options = "width=790,height=350,scrollbars=0,resizable=1,status=0,toolbar=0,"+
  	"left=100,top=100,titlebar=1,menubar=0"
	if( ! debugWin || debugWin.closed )
	{
		debugWin = window.open( "color.html", "Color Debugger", options );
      childWindows[ childWindows.length ] = debugWin;
	}
}
/*
-------------------------------------------------------
Runs correctly only for ANSI encoding
PShell code sets ascii encoding provided other one
was used.
-------------------------------------------------------
*/
function SaveSettings()
{
   var ev = getEvent();
   function Repl( line, ov, nv )
   {
      var p = line.indexOf( "=" ) + 1;
      var l = line.substr( 0, p );
      var r = line.substr( p ).replace( ov, nv );
      return l + r;
   }
	var fso  = new ActiveXObject( "Scripting.FileSystemObject" );
   var path = location.pathname.substr( location.pathname.indexOf( ":" ) - 1 );
   var fn   = fso.GetFileName( path );
	var inif = path.replace( fn, "GetBuildsHistory.ini" );

	var fin  = fso.OpenTextFile( inif, 1 );
   var content = fin.ReadAll().split("\n");
   fin.Close();
   
   var tl = TEXTLOG;
   var pk = PRODUCTKEY;
   var cl = currentLang.toLowerCase();
   var at = activeTheme.toLowerCase();

   var line, ll, key, v, nc = 0;
   var keys = "textlog,theme,lang,productkey".split(",");
   
   for( var i = 0; i < content.length; i++ )
   {
      line = content[i];      
      line = line.split("#")[0].strip();
      if ( line == "" 
      ||   line.indexOf( "=" ) == -1 ) continue;
      ll   = line.split( "=" );
      line = content[i];
      key  = ll[0].strip().toLowerCase();
      ov   = ll[1].strip();
      v    = ov.toLowerCase();

      for ( var j = 0; j < keys.length; j++ )
      {
         if ( keys[j] == key )
         {
            switch( key )
            {
               case "textlog":    if ( v != tl ) content[i] = Repl( line, ov, tl ); nc++; break;
               case "lang":       if ( v != cl ) content[i] = Repl( line, ov, cl ); nc++; break;
               case "theme":      if ( v != at ) content[i] = Repl( line, ov, at ); nc++; break;
               case "productkey": if ( v != pk ) content[i] = Repl( line, ov, pk ); nc++; break;
            }
            break;
         }
      }
   }
   if ( nc )
   {
      fin  = fso.OpenTextFile( inif, 2 );
      for( var i = 0; i < content.length; i++ )
      {
         if ( ! content[i].strip() ) continue;
         fin.WriteLine( content[i] );
      }
      fin.Close(); 
      var msg = LangStrings[ currentLang ].FileUpdated.replace( "%fn%", inif );
      alert ( msg );
   }
   return false;
}
function MainTableToText()
{
   function formatAndJoin( arr )
   {
      var out = ""   ;
      if ( currentV == "V1" )
      {
         var dl = "31.03.2015 16:25:14 Tue".length;
         var tl = "Windows 10 Pro Technical Preview".length;
         var bl = "fbl_impressive_cxe".length;
         var ml = "Minutes".length;
         out += arr[0].right( 5 ) + "  " +                 // build;
         arr[1].replace( "   ", " " ).left( dl ) + "  " +  // Install Date
         arr[2].replace( "   ", " " ).left( dl ) + "  " +  // Upgrade Date
         arr[3].left( tl ) + "  " +                        // Product Name
         arr[4].left( bl ) + "  " +                        // Branch
         arr[5].replace( "Service pack", "UBR").right( 5 ) + "  " + // Service Pack
         arr[6].right( ml );                               // Minutes
         return out + ''\n'';
      }
      else if ( currentV == "V2" )
      {
         var f1 = "[TH]X20-35537".length;
         var f2 = "00178-10511-24375-AB527".length
         out += arr[0].right( 5 ) + "  " +                 // build;
                arr[1].left( f1 ) + "  " +                 // ProductId2 
                arr[2].left( f2 ) + "  " +                 // ProductId2
                arr[3]; 
         return out + ''\n'';                
      }
      else if ( currentV == "V3" )
      {
         var f1 = "F92374586412043700".length;
         var f2 = "D86AFA5F".length
         var f3 = "1EB0A1573BA73F900AA7F7C8CA577B1EB793A369FF41BC4D93A98B2DA5217F54".length;
         if ( arr[0] == "Build" )
         {
            arr[3] = "Unknown3";
            arr[4] = "Unknown4";
         }
         out += arr[0].right( 5 ) + "  " +                 // build;
                arr[1].left( f1 ) + "  " +                 // Unknown1 
                arr[2].left( f2 ) + "  " +                 // Unknown2
                arr[3].left( f3 ) + "  " + arr[4];  
         return out + ''\n'';                
      }
   }
	var fso  = new ActiveXObject( "Scripting.FileSystemObject" );
	var path = location.pathname.substr( location.pathname.indexOf( ":" ) - 1 );
   var outp = path.replace( ".hta", currentV+".log" );
   var out  = ""; 

   var header    = document.getElementById( currentV + "topBar" );
   var mainTable = document.getElementById( currentV + "expandable");
   var tmp = header.getElementsByTagName("div");
   var names = [], row;// column names
   for ( var i = 0; i < tmp.length; i++ )
   {
      names[ names.length ] = tmp[i].innerText.strip();
   }
   out += formatAndJoin( names );
   tmp = mainTable.getElementsByClassName( "mr divcell" );
   
   for ( var i = 0; i < tmp.length; i++ )
   {
      row = tmp[i].getElementsByTagName("div");
      names = [];
      for ( var j = 0; j < row.length; j++ )
      {
         if ( currentV == "V3" && j == 3 )
         {
            var childs = row[j].getElementsByTagName("div");;
            names[ names.length ] = childs[0].innerText.strip();
            names[ names.length ] = childs[1].innerText.strip();
            continue;
         }
         names[ names.length ] = row[j].innerText.strip();
      }
      out += formatAndJoin( names );
   }
   var fut = fso.CreateTextFile( outp, true );
   fut.Write( out );
   fut.Close();
   var msg = LangStrings[ currentLang ].FileCreated.replace( "%fn%", outp );
   alert ( msg );
   return false;
}

window.onload = function()
{
   var ev = getEvent();
   window.resizeTo( 1100, 760 );
   fixGeometry();
   document.onkeydown  = function(){return closePopUps();}
   // Assign onclick handlers for menu items;
   var o, id, items = ["file","view","theme","lang","debug"];
   for ( var i = 0; i < items.length; i++ )
   {
      id = "navbtn_" + items[i];
      o = document.getElementById( id ).parentNode;
      o.onclick = function(o){return showMenuContent(o);}
   }
   if ( CreateColorDebugWin ) createDebugWin();
   document.body.onclick = function(e)
   {
      var Event = getEvent();
      return hideMenuContent();
   }
   implementLangStrings();
   setTheme( activeTheme );
   setLang( currentLang );
   document.body.onbeforeunload = function(){return closeAllWindows();}
}
';

$head = GetRidOfBlanks( $head );# get rid of blanks BUT KEEP \n
$head = $head -replace "%HeaderStyle%", "$HeaderStyle";
$head = $head -replace "%RoseFlowers%", "$ColorSchemeRoseFlowers";
$head = $head -replace "%Black%", "$ColorSchemeBlack";
$head = $head -replace "%version%", "$Version"; 
SetGlobals;
$t    = $Global:Title;
$head = $head.Replace( "Builds History", "$t" );

## Encodings: Unicode, UTF8, UTF32, Ascii
$nbld  = $temp.Length;
$nupg  = $nbld - 1;
$date1 = $temp[ 0 ].InstallDateString;
$date2 = $temp[ $temp.Length - 1 ].InstallDateString;
$loop ='
var lang;
for(var i = 0; i < LangsPresent.length; i++ )
{
   lang=LangsPresent[i];
   LangStrings[lang].Title=LangStrings[lang].Title.replace("%NN%",NUpgrades);
   LangStrings[lang].Title=LangStrings[lang].Title.replace("%date1%",date1);
   LangStrings[lang].Title=LangStrings[lang].Title.replace("%date2%",date2);
   LangStrings[lang].Tooltip=LangStrings[lang].Tooltip.replace(/,/g,''\n'');
}
// set lang value to system language
lang=(window.navigator.userLanguage||window.navigator.language).substr(0,2).toLowerCase();
function implementLangStrings()
{
   document.getElementById("V1topBar").title = LangStrings[lang].Tooltip;
   document.getElementsByTagName("title")[0].innerText = LangStrings[lang].Title; 
   var langMenuItems = document.getElementById("navbtn_lang_content").getElementsByClassName("ContentItem");
   for ( var i = 0; i < langMenuItems.length; i++ )
   {
      var o = langMenuItems[i];
      var t = o.innerText;
      var l = t.substr( 1 + t.indexOf( "(" ), 2 ).toLowerCase();
      if( LangStrings[l] ) o.innerText += LangStrings[l].NativeName;
   }
}
function setLang( lang )
{
   var ev = getEvent();
   document.getElementById("V1topBar").title = LangStrings[lang].Tooltip;
   document.getElementsByTagName("title")[0].innerText=LangStrings[lang].Title;
   currentLang = lang;// global variable in header inline js-code
   var l = LangStrings[lang], t;
   document.getElementById("navbtn_file").childNodes[0].data = l.File;
   document.getElementById("navbtn_view").childNodes[0].data = l.View;
   document.getElementById("navbtn_theme").childNodes[0].data = l.Theme;
   document.getElementById("navbtn_lang").childNodes[0].data = l.Language;
   document.getElementById("navbtn_debug").childNodes[0].data = l.Edit; 
   t = document.getElementById("navbtn_file_content").getElementsByTagName("div");
   t[0].childNodes[0].data = l.SaveSettings;
   t[1].childNodes[0].data = l.SaveView;
   t[2].childNodes[0].data = l.Exit;
   t = document.getElementById("navbtn_view_content").getElementsByTagName("div");
   t[0].childNodes[0].data = l.Default;
   t = document.getElementById("navbtn_theme_content").getElementsByTagName("div");
   t[0].childNodes[0].data = l.Flowers;
   t[1].childNodes[0].data = l.Black;
   t[2].childNodes[0].data = l.Green;
   t[3].childNodes[0].data = l.Blue;
   t[4].childNodes[0].data = l.Brown;
   t[5].childNodes[0].data = l.Orange;
   return false;
}
';
$langs = BuildJS;
$js = $langs + @(
"var NUpgrades=$nupg;"
"var date1=""$date1"";"
"var date2=""$date2"";"
)+$loop;# SEE ABOVE !

$head += $js + "</script></head>";
$head | Set-Content -Encoding utf8 .\$LogFN.hta; ### Created header of the HTA-file
# Create Empty.html
"<html><head></head><body></body></html>" | Set-Content -Encoding utf8 .\empty.html;
# prepare text of the batch file
$cmd = '
@echo off 
if "%2"=="firstrun" exit
cmd /c "%0" null firstrun
if "%1"=="skipuac" goto skipuacstart
:checkPrivileges
NET FILE 1>NUL 2>NUL
if ''%errorlevel%'' == ''0'' ( goto gotPrivileges ) else ( goto getPrivileges )
:getPrivileges
if ''%1''==''ELEV'' (shift & goto gotPrivileges)
setlocal DisableDelayedExpansion
set "batchPath=%~0"
setlocal EnableDelayedExpansion
ECHO Set UAC = CreateObject^("Shell.Application"^) > "%temp%\RunAs.vbs"
ECHO UAC.ShellExecute "!batchPath!", "ELEV", "", "runas", 1 >> "%temp%\RunAs.vbs"
"%temp%\RunAs.vbs"
exit /B
:gotPrivileges
setlocal & pushd .
cd /d %~dp0
cmd /c "%0" skipuac firstrun
cd /d %~dp0
:skipuacstart
if "%2"=="firstrun" exit
';
$cmd += "$LogFN.hta"; 
$cmd | Set-Content -Encoding utf8 .\RunHTA.cmd; ### Create cmd-file to run HTA-file

$Title = "History contains $nupg upgrades since $date1 till $date2";
$RunLog += "$Title$NL";
$Global:Title = $Title;

$Global:Stamps += TimeStamp( "Builds objects array is ready to be logged" );

##$TEXTLOG = 0; # read it from INI-file !

if ( $TEXTLOG )
{
   $RunLog += BuildTextLog( $temp ); ### create full log
   $RunLog += "$NL";
   $Global:Stamps += TimeStamp( "Text log creation is finished" );
}

$AllProperties = @(
   "CurrentBuild","InstallDateString","Minutes","FullDuration","Description","ProductName",`
   "ProductId","ProductId4","ProductId2","BuildLabEx","ProductId3","ProductId5",`
   "DefaultProductKey","ProductKey","EditionID","CurrentVersion","ReleaseId","UBR",`
   "LicensingProductID","ApplicationID","InstallDate","InstallTime","UpgradeDate",`
   "PSParentPath","PSChildName","Unknown1","Unknown2","Unknown3","Unknown4"  
);

if ( Test-Path .\out.xml ){ Remove-Item .\out.xml -Force }
$temp | Select $AllProperties | Export-Clixml -Path .\out.xml;
if ( Test-Path .\$LogFN.xml ){ Remove-Item .\$LogFN.xml -Force }
Rename-Item -Path ".\out.xml" -NewName ".\$LogFN`.xml";
$Global:Stamps += TimeStamp( "XML creation is finished" );

BuldHTML( $temp ) | Add-Content .\$LogFN.hta;

if ( $NeedTextLog )
{
   $Global:Stamps += TimeStamp( "HTML creation is finished" );
   $RunLog | Set-Content -Encoding ascii .\$LogFN.log;
}

& .\$LogFN.hta; # run HTA
