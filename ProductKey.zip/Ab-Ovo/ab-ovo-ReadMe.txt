ATTENTION: All the keys shown below relates to Professional Edition only.

I have started to search codes which can get Windows "Activation Key" in 2012
as soon as have installed Windows 8 on one of my notebooks. The first one code
which correctly detects Product Keys for both of my systems, Windows 7 SP1 and
Windows 8, was VBS-code ( see winaero.vbs ) published at
http://winitpro.ru/index.php/2012/10/12/kak-uznat-klyuch-windows-8/
I've rewrote it from vbs to JS and thus have appeared first version of
getWindowsKey.js.

As soon as Microsoft have started Windows Insider program, 
I've run getWindowsKey.js any time new build was delivered and installed. 
Till Build 10122 getWindowsKey correctly showed Retaill Key value of the Windows 8  
as I've updated Windows 8 by Insider Build 9841 and continued updates.
But since Build 10122 and untill Build 10240, getWindowsKeys started show
somewhat incorrect key values:

Build  ---getWindowsKey values------   -----Correct-Key-Values------
10122  NKJFK-GPHP7-G8C3J-P6JXR-HQRJR   BKJFK-GPHP7-G8C3J-P6JXR-HQRJR
10125  NKJFK-GPHP7-G8C3J-P6JXR-HQRJR   BKJFK-GPHP7-G8C3J-P6JXR-HQRJR
10130  NKJFK-GPHP7-G8C3J-P6JXR-HQRJR   BKJFK-GPHP7-G8C3J-P6JXR-HQRJR
10158  NJ4MX-VQQ7Q-FP3DB-VDGHX-7XM87   BJ4MX-VQQ7Q-FP3DB-VDGHX-7XM87
10159  NJ4MX-VQQ7Q-FP3DB-VDGHX-7XM87   BJ4MX-VQQ7Q-FP3DB-VDGHX-7XM87
10162  8N67H-M3CY9-QT7C4-2TR7M-TXYCV   C867H-M3CY9-QT7C4-2TR7M-TXYCV
10166  NJ4MX-VQQ7Q-FP3DB-VDGHX-7XM87   BJ4MX-VQQ7Q-FP3DB-VDGHX-7XM87

Starting Windows 10 RTM, Build 10240, getWindowsKey.js always shows CORRECT
but well-known key VK7JG-NPHTM-C97JM-9MPGT-3V66T which is assigned to those
who have updated old systems ( Windows 7, Windows 8, Windows 8.1 ) by one
of the Windows 10 builds ( 10240, 10586, 14393 ) or have got it "For-Free" as
Insider Program participator until Windows 10 RTM. This key means that really
you have Digital Certificate which is kept at Microsoft servers.

Nevertheless this code still have sense for:
1. owners of an old Windows systems.
2. owners of the Windows 10 activated by Retail key. 

Incorrectness shown above was fixed in current versions of GetProductKey.js,
ShowProductKey.ps1 in November 2016. Many thanks to Skourlatov who have
published his Get-WindowsProductGUI.ps1 at http://poshcode.org/5429. Some
part of the Skourlatov code is reused with insignificant changes in GUI-part
of the ShowProductKey.ps1. And for sure an arithmetics used by Skourlatov have
fixed key values for 10122..10166 builds. 




