//---------------------------------------------------------------------
// Code below follows get_windows_8_key.vbs presented at
// http://winitpro.ru/index.php/2012/10/12/kak-uznat-klyuch-windows-8/
// with insignificant changes
// OlegKulikov46@mail.ru, 17-12-2012
//---------------------------------------------------------------------
// http://learn-powershell.net/2012/05/04/updating-an-existing-get-productkey-function/
// http://powershell.com/cs/blogs/tips/search.aspx?q=Windows+Product+key&o=Relevance
// http://powershell.com/cs/blogs/tips/archive/2012/04/30/getting-windows-product-key.aspx
// http://gallery.technet.microsoft.com/scriptcenter/Get-product-keys-of-local-83b4ce97
// http://gallery.technet.microsoft.com/scriptcenter/9cda3bf7-2f82-4614-a6f6-34dbdbc0df22/view/Discussions#content
// http://msdn.microsoft.com/en-us/library/cbxxzwb5%28VS.85%29.aspx
// http://msghelp.net/showthread.php?tid=65331&pid=718469
// http://msdn.microsoft.com/en-us/library/ie/yek4tbz0%28v=vs.94%29.aspx
// http://technet.microsoft.com/en-us/library/ee156585.aspx
// https://developer.mozilla.org/en-US/docs/JavaScript/Reference
// http://badassjs.com/post/694057326/bKeyaryreader-js-parsing-bKeyary-data-in-javascript
// http://wsh2.uw.hu/ch11e.html <== must to read !
//---------------------------------------------------------------------
// http://stackoverflow.com/questions/332422/how-do-i-get-the-name-of-an-objects-type-in-javascript
// helped to detect that RegRead returns binary key as VBArray !
Object.prototype.getName = function() 
{ 
   var funcNameRegex = /function (.{1,})\(/;
   var results = (funcNameRegex).exec((this).constructor.toString());
   return (results && results.length > 1) ? results[1] : "";
};


/*
-----------------------------------------------------------------------
VBS-code debug otput:
regKy(66)                  = 9
regKey( 66 ) \ 6           = 1
( regKey( 66 ) \ 6 ) And 1 = 1     <== isWin8 = ( regKey( 66 ) \ 6 ) And 1
regKey( 66 ) And &HF7      = 1
( isWin8 And 2 ) * 4       = 0
( regKey( 66 ) And &HF7 ) Or ( ( isWin8 And 2 ) * 4 ) = 1
-----------------------------------------------------------------------
Mozilla reference
Table 3.4 Bitwise operators Operator 	Usage 	Description
Bitwise AND 	a & b 	Returns a one in each bit position for which the corresponding 
                        bits of both operands are ones.
Bitwise OR 	a | b 	Returns a one in each bit position for which the corresponding 
                        bits of either or both operands are ones.
Bitwise XOR 	a ^ b 	Returns a one in each bit position for which the corresponding 
                        bits of either but not both operands are ones.
Bitwise NOT 	~ a 	Inverts the bits of its operand.
Left shift 	a << b 	Shifts a in bKeyary representation b bits to the left, 
                        shifting in zeros from the right.
Sign-propagating right shift 	a >> b 	Shifts a in bKeyary representation b bits 
                        to the right, discarding bits shifted off.
Zero-fill right shift 	a >>> b  Shifts a in bKeyary representation b bits to the right, 
                        discarding bits shifted off, and shifting in zeros from the left.
Expression 	Result 	bKeyary Description
15 & 9 	9 	1111 & 1001 = 1001
15 | 9 	15 	1111 | 1001 = 1111
15 ^ 9 	6 	1111 ^ 1001 = 0110
~15 	-16 	~00000000...00001111 = 11111111...11110000
~9 	-10 	~00000000...00001001 = 11111111...11110110
*/
var objShellWindows = new ActiveXObject( "shell.application" ).Windows();
        
if ( objShellWindows != null )
{
   var Shell = new ActiveXObject( "WScript.Shell" );
   var rk1   = "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\ProductName";
   var rk2   = "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\ProductID";
   var rk3   = "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\DigitalProductId";
   var PName = "Windows Product Name: " + Shell.RegRead( rk1 );
   var PID   = "Windows Product ID:   " + Shell.RegRead( rk2 );

   Shell.Popup( PName + '\n' + PID );
   WScript.Echo( PName + '\n' + PID );
   WScript.Echo( "Windows 8 Key:        " + convert2Char( Shell, rk3 ) ); 
}

function convert2Char( obj, key ) 
{ 
// RegRead will return binary registry key value as VBArray, thus we need to
// convert it to JScript array of a bytes.
   var bArray = Shell.RegRead( rk3 ).toArray();
   isWin8 = ( ( ( bArray[ 66 ] & 0xFF ) %  6 ) & 1 );
   bArray[ 66 ] = ( bArray[ 66 ] & 0xF7 ) | ( ( isWin8 & 2 ) * 4 );  

   var chars = "BCDFGHJKMPQRTVWXY2346789";  
   var PKey = "";  
   for ( var i = 24; i >= 0; i-- ) 
   { 
      var r = 0; 
      for ( var j = 14; j >= 0; j-- ) 
      { 
         r = r * 256;
         r = bArray[ j + 52 ] + r;
         bArray[ j + 52 ] =  Math.floor( r / 24 ); 
         r = r % 24; 
      } 
      PKey = chars.charAt( r ) + PKey;
WScript.Echo( PKey+", " + r ); 
   } 
   if ( isWin8 == 1 )
   {
      var t1 = PKey.substr( 1, r );
      PKey = PKey.substr( 1 ).replace( t1, t1 + 'N' );
      if ( r == 0 ) PKey = 'N' + PKey;
   }
WScript.Echo( PKey );
   return PKey.substr(  0, 5 ) + "-" + 
          PKey.substr(  5, 5 ) + "-" + 
          PKey.substr( 10, 5 ) + "-" +
          PKey.substr( 15, 5 ) + "-" + 
          PKey.substr( 20, 5 );
}
/*
VBS                                                   JS
H, 5                                                  H, 5
DH, 2                                                 DH, 2
4DH, 19                                               4DH, 19
Q4DH, 10                                              Q4DH, 10
GQ4DH, 4                                              GQ4DH, 4
2GQ4DH, 17                                            2GQ4DH, 17
W2GQ4DH, 14                                           W2GQ4DH, 14
PW2GQ4DH, 9                                           PW2GQ4DH, 9
VPW2GQ4DH, 13                                         VPW2GQ4DH, 13
BVPW2GQ4DH, 0                                         BVPW2GQ4DH, 0
VBVPW2GQ4DH, 13                                       VBVPW2GQ4DH, 13
XVBVPW2GQ4DH, 15                                      XVBVPW2GQ4DH, 15
7XVBVPW2GQ4DH, 21                                     7XVBVPW2GQ4DH, 21
37XVBVPW2GQ4DH, 18                                    37XVBVPW2GQ4DH, 18
B37XVBVPW2GQ4DH, 0                                    B37XVBVPW2GQ4DH, 0
BB37XVBVPW2GQ4DH, 0                                   BB37XVBVPW2GQ4DH, 0
VBB37XVBVPW2GQ4DH, 13                                 VBB37XVBVPW2GQ4DH, 13
VVBB37XVBVPW2GQ4DH, 13                                VVBB37XVBVPW2GQ4DH, 13
YVVBB37XVBVPW2GQ4DH, 16                               YVVBB37XVBVPW2GQ4DH, 16
DYVVBB37XVBVPW2GQ4DH, 2                               DYVVBB37XVBVPW2GQ4DH, 2
BDYVVBB37XVBVPW2GQ4DH, 0                              BDYVVBB37XVBVPW2GQ4DH, 0
8BDYVVBB37XVBVPW2GQ4DH, 22                            8BDYVVBB37XVBVPW2GQ4DH, 22
D8BDYVVBB37XVBVPW2GQ4DH, 2                            D8BDYVVBB37XVBVPW2GQ4DH, 2
6D8BDYVVBB37XVBVPW2GQ4DH, 20                          6D8BDYVVBB37XVBVPW2GQ4DH, 20
G6D8BDYVVBB37XVBVPW2GQ4DH, 4                          G6D8BDYVVBB37XVBVPW2GQ4DH, 4
G6D8BDYVVBB37XVBVPW2GQ4DH                             G6D8BDNYVVBB37XVBVPW2GQ4DH, 4
Windows 8 Key:        6D8BN-DYVVB-B37XV-BVPW2-GQ4DH
*/
