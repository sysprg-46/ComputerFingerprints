//---------------------------------------------------------------------
// Code below follows get_windows_8_key.vbs presented at
// http://winitpro.ru/index.php/2012/10/12/kak-uznat-klyuch-windows-8/
// with insignificant changes
// OlegKulikov46@mail.ru, 17-12-2012
//---------------------------------------------------------------------

var objShellWindows = new ActiveXObject( "shell.application" ).Windows();
        
if ( objShellWindows != null )
{
   var Shell = new ActiveXObject( "WScript.Shell" );
   var rk1   = "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\ProductName";
   var rk2   = "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\ProductID";
   var rk3   = "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\DigitalProductId";
   var PName = "Windows Product Name: " + Shell.RegRead( rk1 ) + '\n';
   var PID   = "Windows Product ID:   " + Shell.RegRead( rk2 ) + '\n';
   var WK    = "Windows Key:          " + convert2Char( Shell, rk3 );       
   WScript.Echo( PName + PID + WK ); 
   Shell.Popup(  PName + PID + WK );
}

function convert2Char( obj, key ) 
{ 
   var bArray = Shell.RegRead( rk3 ).toArray();
   isWin8 = ( ( ( bArray[ 66 ] & 0xFF ) %  6 ) & 1 );
   bArray[ 66 ] = ( bArray[ 66 ] & 0xF7 ) | ( ( isWin8 & 2 ) * 4 );  
   var chars = "BCDFGHJKMPQRTVWXY2346789";  
   var PKey = "";  
   for ( var i = 24; i >= 0; i-- ) 
   { 
      var r = 0; 
      for ( var j = 14; j >= 0; j-- ) 
      { 
         r = r * 256;
         r = bArray[ j + 52 ] + r;
         bArray[ j + 52 ] =  Math.floor( r / 24 ); 
         r = r % 24; 
      } 
      PKey = chars.charAt( r ) + PKey;
   } 
   if ( isWin8 == 1 )
   {
      var t1 = PKey.substr( 1, r );
      PKey = PKey.substr( 1 ).replace( t1, t1 + 'N' );
      if ( r == 0 ) PKey = 'N' + PKey;
   }
   return PKey.substr(  0, 5 ) + "-" + 
          PKey.substr(  5, 5 ) + "-" + 
          PKey.substr( 10, 5 ) + "-" +
          PKey.substr( 15, 5 ) + "-" + 
          PKey.substr( 20, 5 );
}
