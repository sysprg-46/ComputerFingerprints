<#
-------------------------------------------------------------------- 
 Project: GetBuildsHistory, part GBHUtils                                               
 Version: 1.0                                                        
 FileId:  e:\Delme\!Projects\BuildsHistory\GBHUtils.ps1                    
 When:    13 Dec 2016,  Tuesday,  09:53:54                           
 ©        Oleg Kulikov, sysprg@live.ru                               
-------------------------------------------------------------------- 
 Collection of the GetBuildsHistory project functions.                                                           
--------------------------------------------------------------------
Tuesday, December 13, 2016. Have improved Details presentation:
dates now are vertically aligned. textlog
--------------------------------------------------------------------
#>
### Common global for ALL views, contains all fields names
$Global:currentView = "V1";
$Global:P2N = @{
   CurrentBuild      = "Build";
   InstallDateString = "Date1";
   UpgradeDateString = "Date2";
   ProductName       = "Name";
   BuildBranch       = "Branch";
   UBR               = "UBR";
   Minutes           = "mmss";
};

$Global:Translate = @{
   CurrentBuild      = "Build";
   InstallDateString = "Install Date";
   UpgradeDateString = "Upgrade Date";
   ProductName       = "Product Name";
   BuildBranch       = "Branch";
   UBR               = "Service pack";
   Minutes           = "Minutes";
}

$l1 = ("CurrentBuild,InstallDateString,UpgradeDateString,ProductName," +`
"BuildBranch,UBR,Minutes") -split ",";
$l2 = ("CurrentBuild,ProductId2,ProductId,ProductId3") -split ",";
$l3 = ("CurrentBuild,Unknown1,Unknown2,Unknown3") -split ",";

Set-Variable -Name V1RowProps -Scope Global -Value $l1;
Set-Variable -Name V2RowProps -Scope Global -Value $l2;
Set-Variable -Name V3RowProps -Scope Global -Value $l3;

function Global:TagIdFromObjDate( $o )
{
   $v   = $Global:currentView;
   $bld = "{0:X0}" -f [int]$o.CurrentBuild;
   $dat = $o.InstallTimeS.Substring( 2 + $o.InstallTimeS.IndexOf( "0x" ), 8 );
   return "$v$bld$dat";      
}
function Global:FormatNumber( [int64]$num )
{
   if ( $num -lt 13071694150 )
   {
      return ("{0,-19} (0x{0:X0})" -f $num);
   }      
   return ("{0,-19} (0x0{0:X0})" -f $num);
} 
function GetBuildTimeZone( $obj )
{
   $build = $obj.CurrentBuild;
   for ( $i = 0; $i -lt $TimeZoneDefs.Length )
   {
      $def = ($TimeZoneDefs[ $i ]) -split "=";
      if ( $def[0] -eq $build ){return $def[1];}
      elseif( $def[0].IndexOf( "-" ) -eq -1 ) {return "";}
      $lr = $def[0] -split "-";
      if ( [int]$lr[0] -gt [int]$build ){return "";}
      if ( [int]$lr[1] -lt [int]$build ){return "";}
      return $def[1];      
   }
}
function DateStringToSeconds( $obj ) 
{
   $utc   = $obj.PSChildName.Replace( "Source OS (Updated on ", "" ).Replace( ")", "" );
   $tz    = GetBuildTimeZone(  $obj );
   $dt    = [datetime]( "$utc" );
   $epoch = ( Get-Date -Year 1970 -Month 1 -Day 1 -Hour 0 -Minute 0 -Second 0 );### CONST
   $dt | % { $Seconds = [math]::truncate( $_.ToUniversalTime().Subtract( $epoch ).TotalSeconds ) };
   if ( $tz -ne "" )
   {
      $s1 = [int]$CurrentTIMEZONESeconds;
      $s2 = [int]$tz;
      $Seconds += ( $s1 - $s2 );
   }
   return $Seconds;
}
<#
---------------------------------------------------------------------------------
This function is called from GetBuildsHistory.js main code to build Black theme
CSS code. All other themes are built by JS code on base of the Black theme CSS
replacing 4 colors used in Black theme css.
---------------------------------------------------------------------------------
#>
function buildCSS( $colors )
{
<#
P.A: borders are always this solid black for any other then Flowers themes
$dark  is used as text color, dark background 
$lightis used as text color on dark and background for rows
$body less intensive then light
$hover intermediate between light and dark
#>
   $brdr  = "#999";#"#e5e5e5";
   $dark  = $colors[0];# is used as text color, dark background 
   $light = $colors[1];# is used as text color on dark and background for rows
   $body  = $colors[2];# less intensive then light
   $hover = $colors[3];# intermediate between light and dark
   $css = @(
".theme  { color:#ffffff!important; background-color:$dark!important; }"
"a { background-color:transparent; -webkit-text-decoration-skip: objects; color:$light; }"
".navbtn_content {" 
"color: $dark;"
"border: 2px solid $brdr; border-top: none;"
"background-color: $light;}"
".white,.hover-white:hover{color:$dark!important; background-color:#ffffff!important;}"#$light
".ContentItem:hover{background:$hover;color:#ffffff;}" #$light;
"body,#V1expandtable,#V2expandtable,#V3expandable,#V1tablecontainer,#V2tablecontainer,#V3tablecontainer{background-color:$body;}"  
"#V1tablecontainer,#V2tablecontainer,#V3tablecontainer{background: $light;}"
"#V1expandable,#V2expandable,#V3expandable{color:$dark;}"
".divcell { float: left; border: 1px solid $brdr; box-sizing: border-box; border-bottom:none;}"
".colname { float: left; border: 1px solid $brdr; box-sizing: border-box; border-bottom:none;}"
".divcell:hover{background:$hover; color:#ffffff;}" #$light;
".topbarClass,.footbarClass,.colname{background:$dark;color:$light;}" 
"#navbtn_*:hover{ color:$light; }"
"#navbtn_debug,#navbtn_debug a,#navbtn_debug:hover{color:gray!important;background-color:$dark!important;cursor:default;}"
   );
   $css = $css -join "";
   $css = CodeToString( $css );
   return $css;
}
<#
---------------------------------------------------------------------------------
This function is called from GetBuildsHistory.js main code to set some global
variables used later to generate HTML-code and returns updated input argument
updated with values kept in BuildHead code.
---------------------------------------------------------------------------------
#>
function SetGlobals() 
{
   $Global:RowProps = $V1RowProps;

   [string]$n = ([char]0x0d)+([char]0x0a);
   
   Set-Variable -Name NL  -Scope Global -Value $n;
   Set-Variable -Name FSZ -Scope Global -Value 17;
   Set-Variable -Name px  -Scope Global -Value "px";
}# End-of-function SetGlobals

<#
------------------------------------------------------------------------------
Function receives an array of the Builds objects and return HTML-Body code 
which presents objects properties. Header part of the same HTML code is built
by the GetBuildsHistory and written to the disk.
------------------------------------------------------------------------------
#>
function BuldHTML( $arr )
{
   function BuildMainTable( $arr )
   {
      function GetClass( $p )
      {
         $P2C = $Global:P2N;
         return $P2C.$p;
      }       
      function BuildTH( $obj )
      {   
         $tds        = "";
         $lang       = "en";
         $Translate = $Global:Translate;
         $VC         = $Global:currentView; 
         $c1         = "topBar"; 
         $c2         = "footBar"; 
         $CellOpenPattern = "<div class=""colname %pn%"">";
         if ( $Global:currentView -eq "V1" )
         {
            $tooltip = "title=""%tooltip%""";
         }
         $RowOpenTag      = "<div class=""topbarClass"" id=""$VC$c1"" $tooltip>$NL";
         $CellCloseTag    = $RowCloseTag =  "</div>$N";

         if ( $obj -eq $null )
         {
            $RowOpenTag = $RowOpenTag.Replace( "$VC$c1", "$VC$c2" );
         }
    
         $p = $Global:RowProps;
         $tds = "";
         for ( $i = 0; $i -lt $p.Length; $i++ )
         {
            $q = $p[ $i ];
            $a = GetClass( "$q" );
            $CellOpenTag = $CellOpenPattern.Replace( "%pn%", "$a" );
            if ( $obj -eq $null )
            {
               $cpy = "&copy;&nbsp;sysprg&`#64;live.ru`,&nbsp;liza.shakh&`#64;gmail`.com"+
                       "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+`
                       "This page was generated by GetBuildsHistory.ps1, $version&nbsp"              
               $tds = "<div class=""colname copyr"">&nbsp;$cpy&nbsp;</div>$NL";                      
               break;
            }
             
            elseif ( $q -eq "Unknown3" )
            {
               $v1 = "Unknown3";
               $v2 = "Unknown4";
               $v  = "<div style=""float:left;"" onclick=""switchUnknowns();"">&nbsp;$v1&nbsp;</div>"+`
               "<div style=""float:right;"" onclick=""switchUnknowns();"">&nbsp;$v2&nbsp;</div>";
            }
             
            else
            {
               $v = $Translate.$q;
#http://stackoverflow.com/questions/2011142/how-to-change-the-style-of-title-attribute-inside-the-anchor-tag
            }

            $x1 = "<!--EndOfHeader-->";
            if ( $i -eq 0 ){$x1 = "<!--EndOfFooter-->";}
            $tds += "$CellOpenTag&nbsp;$v&nbsp;$CellCloseTag";
         }
         return "$RowOpenTag$tds$RowCloseTag$x1$NL$BreakLine$NL";      
      }
      function BuildTD( $tobj )
      {
         $CellOpenPattern = "<div class=""divcell %pn%"">";
         $CellCloseTag = "</div>$NL";
         $p = $tobj.PropName;
         $a = GetClass( "$p" );
         $CellOpenTag = $CellOpenPattern.Replace( "%pn%", "$a" ); 
         $v = $tobj.Value.ToString().trim();
         if ( $a -and $a.Contains( "Date" ) )
         {
            if ( $v.Contains( "," ) )
            {
               $v  = $v -split ",";
               $v0 = ($v[0]).trim();
               $v1 = ($v[1]).trim();
               $v  = "$v1&nbsp;&nbsp;&nbsp;$v0";
            }
         }
         elseif ( $p -eq "ProductId3" )
         {
            $p  = $v.IndexOf( " " );
            $v0 = $v.Substring( 0, $p ).trim();
            $v1 = $v.Substring( $p + 1 ).trim();
            $fill = "&nbsp;&nbsp;&nbsp;";
            if ( $v0.Length -lt "55041-01781-051-124375-01-1033-10049.0000-0902015".Length )
            {
               $fill += "&nbsp;&nbsp;";
            }
            $style = "style=""font-family:Consolas;letter-spacing:0px;""";
            $v = "&nbsp;$v0$fill<font $style>&nbsp;$v1&nbsp;</font>";
         }
         
         elseif ( $p -eq "Unknown3" )
         {
            $v1 = $v;
            $v2 = ($Global:currentObj).Unknown4;
            $fixed = "font-family:Consolas;letter-spacing:0px;";
            $v  = "<div style=""float:left;display:block;"">&nbsp;$v1&nbsp;</div>"+`
            "<div style=""float:right;display:none;$fixed"">&nbsp;$v2&nbsp;</div>";
         }
         
         return "$CellOpenTag&nbsp;$v&nbsp;$CellCloseTag";
      }
      function BuildRow( $obj )
      { 
         $Global:currentObj = $obj;
         $tds = "";
         $p   = $V1RowProps;
         if( $Global:currentView -eq "V2" )
         {
            $p = $V2RowProps;
         }
         elseif( $Global:currentView -eq "V3" )
         {
            $p = $V3RowProps;
         }
         for ( $i = 0; $i -lt $p.Length; $i++ )
         {
            $q    = $p[ $i ];
            $v    = $obj.$q;
            $tds += BuildTD( @{PropName="$q";Value="$v";} );
         }
         
         $id = TagIdFromObjDate( $obj );
         return "<div class=""mr divcell"" id=""$id"" onclick=""ShowDetails(this)"">$NL"+`
         "$tds</div><!--EndOfMR-->$NL";     
      }
      $V1th1  = BuildTH( $V1RowProps );   
      $V1rows = $arr | %{BuildRow( $_ )};
      $V1th2  = BuildTH( $null );
      $V1vid  = $Global:currentView; 
      $c1 = "tablecontainer"; 
      $c2 = "expandable";
      
      $V1code = "<div id=""Main"" class=""Main"">$NL"+`
      "<div id=""$V1vid$c1"">$V1th1<div id=""$V1vid$c2"">"+`
      "$NL$V1rows</div><!--V1Expandable-->$NL"+`
      "$V1th2</div><!--V1tablecontainer-->$NL";
      
      $Global:currentView = "V2";
      $Global:RowProps = $V2RowProps;

      $Global:P2N = @{
         CurrentBuild = "Build";      # 15007
         ProductId2   = "ProductId2"; # [Blue]res-v2600
         ProductId    = "ProductId";  # 00260-00709-22436-AA664
         ProductId3   = "ProductId3"; # 00000-02600-070-922436-00-1033-9200.0000-3102015  (Fri, 06.11.2015)
      };

      $Global:Translate = @{
         CurrentBuild = "Build";
         ProductId2   = "ProductId2";
         ProductId    = "ProductId";
         ProductId3   = "ProductId3";
      } 

      $V2th1  = BuildTH( $V2RowProps );   
      $V2rows = $arr | %{BuildRow( $_ )};
      $V2th2  = BuildTH( $null );
      $V2vid  = $Global:currentView; 

      $V2code = "<div id=""$V2vid$c1"">$V2th1<div id=""$V2vid$c2"">"+`
      "$NL$V2rows</div><!--V2Expandable-->$NL"+`
      "$V2th2</div><!--V2tablecontainer-->$NL";##</div><!--Main-->$NL";

      $Global:currentView = "V3";
      $Global:RowProps = $V3RowProps;

      $Global:P2N = @{
         CurrentBuild = "Build";     
         Unknown1 = "Unknown1"; 
         Unknown2 = "Unknown2"; 
         Unknown3 = "Unknown3";
         Unknown4 = "Unknown4";          
      };

      $Global:Translate = $Global:P2N;  

      $V3th1  = BuildTH( $V3RowProps );   
      $V3rows = $arr | %{BuildRow( $_ )};
      $V3th2  = BuildTH( $null );
      $V3vid  = $Global:currentView; 

      $V3code = "<div id=""$V3vid$c1"">$V3th1<div id=""$V3vid$c2"">"+`
      "$NL$V3rows</div><!--V3Expandable-->$NL"+`
      "$V3th2</div><!--V3tablecontainer-->$NL</div><!--Main-->$NL";      
      return "$V1code$V2code$V3code";
      
   }# End-Of-BuildMainTable( $arr ), central function
   
   function BuildBottomTable
   {
      $sz = $FSZ - 2;
      $comp = "";
      for ( $i = 0; $i -lt $CompInfo.Length; $i++ )
      {
         $lr = $CompInfo[$i] -split ":";
         $l  = $lr[0].trim();
         $r  = $lr[1].trim();
         $comp += "<tr><td>&nbsp;$l&nbsp;</td><td>&nbsp;$r&nbsp;</td></tr>$NL";
      }
      $sz = $FSZ - 2;
      $lcell =  "<table id=""Computer"" style=""font-size:$sz$px;"">$NL$comp</table>";
      $Global:Stamps += TimeStamp( "HTML creation is finished" );
      $stmp = "";
      for ( $i = 0; $i -lt $Global:Stamps.Length; $i++ )
      {
         $v = $Global:Stamps[$i] -Split "]";
         $stmp += "<tr><td>&nbsp;" + $v[0].Substring( 1 ) + "&nbsp;</td>" +`
                   "<td>&nbsp;" + $v[1] + "&nbsp;</td></tr>$NL"
      }
      $rcell = "<table id=""RunStamps"" style=""font-size:$sz$px;"">$stmp</table>"; 
      return "<table><tr><td>$lcell</td><td>$rcell</td></tr></table>";      
   }
 
   function BuildHidden( $obj )
   {
      $ShowProps = @(
      "CurrentBuild","InstallDateString","UpgradeDateString","Minutes","FullDuration","Description",`
      "ProductName","ProductId","ProductId2","BuildLabEx","ProductId3","LicensingProductID",`
      "EditionID","ProductKey","CurrentVersion","ReleaseId","UBR","InstallDate","InstallTime",`
      "UpgradeDate","PSParentPath","PSChildName","RegisteredOwner","Unknown1","Unknown2","Unknown3","Unknown4" 
      ); 
      $ShowProps1 = @( 
      "CurrentBuild","InstallDateString","Minutes","Description","ProductName",`
      "ProductId","ProductId4","ProductId2","BuildLabEx","ProductId3","ProductId5",`
      "LicensingProductID","ApplicationID","DefaultProductKey","ProductKey","EditionID",`
      "CurrentVersion","ReleaseId","UBR","InstallDate","InstallTime","PSParentPath","PSChildName",
      "RegisteredOwner","Unknown1","Unknown2","Unknown3","Unknown4"      
      );

      $p = $ShowProps;
      if ( $obj.PSChildName -eq "CurrentVersion" -or [int]$obj.CurrentBuild -ge 14986 )
      {$p = $ShowProps1;}
      $tds = "";

      for ( $i = 0; $i -lt $p.Length; $i++ )
      {
         $q    = $p[$i];
         $v    = $obj.$q;
         if ( "$q" -eq "Description" )
         {
            $v = $v.Replace( "(R)", "&`#174;" );
         }

         if ( $v -ne $null )
         {
            if ( $q -eq "InstallDate" -or $q -eq "InstallTime" )
            {
               $v = FormatNumber( $v );
            }
            if ( $v -is [string] )
            {
               $v = $v.trim();
               $v = $v.Replace( " ", "&nbsp;" );
            }
            $cls  = "KeepBlanks";# 
            $tds += "<tr><td>&nbsp$q&nbsp;</td><td class=""$cls"">&nbsp;$v&nbsp;</td></tr>";
         }
      }
      $id  = (TagIdFromObjDate( $obj )).Replace("V3","");# omit V1/V2
      return "<div id=""div$id"" class=""h hc""><table><tbody>$tds</tbody></table></div>";
   }
   function BuildMenuTop()
   {
      $code = '
<ul class="navbar theme wide" id="MenuContainer">
 <li class="navbarbtns">
  <a class="hover-white padding-8" id="navbtn_file" href="#">FILE&nbsp;
  <span class="caret">6</span></a>
 </li>
 <li class="navbarbtns">
  <a class="hover-white padding-8" id="navbtn_view" href="#">VIEW&nbsp;
   <span class="caret">6</span></a>
 </li>
 <li class="navbarbtns">
  <a class="hover-white padding-8" id="navbtn_theme" href="#">THEME&nbsp;
   <span class="caret">6</span></a>
 </li>
 <li class="navbarbtns">
  <a class="hover-white padding-8" id="navbtn_lang" href="#">LANGUAGE&nbsp;
   <span class="caret">6</span></a>
 </li>
 <li class="navbarbtns" id="IgnoreMe">
  <a class="hover-white padding-8 disabled" id="navbtn_debug" href="#">EDIT&nbsp;
   <span class="caret">6</span></a>
 </li>
 <li class="right" id="About">
  <a class="hover-white padding-8 right" title="%version%" href="#">
   <i>About</i></a>
 </li>
</ul>
<!--<br/>-->
';
      return $code.Replace( "%version%", "$Version" );
   }
   function BuildMenuHidden()
   {
      return '
<div class="navbtn_content" id="navbtn_file_content">
 <div class="ContentItem" onclick="SaveSettings();">&nbsp;SAVE CURRENT SETTINGS&nbsp;</div> 
 <div class="ContentItem" onclick="MainTableToText();">&nbsp;SAVE VIEW AS TEXT FILE&nbsp;</div>
 <div class="ContentItem" onclick="closeAllWindows();">&nbsp;EXIT&nbsp;</div>
</div>
<div class="navbtn_content" id="navbtn_view_content">
 <div class="ContentItem" onclick="setView(''V1'');">&nbsp;Default&nbsp;</div>
 <div class="ContentItem" onclick="setView(''V2'');">&nbsp;Build,ProductId2,ProductId,ProductId3&nbsp;</div>
 <div class="ContentItem" onclick="setView(''V3'');">&nbsp;Build,Unkown1,Unkown2,Unkown3,Unknown4&nbsp;</div>
</div>
<div class="navbtn_content" id="navbtn_theme_content">
 <div class="ContentItem" onclick="setTheme(''Flowers'');">&nbsp;FLOWERS&nbsp;</div>
 <div class="ContentItem" onclick="setTheme(''Black'');">&nbsp;BLACK&nbsp;</div>
 <div class="ContentItem" onclick="setTheme(''Green'');">&nbsp;GREEN&nbsp;</div>
 <div class="ContentItem" onclick="setTheme(''Blue'');">&nbsp;BLUE&nbsp;</div>
 <div class="ContentItem" onclick="setTheme(''Brown'');">&nbsp;BROWN&nbsp;</div>
 <div class="ContentItem" onclick="setTheme(''Orange'');">&nbsp;ORANGE&nbsp;</div>
</div>
<div class="navbtn_content" id="navbtn_lang_content">
 <div class="ContentItem" onclick="setLang(''en'');">&nbsp;(EN-US)&nbsp;</div>
 <div class="ContentItem" onclick="setLang(''ru'');">&nbsp;(RU-RU)&nbsp;</div>
 <div class="ContentItem" onclick="setLang(''uk'');">&nbsp;(UK-UA)&nbsp;</div>
 <div class="ContentItem" onclick="setLang(''ge'');">&nbsp;(GE-GE)&nbsp;</div> 
</div>
<div class="navbtn_content" id="navbtn_edit_content">
 <div class="ContentItem" onclick="createDebugWin();">&nbsp;ColorPicker&nbsp;</div>
 <div class="ContentItem" onclick="alert(this.innerText);">&nbsp;Drevoloz&nbsp;</div>
</div>
';
   }
   $Default   = "RoseFlowers"; ### should be defined by INI file !
   $Scheme    = $ColorSchemes.$Default;
   $ColorScheme = "<style id=""ColorScheme"">$Scheme</style>"; 
   $MainTable = BuildMainTable( $arr );
   $bottom    = BuildBottomTable;
   $hidd      = $arr | %{BuildHidden( $_ ); };
   $Container = "<div id=""MainContainer"">";
   $menuTop   = BuildMenuTop;
   $menuHidd  = BuildMenuHidden;
  
   return "<body>$NL$ColorScheme$NL"+`
   "$menuTop$menuHidd<div id=""MainContainer"">$MainTable$bottom$hidd</div>$NL"+`
   "<!--MainContainer-->$NL</body></html>";  
}
################### Part parseIniUtils.ps1 #####################################
<#
---------------------------------------------------------------------------- 
 Project: GetBuildsHistory, part parseIniUtils                                               
 Version: 1.0                                                        
 FileId:  e:\Delme\!Projects\BuildsHistory\parseIniUtils.ps1                    
 When:    09 Jan 2017,  Monday,  12:36:11                           
 ©        Oleg Kulikov, sysprg@live.ru                               
---------------------------------------------------------------------------- 
#>

function TestBuildNumber( $build )
{
   $reg1 = "\d{4,5}";#"[0-9]{4,5}";
   if ( ! $build -match $reg1 )
   {
      $INILog += "TIMEZONE definition parser: Incorrect Build number $build";
      return $false;
   }
   if ( [int]$build -lt 7601 )
   {
      $INILog += "TIMEZONE definition parser: Build number .$build. is too small";
      return $false;
   }
   if ( [int]$build -gt 15999 )
   {
      $INILog += "TIMEZONE definition parser: Build number .$build. is too big";
      return $false;
   }
   return $true;
}
function GetIniSettings()
{
   [byte[]]$enc = get-content -Encoding byte -ReadCount 4 -TotalCount 4 $fn
   $data = @();
   # $config = [io.file]::ReadAllLines($fn)
   $config = Get-Content $fn;
   if ( $enc[0] -ne 35 -or $enc[1] -ne 45 -or $enc[2] -ne 45 -or $enc[3] -ne 45 )
   {
      $config | Set-Content -Encoding "Ascii" $fn;
      $config = Get-Content $fn;
   }
   for( $i = 0; $i -lt $config.Length; $i++ )
   {
      $line = ( $config[$i] -split "`#" )[0];
      if ( $line.Length )
      {
         $data += $line;
      }
   }
   return $data;
}

function ParseTimeZoneDefinition( $d )
{
   # TIMEZONE.7601-10576.IsInsider = +03:00
   $lr   = $d -split "=";
   $zone = ($lr[1]).Replace( "utc", "" ).trim();
   $reg1 = "[+-]\d{1,2}";#"[+-][0-9]{1,2}";
   $reg2 = "$reg1\:[03]0";
   $znh  = ( $zone.Substring( 1 ) -split ":" )[0];
   if ( !  ( $zone -match $reg1 -or `
              $zone -match $reg2 -or `
              $znh -gt 12 ) )
   {
      $INILog += "TIMEZONE definition parser: Incorrect TIMEZONE value $zone";
      return "";         
   }
   $lr   = ($lr[0]).trim();     
   $def  = $lr -split "\.";
   if ( ! $def -is [system.array] ){return "";}
   if ( $def.Length -lt 2 )
   {
      $INILog += "TIMEZONE definition parser: Incorrect TIMEZONE definition $d";
      return "";
   }      
   if ( $def.Length -eq 3 )
   {
      if ( "IsInsider,NotInsider".IndexOf( $def[ 2 ] ) -eq -1 )
      {
         $INILog += "TIMEZONE definition parser: Only ""[Is,Not]Insider"" permitted in TIMEZONE definition $d";
        return "";
      }
      if ( $def[ 2 ] -eq "IsInsider"  -and ! $IsInsider ){return "";}
      if ( $def[ 2 ] -eq "NotInsider" -and   $IsInsider ){return "";}
   }      
   $region = $def[ 1 ] -split "-"; 
   $t = TestBuildNumber( $region[0] );
   if ( ! $t  ){return "";}
   elseif ( $region.Length -eq 2 )
   {
      $t = TestBuildNumber( $region[1] );
      if( ! $t ){return "";}        
      if( [int]$region[1] -lt [int]$region[0] )
      {
         $INILog += "TIMEZONE definition parser: Incorrect Builds region $region"
         return "";
      }
   }
   $seconds = ( zone2seconds( $zone ) ).ToString();
   return $def[ 1 ] + "=$seconds";           
}
function BuildJS()
{
   $fn  = "GetBuildsHistory.Langs.txt";
   [string[]]$arr = Get-Content $fn;
   [string[]]$langs = @();
   #$langs += "`"en`"";
   $js = '
var LangStrings={};
LangStrings.en={};
';
   $sNames = "NativeName,FileCreated,FileUpdated,Title,Details,Tooltip,ReRunSaveSettings,SaveView,"+`
   "Exit,File,View,Theme,Language,Default,Edit,Flowers,Black,Green,Blue,Brown,Orange";

   for ( $i = 0; $i -lt $arr.Length; $i++ )
   {
      $line = ($arr[$i] -split "`#" )[0].trim();
      if ( ! $line.Length ) {continue;}

      $ll   = $line.ToLower();

      if ( $line.IndexOf( "=" ) -gt -1 )
      {
         $lr = $line -split "=";
         $ls = $lr[0].trim();
         $rs = $lr[1].trim();
      }

      if ( $ll.StartsWith( "[lang-" ) )
      {
         $cl = $ll.Substring( 6, $ll.Length - 7 );
         if ( $cl -and $cl.Length -eq 2 )
         {
            $langs += "`"$cl`"";
            $js += "LangStrings.$cl={};$NL";
            continue;
         }
      }
      elseif ( $sNames.IndexOf( $ls ) -gt -1 )
      {
         $js += "LangStrings.$cl.$ls=$rs;$NL";
      }
      elseif ( $ll.StartsWith( "[" ) )
      {
         break;
      }
   }#End-Of-For-loop
   $allLangs = ( $langs -join "," );
   $js = "var LangsPresent=[$allLangs];$NL$js";
   return $js;
}
################### Part Utils.ps1         #####################################
<#
-------------------------------------------------------------------- 
 Project: Utils                                               
 Version: 1.0                                                        
 FileId:  e:\Delme\!Projects\BuildsHistory\                    
 When:    13 Dec 2016,  Tuesday,  09:53:54                           
 (c)      Oleg Kulikov, sysprg@live.ru                               
-------------------------------------------------------------------- 
 Collection of the project independent small functions.                                                           
--------------------------------------------------------------------
#>
function Global:zone2seconds( $zone )
{
   $parts   = $zone -split ":";
   $hours   = [int]( $parts[0] );
   $seconds = $hours * 3600;
   if ( $parts.Length -eq 2 -and "00" -ne $parts[1] )
   {
      $seconds += 60 * ( [int]( $part[1] ) );
   }
   return $seconds;
}

function Global:FileTimeToString( [int64]$qw )
{
   return ( [datetime]::fromFileTime( $qw ) ).ToString( "ddd, dd.MM.yyyy HH:mm:ss" );
}

<#
---------------------------------------------------------------------------------
Function converts Reg_DWORD DateTime which presents number of the seconds since 
01.01.1970 00:00:00 into QWORD FileTime number. Constant which is used in
calculations is the number of the 100 nanosecond intervals since 01.01.1601 
till 01.01.1970. 
1 second = 1000 milliseconds = 10000 of 100-ns intervals
---------------------------------------------------------------------------------
the UNIX Epoch is January 1st, 1970 at 12:00 AM (midnight) UTC
#>
function Global:RegDWDateToFileTime( [int32]$dw )
{  
   return [int64]( ( 1000 * $dw + 11644473600000 ) * 10000 );
}
function Global:FiletimeToDWDate( [int64]$ft )
{
   return [int32]([math]::truncate( $ft - 116444736000000000 ) / 10000000 );
}
function Global:TicksToFileTime( [int64] $ticks )
{
   return $ticks - 504911376000000000;
}
function Global:TicksToString( [int64]$ticks )
{
   return FileTimeToString( TicksToFileTime( $ticks ) );
}
function Global:TimeStamp( $action )
{
   $dt = (get-date);
   $ms = ($dt.Millisecond).ToString().PadLeft(3,"0");
   $dt = $dt.ToString( "dd.MM.yyyy HH:mm:ss" );
   return "[$dt.$ms] $action";
}
function Global:GetCompInfo
{ 
   function GetRAMSize 
   {
      $q = "select Capacity From Win32_PhysicalMemory";
      $dimms = gwmi -Query $q | select @( "Capacity" );
      $ram = 0;
      $dimms | % { $ram += $_.Capacity };
      $ram = $ram / 1024 / 1024 / 1024;
      return [string]$ram + " GB";
   } 
   # detect current video resolution    
   $d = (Get-ItemProperty -Path "hklm:\SYSTEM\CurrentControlSet\Enum\DISPLAY\*\1&8713bca&0&UID0").HardwareID
   $d = $d.substring( "MONITOR\".Length );
   $d = (Get-ItemProperty -Path "hklm:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Configuration\$d*\00\00");
   $r = [string]($d."ActiveSize.cx")+"x"+[string]($d."ActiveSize.cy");

   $Comp  = Get-ItemProperty -Path "HKLM:\HARDWARE\DESCRIPTION\System\BIOS"; 
   $stone = Get-ItemProperty -Path "HKLM:\HARDWARE\DESCRIPTION\System\CentralProcessor\0";
   $Disk0 = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Disk\Enum").0;
   $d     = (Get-ItemProperty -Path "hklm:\system\CurrentControlSet\Enum\$disk0").FriendlyName;
   
   [string]$CompID = "";
   if ( $Comp.BaseBoardManufacturer  -ne $null ) { $CompID += $Comp.BaseBoardManufacturer + " "; }
   elseif ( $Comp.SystemManufacturer -ne $null ) { $CompID += $Comp.SystemManufacturer    + " "; }
   if ( $Comp.SystemVersion          -ne $null ) { $CompID += $Comp.SystemVersion         + " "; }
   elseif ( $Comp.SystemFamily       -ne $null ) { $CompID += $Comp.SystemFamily          + " "; }  
   if ( $Comp.SystemProductName      -ne $null ) { $CompID += $Comp.SystemProductName; }
   
   $Platform  = ( $CompID  -replace "\s\s*", " " );
   $Processor = ( $stone.ProcessorNameString.trim() -replace "\s\s*", " " ); 
   $DiskDrive = ( $d  -replace "\s\s*", " " );
   $RAMSize   = GetRAMSize;
   $Monitor   = "$r ( Current resolution )";

   $ML   = "DiskDrive".Length;
   $ret  = @();
   $ret += "{0,-$ML}: {1}" -f "Platform",  $Platform;
   $ret += "{0,-$ML}: {1}" -f "Processor", $Processor;
   $ret += "{0,-$ML}: {1}" -f "DiskDrive", $DiskDrive;
   $ret += "{0,-$ML}: {1}" -f "RAMSize",   $RAMSize;
   $ret += "{0,-$ML}: {1}" -f "Monitor",   $Monitor;
   
   return $ret;
}
function Global:GetRidOfBlanks( [string] $code )
{
   $s = $code -replace '([0-9a-zA-Z"]) ([0-9a-zA-Z"])','$1%%$2';
   $s = $s -replace " `#", "%%#";
   <#
   ----------------------------------------------------------------------
   "margin:           5px 0 9 0px;" => "margin:           5px%%0 9%%0px;"
   Thus following replace is necessary
   ----------------------------------------------------------------------
   #>
   $s = $s    -replace '([0-9])\s([0-9])','$1%%$2'
   return $s -replace "%%"," ";
}
function Global:CodeToString( [string] $code )
{
   $s = $code -replace '([0-9a-zA-Z"]) ([0-9a-zA-Z"])','$1%%$2';
   $s = $s -replace " `#", "%%#";
   <#
   ----------------------------------------------------------------------
   "margin:           5px 0 9 0px;" => "margin:           5px%%0 9%%0px;"
   Thus following replace is necessary
   ----------------------------------------------------------------------
   #>
   $s = $s    -replace '([0-9])\s([0-9])','$1%%$2'
   $s = $s -replace '\s*','';
   return $s -replace "%%"," ";
}
<#--End-of-File-DTConverters------------------------------------------#>

################### Part CreateTextLog.ps1 #####################################  
<#
---------------------------------------------------------------------------- 
 Project: GetBuildsHistory, part CreateTextLog.ps1                                               
 Version: 1.0                                                        
 FileId:  e:\Delme\!Projects\BuildsHistory\GBHColorSchemes.ps1                    
 When:    09 Jan 2017,  Monday,  22:11:09                           
 ©        Oleg Kulikov, sysprg@live.ru                               
---------------------------------------------------------------------------- 
Function: 
receives an array of the builds objects
returns an array of the strings
Former name of this function - Show. It was used in the
archives till December 13, 2016.
-----------------------------------------------------------------------------
#>
function BuildTextLog( $arr )
{
   function TypeArray( $arr )
   {
      $out = @();
      for ( $i = 0; $i -lt $arr.Length; $i++ )
      {
         $v = $arr[ $i ];
         $out += $v;
      }
      $out += "$NL";
      return $out;
   }
   function TypeProps( $o )
   {
      # Global variable $PropList is used to access properties
      # and values of the input object. $Proplist is set by the caller.
      $out = @();
      $MaxL = "LicensingProductID".Length;
      for ( $i = 0; $i -lt $PropList.Length; $i++ )
      {
         $pp = $p = $PropList[ $i ];
         if ( $p.StartsWith( "Install" ) -or` 
              $p.StartsWith( "Upgrade" ) )
         {
            $pp = $p.Substring( 0, $p.Length - 1 );
         }
         if ( $o.$p -ne $null )
         {
            $out += "{0,-$MaxL} : {1}" -f $pp, $o.$p;
         }
      }
      $out += "$NL$NL";
      return $out;
   }
<#
CurrentBuild       : 14986
InstallDateStrin   : Thu, 08.12.2016 14:50:58
Minutes            : 111:08
Description        : Microsoft(R) Windows(R) Operating System, Retail channel
ProductName        : Windows 10 Pro Insider Preview
ProductId          : 00330-80000-00000-AA633
ProductId4         : 00330-80000-00000-AA380
ProductId2         : [TH]X19-98841
BuildLabEx         : 14986.1000.amd64fre.rs_prerelease.161202-1928     (Fri, 02.12.2016)
ProductId3         : 55041-03308-000-000000-00-1033-14986.0000-3432016 (Thu, 08.12.2016)
ProductId5         : 00000-03308-000-000000-00-1033-14393.0000-3372016 (Fri, 02.12.2016)
DefaultProductKey  : VK7JG-NPHTM-C97JM-9MPGT-3V66T
ProductKey         : VK7JG-NPHTM-C97JM-9MPGT-3V66T
EditionID          : Professional
CurrentVersion     : 6.3
ReleaseId          : 1607
UBR                : 1000
LicensingProductID : 4de7cb65-cdf1-4de9-8ae8-e3cce27b9f2c
ApplicationID      : {55c92734-d682-4d71-983e-d6ec3f16059f}
InstallDate        : 1481194258          (0x58493B12)
InstallTime        : 131256678582433859  (0x01D25140F54DB843)
UpgradeDate        : 
PSParentPath       : SOFTWARE\Microsoft\Windows NT
PSChildName        : CurrentVersion
#>
   $ShowProps = @(
   "CurrentBuild","InstallDateString","UpgradeDateString","Minutes","Description","ProductName",`
   "ProductId","ProductId2","BuildLabEx","ProductId3","LicensingProductID",`
   "EditionID","ProductKey","CurrentVersion","ReleaseId","UBR","InstallDateS","InstallTimeS",`
   "UpgradeDateS","RegisteredOwner","PSParentPath","PSChildName","Unknown1","Unknown2","Unknown3",`
   "Unknown4"
   ); 
   $ShowProps1 = @(
   "CurrentBuild","InstallDateString","Minutes","FullDuration","Description","ProductName",`
   "ProductId","ProductId4","ProductId2","BuildLabEx","ProductId3","ProductId5",`
   "DefaultProductKey","ProductKey","EditionID","CurrentVersion","ReleaseId","UBR",`
   "LicensingProductID","ApplicationID","InstallDateS","InstallTimeS",`
   "UpgradeDateS","RegisteredOwner","PSParentPath","PSChildName","Unknown1","Unknown2","Unknown3",`
   "Unknown4" 
   );
   $out = @();              
   for ( $i = 0; $i -lt $arr.Length; $i++ )
   {
      $o = $arr[ $i ];
      if ( $i -lt $arr.Length - 1 )
      {      
         $t = $o | Select $ShowProps;
         Set-Variable PropList $ShowProps -Scope Global -Force;
         $out += TypeProps( $t );
      }
      else
      {      
         $t = $o | Select $ShowProps1;
         Set-Variable PropList $ShowProps1 -Scope Global -Force;
         $out += TypeProps( $t );
      }
   }
   $out += $CompInfo;

   return $out;
}
