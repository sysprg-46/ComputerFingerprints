<#
---------------------------------------------------------------------------- 
 Project: GetBuildsHistory, part CreateTextLog.ps1                                               
 Version: 1.0                                                        
 FileId:  e:\Delme\!Projects\BuildsHistory\GBHColorSchemes.ps1                    
 When:    09 Jan 2017,  Monday,  22:11:09                           
 ©        Oleg Kulikov, sysprg@live.ru                               
---------------------------------------------------------------------------- 
Function: 
receives an array of the builds objects
returns an array of the strings
Former name of this function - Show. It was used in the
archives till December 13, 2016.
-----------------------------------------------------------------------------
#>
function BuildTextLog( $arr )
{
   function TypeArray( $arr )
   {
      $out = @();
      for ( $i = 0; $i -lt $arr.Length; $i++ )
      {
         $v = $arr[ $i ];
         $out += $v;
      }
      $out += "$NL";
      return $out;
   }
   function TypeProps( $o )
   {
      # Global variable $PropList is used to access properties
      # and values of the input object. $Proplist is set by the caller.
      $out = @();
      $MaxL = "LicensingProductID".Length;
      for ( $i = 0; $i -lt $PropList.Length; $i++ )
      {
         $pp = $p = $PropList[ $i ];
         if ( $p.StartsWith( "Install" ) -or` 
              $p.StartsWith( "Upgrade" ) )
         {
            $pp = $p.Substring( 0, $p.Length - 1 );
         }
         if ( $o.$p -ne $null )
         {
            $out += "{0,-$MaxL} : {1}" -f $pp, $o.$p;
         }
      }
      $out += "$NL$NL";
      return $out;
   }
<#
CurrentBuild       : 14986
InstallDateStrin   : Thu, 08.12.2016 14:50:58
Minutes            : 111:08
Description        : Microsoft(R) Windows(R) Operating System, Retail channel
ProductName        : Windows 10 Pro Insider Preview
ProductId          : 00330-80000-00000-AA633
ProductId4         : 00330-80000-00000-AA380
ProductId2         : [TH]X19-98841
BuildLabEx         : 14986.1000.amd64fre.rs_prerelease.161202-1928     (Fri, 02.12.2016)
ProductId3         : 55041-03308-000-000000-00-1033-14986.0000-3432016 (Thu, 08.12.2016)
ProductId5         : 00000-03308-000-000000-00-1033-14393.0000-3372016 (Fri, 02.12.2016)
DefaultProductKey  : VK7JG-NPHTM-C97JM-9MPGT-3V66T
ProductKey         : VK7JG-NPHTM-C97JM-9MPGT-3V66T
EditionID          : Professional
CurrentVersion     : 6.3
ReleaseId          : 1607
UBR                : 1000
LicensingProductID : 4de7cb65-cdf1-4de9-8ae8-e3cce27b9f2c
ApplicationID      : {55c92734-d682-4d71-983e-d6ec3f16059f}
InstallDate        : 1481194258          (0x58493B12)
InstallTime        : 131256678582433859  (0x01D25140F54DB843)
UpgradeDate        : 
PSParentPath       : SOFTWARE\Microsoft\Windows NT
PSChildName        : CurrentVersion
#>
   $ShowProps = @(
   "CurrentBuild","InstallDateString","UpgradeDateString","Minutes","Description","ProductName",`
   "ProductId","ProductId2","BuildLabEx","ProductId3","LicensingProductID",`
   "EditionID","ProductKey","CurrentVersion","ReleaseId","UBR","InstallDateS","InstallTimeS",`
   "UpgradeDateS","PSParentPath","PSChildName","Unknown1","Unknown2","Unknown3","Unknown4"
   ); 
   $ShowProps1 = @(
   "CurrentBuild","InstallDateString","Minutes","FullDuration","Description","ProductName",`
   "ProductId","ProductId4","ProductId2","BuildLabEx","ProductId3","ProductId5",`
   "DefaultProductKey","ProductKey","EditionID","CurrentVersion","ReleaseId","UBR",`
   "LicensingProductID","ApplicationID","InstallDateS","InstallTimeS",`
   "UpgradeDateS","PSParentPath","PSChildName","Unknown1","Unknown2","Unknown3","Unknown4" 
   );
   $out = @();              
   for ( $i = 0; $i -lt $arr.Length; $i++ )
   {
      $o = $arr[ $i ];
      if ( $i -lt $arr.Length - 1 )
      {      
         $t = $o | Select $ShowProps;
         Set-Variable PropList $ShowProps -Scope Global -Force;
         $out += TypeProps( $t );
      }
      else
      {      
         $t = $o | Select $ShowProps1;
         Set-Variable PropList $ShowProps1 -Scope Global -Force;
         $out += TypeProps( $t );
      }
   }
   $out += $CompInfo;

   return $out;
}