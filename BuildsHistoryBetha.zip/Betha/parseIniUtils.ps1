<#
---------------------------------------------------------------------------- 
 Project: GetBuildsHistory, part parseIniUtils                                               
 Version: 1.0                                                        
 FileId:  e:\Delme\!Projects\BuildsHistory\parseIniUtils.ps1                    
 When:    09 Jan 2017,  Monday,  12:36:11                           
 ©        Oleg Kulikov, sysprg@live.ru                               
---------------------------------------------------------------------------- 
#>

function TestBuildNumber( $build )
{
   $reg1 = "\d{4,5}";#"[0-9]{4,5}";
   if ( ! $build -match $reg1 )
   {
      $INILog += "TIMEZONE definition parser: Incorrect Build number $build";
      return $false;
   }
   if ( [int]$build -lt 7601 )
   {
      $INILog += "TIMEZONE definition parser: Build number .$build. is too small";
      return $false;
   }
   if ( [int]$build -gt 15999 )
   {
      $INILog += "TIMEZONE definition parser: Build number .$build. is too big";
      return $false;
   }
   return $true;
}
function GetIniSettings()
{
   $data = @();
   # $config = [io.file]::ReadAllLines($fn)
   $config = Get-Content $fn;
   for( $i = 0; $i -lt $config.Length; $i++ )
   {
      $line = ( $config[$i] -split "`#" )[0];
      if ( $line.Length )
      {
         $data += $line;
      }
   }
   return $data;
}

function ParseTimeZoneDefinition( $d )
{
   # TIMEZONE.7601-10576.IsInsider = +03:00
   $lr   = $d -split "=";
   $zone = ($lr[1]).Replace( "utc", "" ).trim();
   $reg1 = "[+-]\d{1,2}";#"[+-][0-9]{1,2}";
   $reg2 = "$reg1\:[03]0";
   $znh  = ( $zone.Substring( 1 ) -split ":" )[0];
   if ( !  ( $zone -match $reg1 -or `
              $zone -match $reg2 -or `
              $znh -gt 12 ) )
   {
      $INILog += "TIMEZONE definition parser: Incorrect TIMEZONE value $zone";
      return "";         
   }
   $lr   = ($lr[0]).trim();     
   $def  = $lr -split "\.";
   if ( ! $def -is [system.array] ){return "";}
   if ( $def.Length -lt 2 )
   {
      $INILog += "TIMEZONE definition parser: Incorrect TIMEZONE definition $d";
      return "";
   }      
   if ( $def.Length -eq 3 )
   {
      if ( "IsInsider,NotInsider".IndexOf( $def[ 2 ] ) -eq -1 )
      {
         $INILog += "TIMEZONE definition parser: Only ""[Is,Not]Insider"" permitted in TIMEZONE definition $d";
        return "";
      }
      if ( $def[ 2 ] -eq "IsInsider"  -and ! $IsInsider ){return "";}
      if ( $def[ 2 ] -eq "NotInsider" -and   $IsInsider ){return "";}
   }      
   $region = $def[ 1 ] -split "-"; 
   $t = TestBuildNumber( $region[0] );
   if ( ! $t  ){return "";}
   elseif ( $region.Length -eq 2 )
   {
      $t = TestBuildNumber( $region[1] );
      if( ! $t ){return "";}        
      if( [int]$region[1] -lt [int]$region[0] )
      {
         $INILog += "TIMEZONE definition parser: Incorrect Builds region $region"
         return "";
      }
   }
   $seconds = ( zone2seconds( $zone ) ).ToString();
   return $def[ 1 ] + "=$seconds";           
}
function GetThemeBackgrounds( $arr )
{
   ;
}
function BuildJS( $arr )
{
   [string[]]$langs = @();
   $langs += "`"en`"";
   $js = '
var LangStrings={};
LangStrings.en={};
LangStrings.en.NativeName="English";
LangStrings.en.Title="History contains %NN% upgrades since %date1% till %date2%";
LangStrings.en.Details="All properties for the Build %bld%";
LangStrings.en.Tooltip="Build,Install Date,Upgrade Date,Product Name,Branch,Service Pack,Minutes";   
';
   for ( $i = 0; $i -lt $arr.Length; $i++ )
   {
      $line = $arr[$i];
      $ll = $line.ToLower();
      if ( $ll.StartsWith( "[lang-" ) )
      {
         $cl = $ll.Substring( 6, $ll.Length - 7 );
         if ( $cl -and $cl.Length -eq 2 )
         {
            $langs += "`"$cl`"";
            $js += "LangStrings.$cl={};$NL";
         }
      }
      elseif ( $ll.StartsWith( "nativename" ) )
      {
         $val = ( $line -split "=" )[1].trim();
         $js += "LangStrings.$cl.NativeName=$val;$NL";
      }
      elseif ( $ll.StartsWith( "title" ) )
      {
         $val = ( $line -split "=" )[1].trim();
         $js += "LangStrings.$cl.Title=$val;$NL";
      }
      elseif ( $ll.StartsWith( "details" ) )
      {
         $val = ( $line -split "=" )[1].trim();
         $js += "LangStrings.$cl.Details=$val;$NL";
      }
      elseif ( $ll.StartsWith( "tooltip" ) )
      {
         $val = ( $line -split "=" )[1].trim();
         $js += "LangStrings.$cl.Tooltip=$val;$NL";
      }
      elseif ( $ll.StartsWith( "[" ) )
      {
         break;
      }
   }#End-Of-For-loop
   $allLangs = ( $langs -join "," );
   $js = "var LangsPresent=[$allLangs];$NL$js";
   $js | Set-Content -Encoding Unicode .\LangStrings.js
   if ( $i -lt $arr.Length )
   {
      $ll = $arr[$i].ToLower();
      if ( $ll.StartsWith( "[theme-" ) )
      {
         $l = $arr.Length;
         $a = $arr[$i..$l];
         GetThemeBackgrounds( $a );
      }
   }
}
