<#
--------------------------------------------------------------------------------- 
Project: BuildsHistory                                               
Version: 1.0                                                         
FileId:  f:\Delme\CleanBCD\BuildsHistory                             
When:    October 10, 2016,  Monday,  09:28, Windows build 14942                             
©        Oleg Kulikov, sysprg@live.ru                                                                                          
--------------------------------------------------------------------------------- 
This is PShell version of the BuildsHistory.js which was finished at
October 7, 2016, some hours before Build 14942 became available at WU servers.
--------------------------------------------------------------------------------- 
10.0.14393.321
[MAJOR VERSION].[MINOR VERSION].[BUILD NUMBER].[REVISION NUMBER]
---------------------------------------------------------------------------------
ESD/ISO names structure
<build>.<revision>.<architecture>.<branch>.<timestamp>_<skufamily>_<sku>_<language>.ESD
8250.0.amd64chk.winmain_win8beta.120217-1520_client_professional_en-us.iso
---------------------------------------------------------------------------------
2016.12.11 Set encoding UNICODE to enable opportunity to handle Russian strings
TicksToFileTime and TicksToString functions implemented
File c:\$WINDOWS.~BT\Sources\SetupPlatform.ini contains timestamps in ticks which
can be read and analyzed.
--
Monday,   December 12, 2016 23:21:00
Function Show is excluded as XML and HTA are created. But it appereared that
XML Export decides that obj.InstallDate, obj.InstallTime, obj.UpgradeDate
are integers despite these properties were already converted to strings and
Show log, HTA demonstrate it. Thus it is necessary to change type of these
data in the AddProperties function.
--
Tuesday, December 13, 2016. Have splitted source on 3-parts: 
Utils.ps1    - collection of project independent functions
GBHUtils.ps1 - BuildsHistory functions. Former Show function was renamed
to BuildTextLog and included into GBHUtils.ps1 with some changes according
to 3 new properties defined and with exclusion of the FormatNumber calls as
this function is called from AddProperties.
GetBuildsHistory.ps1 - this one.
Created 3 new properties: InstallDateS, InstallTimeS, UpgradeDateS which
are renamed to the same without trailing 'S' in the text-log and in HTA.
These properties are not exporeted into XML.
All of the code from the loop in Main section which was run AFTER call
of the AddProperties, were moved into the AddProperties.
Improved Details presentation by changes in GBHUtils.
--
Wednesday, December 14, 2016. Well, HTA is started by the last line
of this code. GBHUtils have improved footer line.
Saturday, December 17, 2016. GBHColorSchemes.ps1 implemented. All color
styles are placed now in the body Style tag. JS code can now change
ColorSchemes replacing innerHTML of that Style tag.
--
Wednesday, December 22, 2016. All problems with implementing toolbar
was fixed and Color Theme selection runs fine.
--
Friday, December 23, 2016. INI-file changed: some new sections were
implemented and commented. PLAN: create and implement ASAP Views to
edit and TEST color scheme parameters ( colors ) and GEOMETRY which
strongly depends on the language selection for non-latin alphabeth languages.
Remove all the native language strings from the PShell code to INI-file
and JS-code which HAS NO problems with keeping and handling Unicode strings.
HAD to finish till NY.
--
Saturday, December 24, 2016. 17:23. Color inversion for HOVER items enabled as 
in Toolbar as in Maintable. The same border color is used for MainTable header,
footer and data rows -> one color less. But minor problems:
1. header borders are 1-2 pixels left of those of data rows
2. for the toolbar HOVER items only text content gets necessary color
3. toolbar has no border at all though SHOULD HAS.
4. Yet don't know which width toolbar should have: MainTable WITH or WITHOUT
   scrollbar. Seems better WITH scrollbar width but what about toolbar 
   border in this case?
--
Monday, January 09, 2017. Current Build number is still 14986 but can be
changed this week. What was implemented, improved since December 24:
1. color-picker page ( color.html ) was created but is not yet ready to
   change colors of the parent page;
2. drevolaz had to be rewritten
3. due to 1 & 2, Debugger item in menu is shown as disabled
4. One main color is used now
5. Details are presented in popup window.
 
What is not yet implemented:
1. Onload update of the Language strings and usage of those strings in HTML DONE
2. Saving of the current view as a text                                     DONE
3. additional views.
4. Reading & using previously created XML
5. Some more themes.                                                        DONE
6. background URL / Image support
Item 1 - is implemented for the titles and tooltip which is also a title :)
language selection runs fine though got a lot of time and required creation
of an external JS-code which has encoding Unicode. 
Have saved two of the sources which were in encoded Unicode as ascii.
--
Wensday, January 11, 2017, Build 15002 was issued at Monday, had to finish
this week. New plans:
1. Ini-file editor in a new window.
2. DIAGCAB instead of cmd-file!
3. Additional views.

-----------------------------------------------------------------------------
#>
. '.\parseIniUtils.ps1'   # Load collection of the once-used functions
. '.\utils.ps1'           # Load collection of the project independent functions
. '.\CreateTextLog.ps1'   # Load text log creation function
. '.\GBHColorSchemes.ps1' # Load collection of HTA styles
. '.\GBHUtils.ps1'        # Load collection of the project functions

<#
if ($items.$architecture.SetupESDs -is [system.array])
$sw = [System.Diagnostics.Stopwatch]::StartNew();
[long]$secselapsed = [long]($sw.elapsedmilliseconds.ToString())/1000; 
$sw.Stop(); 
$sw.Reset();
#>  
#----------------- Define and set some variables with a Global scope ---------------------------
$version = "1.01.15002"; 
Set-Variable Version -Scope Global -Value $version;                                                                                         
$p = "HARDWARE\DESCRIPTION\System\MultifunctionAdapter\0\DiskController\0\DiskPeripheral\0\";  
$Disk1 = ( get-itemproperty -path HKLM:\$p ).Identifier;                            
Set-Variable DiskId    -Scope Global -Value $Disk1; 

$p  = "SOFTWARE\Microsoft\Windows NT\CurrentVersion";
$cv = ( get-itemproperty -path HKLM:\$p ).CurrentBuild;
Set-Variable CurrentBuild -Scope Global -Value $cv;
Set-Variable LogFN     -Scope Global -Value "R500D$cv"; 

$arr = @();
Set-Variable CompInfo  -Scope Global -Value $arr;
Set-Variable RunLog    -Scope Global -Value $arr;
Set-Variable TimeZones -Scope Global -Value $arr;
Set-Variable TimeZoneDefs -Scope Global -Value $arr;

$dt   = get-date;
$zone = "{0:zzz}" -f $dt;
Set-Variable CurrentTIMEZONE -Value $zone -Scope Global;
$dw   = "{0:x}" -f ( FiletimeToDWDate( $dt.ToFileTime() ) );
Set-Variable StartTime -Scope Global -Value $dw;
$seconds = ( zone2seconds( $CurrentTIMEZONE ) ).ToString();
Set-Variable CurrentTIMEZONESeconds -Value $seconds -Scope Global;

$p = "SOFTWARE\Microsoft\WindowsSelfHost\Applicability";
$p = ( get-itemproperty -path HKLM:\$p ).IsBuildFlightingEnabled;

Set-Variable IsInsider -Scope Global -Value $p;
Set-Variable LANG      -Scope Global -Value "en";
Set-Variable THEME     -Scope Global -Value "flowers";
Set-Variable INILog    -Scope Global -Value $arr; 

[string]$n = ([char]0x0d)+([char]0x0a);  
Set-Variable -Name NL -Scope Global  -Value $n;

$CompInfo = GetCompInfo;
<#
--------------------------------------------------------------
Reading and parsing INI-file if it is present in the current
directory: GetBuildsHistory.ini should be created in the
directory in which GetBuildsHistory.ps1 resides.
--------------------------------------------------------------
#>
$fn = "GetBuildsHistory.ini";### Current path is supposed
if ( Test-Path $fn )
{

   $config = GetIniSettings;
   $TimeZoneDefs = @();
   $inSettings = $false;
   for( $i = 0; $i -lt $config.Length; $i++ )
   {
      $line = $config[$i].trim().ToLower();
      if ( $line -eq "[settings]" )
      {
         $inSettings = $true;
         break;
      }     
   }
   $j = $i + 1;
   for( $i = $j; $i -lt $config.Length; $i++ )
   {
      $line = $config[$i];
      $ll   = $line.ToLower();
      if ( $ll.StartsWith( "[lang-" ) ) 
      { 
         $inSettings = $false;
         $j = $i;
         break;
      }      
      if ( $inSettings )
      {
         if( $ll.IndexOf( "=" ) -eq -1 ) 
         {
            $INILog += "Incorrect statement $line";
            continue;
         }
         $val = ( $ll -split "=" )[1].trim(); 
         if ( $ll.StartsWith( "timezone." ) )     
         { 
            $val = ParseTimeZoneDefinition( $line );
            if ( $val )
            {
               $TimeZoneDefs += $val;
            }
         }
         elseif ( $ll.StartsWith( "textlog" ) )
         {
            if ( $val -eq "0" -or $val -eq "1" )
            {
               $val = ( $val -eq "1" );
               Set-Variable NeedTextLog -Scope Global -Value $val;
            }
         }
         elseif ( $ll.StartsWith( "lang" ) )
         {
            if ( "en,ru,uk,ge".IndexOf( $val ) -gt -1 )
            {
               Set-Variable LANG -Scope Global -Value $val;
            }
         }
         elseif ( $ll.StartsWith( "theme" ) )
         {
            if ( "pink,flowers".IndexOf( $val ) -gt -1 )
            {
               Set-Variable THEME -Scope Global -Value $val;
            }
         }
      }#End-Of-If-inSettings;   
   }#End-Of-For-Config-lines-Loop;
   $INILog += "LANG assigned value $LANG";
   $INILog += "THEME assigned value $THEME"
   $INILog += "LANG assigned value $LANG"
   $INILog += "NeedTextLog assigned value $NeedTextLog"
   $l = $config.Length;
   $arr = $config[$i..$l];
   BuildJS( $arr );
}#End-Of-if(Test-Path $fn);

#----------------------End-of-Globals-----------------------------

<#
---------------------------------------------------------------------------------
Function receives Builds object and return string presenting 
ProductKey or 5 groups of "BBBBB" separated by dash.
November 23, 2016. Adopt version of the same function which is used in
\!Projects\ProductKey\ShowProductKey.ps1
---------------------------------------------------------------------------------
#>
Function GetProductKey( $obj )                                                    
{                                                                                           
   function DecryptWindowsKey( [byte[]]$ByteArray )
   {              #0-9abcdef01234567
      $TrTable = "BCDFGHJKMPQRTVWXY2346789"
      $TrTabL  = $TrTable.Length;
      $RawData = $ByteArray;
      $Last    = $RawData.Length - 1;
      
      [bool]$isWin8 = ( ( $RawData[ $Last ] -shr 3 ) -band 1 );                                                           
      $RawData[ $Last ] = $RawData[ $Last ] -band 0xF7; 
       
      $PK = "";                                                                                    
      for ( $i = $TrTabL; $i -ge 0; $i-- )                                                                   
      {                                                                                                 
         $TrTabIndex = 0;                                                                                        
         for ( $j = $Last; $j -ge 0; $j-- )                                                                
         {
            $TrTabIndex = $TrTabIndex -shl 8 -bxor $RawData[ $j ];                                                      
            $RawData[ $j ] = [Math]::Truncate( $TrTabIndex / $TrTabL );            
            $TrTabIndex = $TrTabIndex % $TrTabL            
         }                                                                                              
         $PK = $TrTable[ $TrTabIndex ] + $PK;                                                                    
      }                                                                                                                                                                                        
                                                                                                        
      if ( $isWin8 )                                                                              
      {
         $i = $TrTable.indexOf( $PK.Substring( 0, 1 ) );                                                                                                                                       
         $PK = $PK.Substring( 1 ).Insert( $i,'N' );                                                                                  
      }                                                                                                 
                                                                                                        
      return "" +`                                                                                      
             $PK.Substring(  0, 5 ) + "-" +`                                                            
             $PK.Substring(  5, 5 ) + "-" +`                                                            
             $PK.Substring( 10, 5 ) + "-" +`                                                            
             $PK.Substring( 15, 5 ) + "-" +`                                                            
             $PK.Substring( 20, 5 );                              
   }#End-of-DecryptWindowsKey 
   
   return DecryptWindowsKey( $obj.DigitalProductId[52..66] );  
}#-end-of-GetProductKey

<#
-------------------------------------------------------------------------
Fuction is called after an array of the objects is already sorted.
Function creates some properties for the objects returned from the
Registry. It also changes some propeties values. 
-------------------------------------------------------------------------
#>
function AddProperties( [pscustomobject]$o )
{
   function ByteArrayToString( [byte[]]$arr )
   {
      return ([char[]]$arr -join "").Replace( "`0", "" );
   }
   function GetProductId3( [byte[]]$arr ) 
   {
      $d   = ByteArrayToString( $arr ); 
      $t   = $d.split( "-" )[ 7 ];
      $day = [int]$t.Substring( 0, 3 ) - 1;
      $dat = [datetime]( "01/01/" + $t.Substring( 3 ) );
      $t   = (Get-Date $dat).AddDays( $day ).ToString( "ddd, dd.MM.yyyy" );
      $l   = "55041-01781-051-124375-01-1033-10049.0000-0902015".Length;
      return "{0,-$l} ({1})" -f $d, $t; 
   }
   function GetBuildLabExDate( $str )
   {  # 9600.17668.amd64fre.winblue_r8.150127-1500
      $dt = $str.split( "." )[4];
      $dt = $dt.Substring( 4, 2 ) + "." + $dt.Substring( 2, 2 ) + "." +`
      "20" + $dt.Substring( 0, 2 ) + " " + $dt.Substring( 7, 2 ) + ":" +`
      $dt.Substring( 9, 2 ) + ":00";
      return ( get-date $dt ).ToString( "ddd, dd.MM.yyyy" );
   }
   function ArrayToHexString( $a )
   {
      return [System.BitConverter]::ToString( $a ).Replace( "-", "" );
   }
   Add-Member -InputObject $o -type NoteProperty -name Minutes            -value "";
   Add-Member -InputObject $o -type NoteProperty -name UpgradeDate        -value [int32]0;
   Add-Member -InputObject $o -type NoteProperty -name UpgradeDateString  -value "";
   Add-Member -InputObject $o -type NoteProperty -name UpgradeDateS       -value "";
   Add-Member -InputObject $o -type NoteProperty -name InstallDateString  -value "";
   Add-Member -InputObject $o -type NoteProperty -name InstallDateS       -value "";
   Add-Member -InputObject $o -type NoteProperty -name InstallTimeS       -value "";
   Add-Member -InputObject $o -type NoteProperty -name Description        -value "";
   Add-Member -InputObject $o -type NoteProperty -name ProductId2         -value "";
   Add-Member -InputObject $o -type NoteProperty -name ProductId3         -value "";
   Add-Member -InputObject $o -type NoteProperty -name LicensingProductID -value "";
   Add-Member -InputObject $o -type NoteProperty -name ProductKey         -value "";
   Add-Member -InputObject $o -type NoteProperty -name Unknown1           -value "";
   Add-Member -InputObject $o -type NoteProperty -name Unknown2           -value "";
   Add-Member -InputObject $o -type NoteProperty -name Unknown3           -value "";
   Add-Member -InputObject $o -type NoteProperty -name Unknown4           -value "";
   
   $o.ProductId2         = ByteArrayToString( $o.DigitalProductID[36..51] );
   $o.ProductId3         = GetProductId3(     $o.DigitalProductID4[008..108] );
   $o.LicensingProductID = ByteArrayToString( $o.DigitalProductID4[136..208] ); 
   $c = ByteArrayToString(                    $o.DigitalProductID4[0x3f8..0x46f] );
   $o.Description        = "Microsoft(R) Windows(R) Operating System, $c channel";
   $o.ProductKey         = GetProductKey( $o );

   $o.Unknown1 = ArrayToHexString( $o.DigitalProductId[0x048..0x050]  );
   $o.Unknown2 = ArrayToHexString( $o.DigitalProductId[0x0a0..0x0a3]  );
   $o.Unknown3 = ArrayToHexString( $o.DigitalProductId4[0x338..0x357] );
   $o.Unknown4 = ArrayToHexString( $o.DigitalProductId4[0x358..0x377] ); 
   
   if ( $o.PSPath.EndsWith( "CurrentVersion" ) )
   {
      $cv = "SOFTWARE\Microsoft\Windows NT\CurrentVersion";
      $p  = "$cv\SoftwareProtectionPlatform\GenuineApps\";
      $d  = ( get-childItem hklm:\"$p*" ).Name.Substring( "HKEY_LOCAL_MACHINE\$p".Length );
      Add-Member -InputObject $o -type NoteProperty -name ApplicationID -value $d;
      $Need = @( "ProductId", "DigitalProductId", "DigitalProductId4" );
      $od   = ( get-itemproperty HKLM:\"$cv\DefaultProductKey" -Name $Need );
      Add-Member -InputObject $o -type NoteProperty -name ProductId4 -value "";
      Add-Member -InputObject $o -type NoteProperty -name ProductId5 -value "";
      Add-Member -InputObject $o -type NoteProperty -name DefaultProductKey -value "";
      $o.ProductId4        = $od.ProductId;
      $o.ProductId5        = GetProductId3(     $od.DigitalProductID4[008..108] );
      $o.DefaultProductKey = GetProductKey( $od );
      
      if ( Test-Path c:\"`$Windows`.`~BT" )########### IS NOT USED ###############
      {
         #$prf  = $dir.Name;
         $prf  = "`$Windows`.`~BT";
         $log  = get-item c:\"$prf\Sources\Diagnostics";
         $dat  = get-item c:\"$prf\Sources\Diagnostics\diagnostics.dat";
         $durn = [long]$dat.LastWriteTime.ToFileTime() - [long]$log.CreationTime.ToFileTime();
         $durf = [math]::truncate( $durn / 10000000 ); # seconds
         $durm = [math]::truncate( $durf / 60 ); # minutes
         $durs = ($durf % 60).ToString().PadLeft( 2, "0" );
         $dur  = "$durm`:$durs";         
         #Add-Member -InputObject $o -type NoteProperty -name FullDuration -value "$dur";
         # $dur is two seconds less then the $Seconds value. Thus it is necessary to find
         # othe file.         
      }      
   } 

   if ( [int]( $o.CurrentBuild ) -lt 10122 )
   {
      $tmp = $o.BuildLabEx.split( "." );
      $ubr = $tmp[ 1 ];
      $bb  = $tmp[ 3 ];
      Add-Member -InputObject $o -type NoteProperty -name UBR -value $ubr;
      Add-Member -InputObject $o -type NoteProperty -name BuildBranch -value " $bb";
   } 
   if ( $o.InstallTime -eq $null )## BuildNumber less them 9841
   {
      Add-Member -InputObject $o -type NoteProperty -name InstallTime -value 1427802253;   
      $o.InstallTime = RegDWDateToFileTime( $o.InstallDate ); 
   } 
   $o.UBR = $o.UBR.ToString(); 
   $o.InstallDateString = FileTimeToString( $o.InstallTime );  
   # Update property BuildLabEx
   $d = GetBuildLabExDate( $o.BuildLabEx );
   $l = "55041-01781-051-124375-01-1033-10049.0000-0902015".Length;
   $o.BuildLabEx = ("{0,-$l} ({1})" -f $o.BuildLabEx, $d); 
   $pp = "Microsoft.PowerShell.Core\Registry::HKEY_LOCAL_MACHINE\".Length; 
   $o.PSParentPath = $o.PSParentPath.Substring( $pp );
   $o.InstallDateS = FormatNumber( $o.InstallDate );
   $o.InstallTimeS = FormatNumber( $o.InstallTime ); 
   if ( $o.PSChildName.Substring( 0, 3 ) -eq "Sou" )
   {
      $o.UpgradeDate       = DateStringToSeconds( $o );
      $o.UpgradeDateString = FileTimeToString( RegDWDateToFileTime( $o.UpgradeDate ) );
      $o.UpgradeDateS      = FormatNumber( $o.UpgradeDate );
   }   
   return $o;
}

## https://www.tutorialspoint.com/xaml/xaml_layouts.htm
#------------------------- Builds objects collecting starts ---------------------------------

$Global:Stamps = @();

# Some properties of the Build object read from the Registry are not used
$Omit = @( "BuildGUID","BuildLab","CompositionEditionID","CurrentBuildNumber",`
"CurrentMajorVersionNumber","CurrentMinorVersionNumber","CurrentType","Customizations",`
"EditionID","InstallationType","PathName","RegisteredOrganization","RegisteredOwner",`
"SoftwareType","SystemRoot","MigrationScope" );

$Need = @( "BuildBranch","BuildLabEx","CurrentBuild","CurrentVersion","DigitalProductId",`
"DigitalProductId4","EditionID","InstallDate","InstallTime","ProductId","ProductName",`
"ReleaseId","SoftwareType","UBR" );

$Global:Stamps += TimeStamp( "Started" );   

$temp  = ( get-itemproperty HKLM:\SYSTEM\Setup\"Source OS*" -Name $Need -EA SilentlyContinue ); 
$temp += ( get-itemproperty HKLM:\SOFTWARE\Microsoft\"Windows NT\CurrentVersion" -Name $Need );

$Global:Stamps += TimeStamp( "Builds objects collecting finished" );
                     
### SORT an array of the Build objects
$temp = ( $temp | Sort-Object -Property InstallDate );

$MaxL  = "Windows 10 Pro Technical Preview".Length;
$DateL = "13.10.2016 21:23:31".Length;
$FreeUpgrade = [int]$temp[0].CurrentBuild -lt 9841;

for ( $i = 0; $i -lt $temp.Length; $i++ )
{
   $obj = AddProperties( [pscustomobject]$temp[ $i ] );
   
   if ( [int]$obj.CurrentBuild -le 10240 )
   {
      if ( $FreeUpgrade -and $temp[ $i ].ProductKey.Split( "-" )[ 4 ] -eq `
      $temp[ 0 ].ProductKey.Split( "-" )[ 4 ] )
      {
         $p = $temp[ $i ].ProductKey.Substring( 24 );
         $temp[ $i ].ProductKey = "XXXXX-XXXXX-XXXXX-XXXXX-$p";
      }
   }
   if ( $i -gt 0 )
   {
      $obj.Minutes = [math]::truncate( ( $obj.InstallDate - $temp[ $i - 1 ].UpgradeDate ) / 60 );
      $seconds     = ( $obj.InstallDate - $temp[ $i - 1 ].UpgradeDate ) % 60;
      $seconds     = $seconds.ToString().PadLeft( 2, "0" ); 
      $obj.Minutes = $obj.Minutes.ToString() + ":" + $seconds;
   }   
   $temp[ $i ] = $obj; # update Array element   
}
## Encodings: Unicode, UTF8, UTF32, Ascii
$nbld  = $temp.Length;
$nupg  = $nbld - 1;
$date1 = $temp[ 0 ].InstallDateString;
$date2 = $temp[ $temp.Length - 1 ].InstallDateString;
$loop ='
var lang;
for(var i = 0; i < LangsPresent.length; i++ )
{
   lang=LangsPresent[i];
   LangStrings[lang].Title=LangStrings[lang].Title.replace("%NN%",NUpgrades);
   LangStrings[lang].Title=LangStrings[lang].Title.replace("%date1%",date1);
   LangStrings[lang].Title=LangStrings[lang].Title.replace("%date2%",date2);
   LangStrings[lang].Tooltip=LangStrings[lang].Tooltip.replace(/,/g,''\n'');
}
// set lang value to system language
lang=(window.navigator.userLanguage||window.navigator.language).substr(0,2).toLowerCase();
function implementLangStrings()
{
   document.getElementById("topBar").title = LangStrings[lang].Tooltip;
   document.getElementsByTagName("title")[0].innerText = LangStrings[lang].Title; 
   var langMenuItems = document.getElementById("navbtn_lang_content").getElementsByClassName("ContentItem");
   for ( var i = 0; i < langMenuItems.length; i++ )
   {
      var o = langMenuItems[i];
      var t = o.innerText;
      var l = t.substr( 1 + t.indexOf( "(" ), 2 ).toLowerCase();
      if( LangStrings[l] ) o.innerText += LangStrings[l].NativeName;
   }
}
function setLang( lang )
{
   document.getElementById("topBar").title = LangStrings[lang].Tooltip;
   document.getElementsByTagName("title")[0].innerText=LangStrings[lang].Title;
   currentLang = lang;// global variable in header inline js-code 
   return false;
}
';
$js = @(
"var NUpgrades=$nupg;"
"var date1=""$date1"";"
"var date2=""$date2"";"
)+$loop;
$js | Add-Content -Encoding Unicode .\LangStrings.js;

$Title = "History contains $nupg upgrades since $date1 till $date2";
$RunLog += "$Title$NL";
$Global:Title = $Title;

$Global:Stamps += TimeStamp( "Builds objects array is ready to be logged" );

##$NeedTextLog = $false; # read it from INI-file !

if ( $NeedTextLog )
{
   $RunLog += BuildTextLog( $temp ); ### create full log
   $RunLog += "$NL";
   $Global:Stamps += TimeStamp( "Text log creation is finished" );
}

$AllProperties = @(
   "CurrentBuild","InstallDateString","Minutes","FullDuration","Description","ProductName",`
   "ProductId","ProductId4","ProductId2","BuildLabEx","ProductId3","ProductId5",`
   "DefaultProductKey","ProductKey","EditionID","CurrentVersion","ReleaseId","UBR",`
   "LicensingProductID","ApplicationID","InstallDate","InstallTime","UpgradeDate",`
   "PSParentPath","PSChildName","Unknown1","Unknown2","Unknown3","Unknown4"  
);

if ( Test-Path .\out.xml ){ Remove-Item .\out.xml -Force }
$temp | Select $AllProperties | Export-Clixml -Path .\out.xml;
if ( Test-Path .\$LogFN.xml ){ Remove-Item .\$LogFN.xml -Force }
Rename-Item -Path ".\out.xml" -NewName ".\$LogFN`.xml";
$Global:Stamps += TimeStamp( "XML creation is finished" );

BuldHTML( $temp ) | Set-Content -Encoding utf8 .\$LogFN.hta;

if ( $NeedTextLog )
{
   $Global:Stamps += TimeStamp( "HTML creation is finished" );
   $RunLog | Set-Content -Encoding ascii .\$LogFN.log;
}

& .\$LogFN.hta; # run HTA
