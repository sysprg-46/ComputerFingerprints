<#
---------------------------------------------------------------------------- 
 Project: GetBuildsHistory, part GBHColorSchemes                                               
 Version: 1.0                                                        
 FileId:  e:\Delme\!Projects\BuildsHistory\GBHColorSchemes.ps1                    
 When:    13 Dec 2016,  Tuesday,  09:53:54                           
 ©        Oleg Kulikov, sysprg@live.ru                               
---------------------------------------------------------------------------- 
Creates Style tags for HTA creation by GBHUtils.ps1 BuldHTML function                                                           
----------------------------------------------------------------------------
ATTENTION: contains Unicode strings, must be saved as Unicode !
----------------------------------------------------------------------------
Saturday, December 17, 2016. Created from the code from GBHUtils
----------------------------------------------------------------------------
The CSS3 box-sizing property allows us to include the padding and border in 
an element''s total width and height. If you set box-sizing: border-box; 
on an element padding and border are included in the width and height:
----------------------------------------------------------------------------
Read about webkit at:
stackoverflow.com/questions/1256258/div-scrollbar-any-way-to-style-it
----------------------------------------------------------------------------
#>

$HeaderStyle = '

html    { box-sizing: border-box; }
*, *::before, *::after { box-sizing: inherit; }
html    { overflow-x: hidden; }
body    { margin: 0; font-family: "Segoe UI"; leter-spacing:0px;}

.wide   { letter-spacing: 2px; }
.navbar { list-style-type: none; margin: 0; margin-left: 10px; padding: 0; width: 968px; overflow: hidden; }
.padding-8 { padding-top: 8px !important; padding-bottom: 8px !important; }
.navbar { position: relative; z-index: 4; font-size: 14px; }
.navbar a { text-decoration: none !important; }
.right { float: right !important; }
.navbar li { float: left; }
.navbar li a, .navitem, .navbar li { display: block; padding: 8px 16px; }
.caret   { font-family: Webdings; }
.navbtn_content { 
           display:     none; 
           position:    absolute; top: 50px;
           padding:        5px;
           font-size:     15px;
           letter-spacing: 2px;           
}
.hover-white{ cursor:pointer; }
.ContentItem { padding-top: 2px; padding-bottom: 2px; cursor:pointer;}
.topbarClass{ cursor:pointer; }

#navbtn_file_content  { left: 022px; }
#navbtn_view_content  { left: 146px; } 
#navbtn_theme_content { left: 279px; }
#navbtn_lang_content  { left: 426px; }
#navbtn_debug_content { left: 602px; }

#MainContainer
{
   width:      1030px; 
   heigth:     760px;
   max-width:  1170px;
   padding:    0px;  
   margin:     0px;
   overflow:   hidden;
   font-size:  14px;
}
#Main
{ 
   width:      98%; 
   padding:    0px;  
   margin:     0px;  
} 
     
#expandtable, #tablecontainer 
{
   height:      98%;
   margin:      0;
   padding:     0;
   border:      none;
   overflow-y:  hidden;
}
   
#tablecontainer 
{
   width:       98%;
   margin:      0 auto;
   padding:     0px;
   max-height:  0450px;
}

#expandable
{
   margin:           5px 0 0 0px;
   overflow-x:       hidden;
   overflow-y:       auto;
   height:           370px;
   width:            100%;
   border-bottom:    none;
   cursor:           hand;
}

::-webkit-scrollbar{width:5px;}
::-webkit-scrollbar-thumb{background: #0000ff;}
.mr{cursor:pointer;border:none;}
.h{display:none;}     
.Build  {text-align:right;  width: %Build%;} 
.Date1  {text-align:left;   width: %Date1%;}
.Date2  {text-align:left;   width: %Date2%;}
.Name   {text-align:left;   width: %Name%;}
.Branch {text-align:left;   width: %Branch%;}
.UBR    {text-align:left;   width: %UBR%;}
.mmss   {text-align:center; width: %mmss%;}
.copyr  {width:968px;}
';
$HeaderStyle = GetRidOfBlanks( $HeaderStyle );#get rid of blanks BUT KEEP \n
$bgRose = "http://webneel.com/wallpaper/sites/default/files/images/01-2014/20-flower-wallpaper.preview.jpg";
<#
--------------------------------------------------------
#ef7a8f - dark  color of all bars
#f7dede - light color of the table rows background, REALLY rgba(247,222,222,0.82);
#f6e2f9 - 
#a914a9 - text  color of the table rows
#7d10b5 - nearly black text color of the menu items
#navbtn_debug,#navbtn_debug a,#navbtn_debug:hover -
colors definition REQUIRES !important at list for HOVER 
---------------------------------------------------------
.white,.hover-white:hover {color:#000!important; background-color:#fff!important;}
#>
$ColorSchemeRoseFlowers = '
.navbtn_content { 
   color:            #ef7a8f;
   border: 2px solid #ef7a8f; border-top: none;
   background-color: #ffffff;
}
.theme  { color:#fff !important; background-color:#ef7a8f !important; }
a { background-color:transparent; -webkit-text-decoration-skip: objects; color:#ffffff; }
.white,.hover-white:hover {color:#000!important; background-color:#fff!important;}
.ContentItem:hover{background:#ef7a8f;color:#ffffff;}
  
body, #expandtable, #tablecontainer
{ 
   background-color:#f6e2f9;
   background:url(%BGImage%);
   background-size:cover;
}  
#tablecontainer{background: rgba(247,222,222,0.82);}
#expandable{color:#a914a9;} 
.divcell { float: left; border: 1px solid #999000; box-sizing: border-box; border-bottom:none;}
.colname { float: left; border: 1px solid #999000; box-sizing: border-box; border-bottom:none;}
.divcell:hover{background:#a914a9; color:#f6e2f9;} 
.topbarClass,.footbarClass,.colname{background:#ef7a8f;color:#ffffff;} 
#navbtn_*:hover{ color:#7d10b5; }
#navbtn_debug,#navbtn_debug a,#navbtn_debug:hover{color:gray!important;background-color:#ef7a8f!important;cursor:default;}
';
$ColorSchemeRoseFlowers = CodeToString( $ColorSchemeRoseFlowers );
$ColorSchemeRoseFlowers = $ColorSchemeRoseFlowers -replace "%BGImage%", "$bgRose";

#                                  dark      light     body      hover
$ColorSchemeBlack  = buildCSS( @("#2f4f4f","#d3d3d3","#dcdcdc","#778899") );
$ColorSchemeGreen  = buildCSS( @("#006400","#90ef90","#98fb98","#3CB371") );
$ColorSchemeBlue   = buildCSS( @("#0000cd","#add8d6","#8fcefa","#6495ed") );
$ColorSchemeBrown  = buildCSS( @("#8b4516","#ffe4c4","#f5deb3","#cd853f") );
$ColorSchemeOrange = buildCSS( @("#ff4500","#ffffe0","#ffcacd","#ff8c00") );

$schemes = ( "" | Select HeaderStyle,RoseFlowers,Black,Green,Blue,Brown,Orange );

Set-Variable ColorSchemes -Scope Global -Value $schemes;

$ColorSchemes.RoseFlowers = "$ColorSchemeRoseFlowers";
$ColorSchemes.Black       = "$ColorSchemeBlack";
$ColorSchemes.Green       = "$ColorSchemeGreen";
$ColorSchemes.Blue        = "$ColorSchemeBlue";
$ColorSchemes.Brown       = "$ColorSchemeBrown";
$ColorSchemes.Orange      = "$ColorSchemeOrange";
<#
Geometry:    http://javascript.info/tutorial/metrics;
ColorNamesTo #-values: http://www.w3schools.com/colors/colors_names.asp;
Characters names: http://www.ascii.cl/htmlcodes.htm
AllAboutMouseEvents http://javascript.info/tutorial/mouse-events describes drag-n-drop
#>
$head ='
<head>
<meta http-equiv="X-UA-Compatible" content="IE=11">
<title>Builds History</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<style type="text/css">%HeaderStyle%</style>
<script src="LangStrings.js" type="text/javascript"></script>
<script type="text/javascript">
var version="%version%";
if ( typeof( repeat ) == "undefined" )
{
   String.prototype.repeat = function( n )                               
   { 
      var tmp = ""; 
      for ( var i = 0; i < n; i++ ) tmp += this;                                                                         
      return tmp;
   } 
} 
String.prototype.left = function( n, char )                               
{ 
   if ( typeof( char ) == "undefined" ) char = " ";  
   if ( this.length >= n ) return this.substr( 0, n );
   return this + char.repeat( n - this.length );
}
String.prototype.right = function( n, char )                               
{
   if ( typeof( char ) == "undefined" ) char = " ";   
   if ( this.length > n ) return this.substr( this.length - n );
   return char.repeat( n - this.length ) + this;
}
String.prototype.strip = function()                                         
{                                                                           
   return this.replace( /^(\s*)/, "" ).replace( /(\s*)$/, "" );               
}
function getEvent()
{
   var evt = event || window.event;
   evt.cancelBubble = true;
   evt.returnValue  = false;
   if ( evt.cancelable ) evt.preventDefault();
   return evt;
}
 
var lastShownItem    = null;
var lastShownContent = null;
var lastShownCaret   = null;
var caretDown = "6", caretUp = "5";

function showMenuContent( o )
{
   var Event   = getEvent();// call it to prevent event propagation
   
   try 
   {
      obj = o.currentTarget;
   }
   catch(e){obj = o;}

   if ( lastShownItem )
   {
      lastShownContent.style.display = "none";
      lastShownItem.getElementsByTagName( "span" )[0].innerText = caretDown;
   }

   if ( obj.className == "navbarbtns_disabled" ) return false;

   var id                = obj.getElementsByTagName( "a" )[0].id;
   var content           = document.getElementById( id + "_content" );
   var caret             = obj.getElementsByTagName( "span" )[0];
   content.style.display = "inline-block";
   caret.innerText       = caretUp;
   lastShownItem         = obj;
   lastShownCaret        = caret;
   lastShownContent      = content;
   return false;
}
function hideMenuContent()
{
   if ( ! lastShownItem ) return false;
   lastShownContent.style.display = "none";
   lastShownItem                  = null;
   if ( lastShownCaret )
   {
      lastShownCaret.innerText = caretDown;
      lastShownCaret = null;
   }    
   return false;   
}
var activeTheme = "%activeTheme%";
var ColorScheme =
{
   "Flowers": "%RoseFlowers%",
   "Black":   "%Black%",
   "Green":   "%Green%",
   "Blue":    "%Blue%",
   "Brown":   "%Brown%",
   "Orange":  "%Orange%"    
};
var popColors = 
{
   "Flowers": ["#a914a9","#f7dede","#f6e2f9"],
   "Black":   ["#2f4f4f","#d3d3d3","#dcdcdc","#778899"],
   "Green":   ["#006400","#90ef90","#98fb98","#00ff00"],
   "Blue":    ["#0000cd","#add8d6","#8fcefa","#6495ed"],
   "Brown":   ["#8b4516","#ffe4c4","#f5deb3","#cd853f"],
   "Orange":  ["#ff4500","#ffffe0","#ffcacd","#ff8c00"]
 //             dark      light     body      hover
}
function setTheme( schemeName )
{
   var Event  = getEvent();// call it to prevent event propagation
   var scheme = ColorScheme[ schemeName ];
   
   if ( scheme )
   {
      document.getElementById( "ColorScheme" ).innerHTML = scheme;
      activeTheme = schemeName;
   }
   hideMenuContent();
   return false; 
}
var currentLang = "en";// is updated by setLang function
function ShowDetails( row )
{ 
   var win = null;
   var id  = "div" + row.id;
   var colors = popColors[ activeTheme ];
   var themeDependent = ".hc{color:%color1;background-color:%color2;border:1px solid %color1;}"+
   "body{background-color:%color3;}";

   themeDependent = themeDependent.replace( /%color1/g, colors[0] );
   themeDependent = themeDependent.replace( "%color2", colors[1] );
   themeDependent = themeDependent.replace( "%color3", colors[2] );

   var html = ""+//%bld%  
"<!DOCTYPE html><html><head><meta content=\"IE=11.0000\" http-equiv=\"X-UA-Compatible\">"+
"<title>" + LangStrings[currentLang].Details + "</title>"+    
"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"><style type=\"text/css\">"+
".h{font-family:MS Serif;letter-spacing:0px;}.KeepBlanks{font-family:Consolas;letter-spacing:0px;}"+
themeDependent + "</style></head><body>";

   var bld = ( parseInt( "0x" + row.id.substr( 0, 4 ) ) ).toString();
   html = html.replace( "%bld%", bld );
   html += document.getElementById( id ).outerHTML + "</body></html>";
   var options = "width=810,height=600,scrollbars=1,resizable=1,status=0,toolbar=0,"+
  	"left=200,top=1200,titlebar=0,menubar=0";
	win = window.open( "empty.html", "", options );//#f6e2f9
   win.document.write( html );
   return false; 
}
 
function closePopUps()
{
   var Event = getEvent();
   if ( Event.keyCode == "27" )// Escape;
   {
      hideMenuContent();
   }
   return false;
}

/*
This is, I HOPE, temporary function which fixes 1 pixel lost
at the 1st item of the topBar and, as appeared 1 pixel at the
last item. DON''t UNDERSTAND WHY thease pixels are lost.
*/ 
function fixGeometry()
{
   var container = document.getElementById( "topBar" );
   var el = container.getElementsByClassName("colname Build")[0];
   el.style.width = (el.offsetWidth + 1)+"px";
   el = container.getElementsByClassName( "colname mmss" )[0];
   el.style.width = (el.offsetWidth + 1)+"px";
   return false;
}
var CreateColorDebugWin = false;
var debugWin = null;
function createDebugWin()
{
   var options = "width=790,height=350,scrollbars=0,resizable=1,status=0,toolbar=0,"+
  	"left=100,top=100,titlebar=1,menubar=0"
	if( ! debugWin || debugWin.closed )
	{
		debugWin = window.open( "color.html", "Color Debugger", options );
	}
}

function MainTableToText()
{
   function formatAndJoin( arr )
   {
      var dl = "31.03.2015 16:25:14 Tue".length;
      var tl = "Windows 10 Pro Technical Preview".length;
      var bl = "fbl_impressive_cxe".length;
      var ml = "Minutes".length;
      var out = "";
      out += arr[0].right( 5 ) + "  " +                 // build;
      arr[1].replace( "   ", " " ).left( dl ) + "  " +  // Install Date
      arr[2].replace( "   ", " " ).left( dl ) + "  " +  // Upgrade Date
      arr[3].left( tl ) + "  " +                        // Product Name
      arr[4].left( bl ) + "  " +                        // Branch
      arr[5].replace( "Service pack", "UBR").right( 5 ) + "  " + // Service Pack
      arr[6].right( ml );                               // Minutes
      return out + ''\n'';
   }
	var fso  = new ActiveXObject( "Scripting.FileSystemObject" );
	var path = location.pathname.substr( location.pathname.indexOf( ":" ) - 1 );
   var outp = path.replace( ".hta", ".log" );
   var out  = "" 

   var header    = document.getElementById( "topBar" );
   var mainTable = document.getElementById("expandable");
   var tmp = header.getElementsByTagName("div");
   var names = [], row;// column names
   for ( var i = 0; i < tmp.length; i++ )
   {
      names[ names.length ] = tmp[i].innerText.strip();
   }
   out += formatAndJoin( names );
   tmp = mainTable.getElementsByClassName( "mr divcell" );
   
   for ( var i = 0; i < tmp.length; i++ )
   {
      row = tmp[i].getElementsByTagName("div");
      names = [];
      for ( var j = 0; j < row.length; j++ )
      {
         names[ names.length ] = row[j].innerText.strip();
      }
      out += formatAndJoin( names );
   }
   var fut = fso.CreateTextFile( outp, true );
   fut.Write( out );
   fut.Close();
   alert ( "file " + outp + " succesfully created" );
   return false;
}
window.onload = function()
{
   window.resizeTo( 1100, 760 );
   fixGeometry();
   document.onkeydown  = function(){return closePopUps();}
   // Assign onclick handlers for menu items;
   var o, id, items = ["file","view","theme","lang","debug"];
   for ( var i = 0; i < items.length; i++ )
   {
      id = "navbtn_" + items[i];
      o = document.getElementById( id ).parentNode;
      o.onclick = function(o){return showMenuContent(o);}
   }
   if ( CreateColorDebugWin ) createDebugWin();
   implementLangStrings();
   document.body.onclick = function(e)
   {
      var Event = getEvent();
      return hideMenuContent();
   }
}
</script>
</head>
';

$head = GetRidOfBlanks( $head );# get rid of blanks BUT KEEP \n
$head = $head -replace "%HeaderStyle%", "$HeaderStyle";
$head = $head -replace "%RoseFlowers%", "$ColorSchemeRoseFlowers";
$head = $head -replace "%Black%", "$ColorSchemeBlack";
$head = $head -replace "%Green%", "$ColorSchemeGreen";
$head = $head -replace "%Blue%", "$ColorSchemeBlue";
$head = $head -replace "%Brown%", "$ColorSchemeBrown";
$head = $head -replace "%Orange%", "$ColorSchemeOrange";
$head = $head -replace "%activeTheme%", "Flowers";
$head = $head -replace "%version%", "$Version";

Set-Variable HeadTag -Scope Global -Value "$head";