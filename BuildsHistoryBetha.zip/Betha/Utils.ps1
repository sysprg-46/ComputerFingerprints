<#
-------------------------------------------------------------------- 
 Project: Utils                                               
 Version: 1.0                                                        
 FileId:  e:\Delme\!Projects\BuildsHistory\                    
 When:    13 Dec 2016,  Tuesday,  09:53:54                           
 (c)      Oleg Kulikov, sysprg@live.ru                               
-------------------------------------------------------------------- 
 Collection of the project independent small functions.                                                           
--------------------------------------------------------------------
#>
function Global:zone2seconds( $zone )
{
   $parts   = $zone -split ":";
   $hours   = [int]( $parts[0] );
   $seconds = $hours * 3600;
   if ( $parts.Length -eq 2 -and "00" -ne $parts[1] )
   {
      $seconds += 60 * ( [int]( $part[1] ) );
   }
   return $seconds;
}

function Global:FileTimeToString( [int64]$qw )
{
   return ( [datetime]::fromFileTime( $qw ) ).ToString( "ddd, dd.MM.yyyy HH:mm:ss" );
}

<#
---------------------------------------------------------------------------------
Function converts Reg_DWORD DateTime which presents number of the seconds since 
01.01.1970 00:00:00 into QWORD FileTime number. Constant which is used in
calculations is the number of the 100 nanosecond intervals since 01.01.1601 
till 01.01.1970. 
1 second = 1000 milliseconds = 10000 of 100-ns intervals
---------------------------------------------------------------------------------
the UNIX Epoch is January 1st, 1970 at 12:00 AM (midnight) UTC
#>
function Global:RegDWDateToFileTime( [int32]$dw )
{  
   return [int64]( ( 1000 * $dw + 11644473600000 ) * 10000 );
}
function Global:FiletimeToDWDate( [int64]$ft )
{
   return [int32]([math]::truncate( $ft - 116444736000000000 ) / 10000000 );
}
function Global:TicksToFileTime( [int64] $ticks )
{
   return $ticks - 504911376000000000;
}
function Global:TicksToString( [int64]$ticks )
{
   return FileTimeToString( TicksToFileTime( $ticks ) );
}
function Global:TimeStamp( $action )
{
   $dt = (get-date);
   $ms = ($dt.Millisecond).ToString().PadLeft(3,"0");
   $dt = $dt.ToString( "dd.MM.yyyy HH:mm:ss" );
   return "[$dt.$ms] $action";
}
function Global:GetCompInfo
{ 
   function GetRAMSize 
   {
      $q = "select Capacity From Win32_PhysicalMemory";
      $dimms = gwmi -Query $q | select @( "Capacity" );
      $ram = 0;
      $dimms | % { $ram += $_.Capacity };
      $ram = $ram / 1024 / 1024 / 1024;
      return [string]$ram + " GB";
   } 
   # detect current video resolution    
   $d = (Get-ItemProperty -Path "hklm:\SYSTEM\CurrentControlSet\Enum\DISPLAY\*\1&8713bca&0&UID0").HardwareID
   $d = $d.substring( "MONITOR\".Length );
   $d = (Get-ItemProperty -Path "hklm:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Configuration\$d*\00\00");
   $r = [string]($d."ActiveSize.cx")+"x"+[string]($d."ActiveSize.cy");

   $Comp  = Get-ItemProperty -Path "HKLM:\HARDWARE\DESCRIPTION\System\BIOS"; 
   $stone = Get-ItemProperty -Path "HKLM:\HARDWARE\DESCRIPTION\System\CentralProcessor\0";
   $Disk0 = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Disk\Enum").0;
   $d     = (Get-ItemProperty -Path "hklm:\system\CurrentControlSet\Enum\$disk0").FriendlyName;
   
   [string]$CompID = "";
   if ( $Comp.BaseBoardManufacturer  -ne $null ) { $CompID += $Comp.BaseBoardManufacturer + " "; }
   elseif ( $Comp.SystemManufacturer -ne $null ) { $CompID += $Comp.SystemManufacturer    + " "; }
   if ( $Comp.SystemVersion          -ne $null ) { $CompID += $Comp.SystemVersion         + " "; }
   elseif ( $Comp.SystemFamily       -ne $null ) { $CompID += $Comp.SystemFamily          + " "; }  
   if ( $Comp.SystemProductName      -ne $null ) { $CompID += $Comp.SystemProductName; }
   
   $Platform  = ( $CompID  -replace "\s\s*", " " );
   $Processor = ( $stone.ProcessorNameString.trim() -replace "\s\s*", " " ); 
   $DiskDrive = ( $d  -replace "\s\s*", " " );
   $RAMSize   = GetRAMSize;
   $Monitor   = "$r ( Current resolution )";

   $ML   = "DiskDrive".Length;
   $ret  = @();
   $ret += "{0,-$ML}: {1}" -f "Platform",  $Platform;
   $ret += "{0,-$ML}: {1}" -f "Processor", $Processor;
   $ret += "{0,-$ML}: {1}" -f "DiskDrive", $DiskDrive;
   $ret += "{0,-$ML}: {1}" -f "RAMSize",   $RAMSize;
   $ret += "{0,-$ML}: {1}" -f "Monitor",   $Monitor;
   
   return $ret;
}
function Global:GetRidOfBlanks( [string] $code )
{
   $s = $code -replace '([0-9a-zA-Z"]) ([0-9a-zA-Z"])','$1%%$2';
   $s = $s -replace " `#", "%%#";
   <#
   ----------------------------------------------------------------------
   "margin:           5px 0 9 0px;" => "margin:           5px%%0 9%%0px;"
   Thus following replace is necessary
   ----------------------------------------------------------------------
   #>
   $s = $s    -replace '([0-9])\s([0-9])','$1%%$2'
   return $s -replace "%%"," ";
}
function Global:CodeToString( [string] $code )
{
   $s = $code -replace '([0-9a-zA-Z"]) ([0-9a-zA-Z"])','$1%%$2';
   $s = $s -replace " `#", "%%#";
   <#
   ----------------------------------------------------------------------
   "margin:           5px 0 9 0px;" => "margin:           5px%%0 9%%0px;"
   Thus following replace is necessary
   ----------------------------------------------------------------------
   #>
   $s = $s    -replace '([0-9])\s([0-9])','$1%%$2'
   $s = $s -replace '\s*','';
   return $s -replace "%%"," ";
}
<#--End-of-File-DTConverters------------------------------------------#>


