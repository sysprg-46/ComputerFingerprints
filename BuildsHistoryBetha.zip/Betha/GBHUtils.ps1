<#
-------------------------------------------------------------------- 
 Project: etBuildsHistory, part GBHUtils                                               
 Version: 1.0                                                        
 FileId:  e:\Delme\!Projects\BuildsHistory\GBHUtils.ps1                    
 When:    13 Dec 2016,  Tuesday,  09:53:54                           
 ©        Oleg Kulikov, sysprg@live.ru                               
-------------------------------------------------------------------- 
 Collection of the GetBuildsHistory project functions.                                                           
--------------------------------------------------------------------
ATTENTION: contains Unicode strings, must be saved as Unicode !
--------------------------------------------------------------------
Tuesday, December 13, 2016. Have improved Details presentation:
dates now are vertically aligned.
--------------------------------------------------------------------
#>
function Global:TagIdFromObjDate( $o )
{
   $bld = "{0:X0}" -f [int]$o.CurrentBuild;
   $dat = $o.InstallTimeS.Substring( 2 + $o.InstallTimeS.IndexOf( "0x" ), 8 );
   return "$bld$dat";      
}
function Global:FormatNumber( [int64]$num )
{
   if ( $num -lt 13071694150 )
   {
      return ("{0,-19} (0x{0:X0})" -f $num);
   }      
   return ("{0,-19} (0x0{0:X0})" -f $num);
} 
function GetBuildTimeZone( $obj )
{
   $build = $obj.CurrentBuild;
   for ( $i = 0; $i -lt $TimeZoneDefs.Length )
   {
      $def = ($TimeZoneDefs[ $i ]) -split "=";
      if ( $def[0] -eq $build ){return $def[1];}
      elseif( $def[0].IndexOf( "-" ) -eq -1 ) {return "";}
      $lr = $def[0] -split "-";
      if ( [int]$lr[0] -gt [int]$build ){return "";}
      if ( [int]$lr[1] -lt [int]$build ){return "";}
      return $def[1];      
   }
}
function DateStringToSeconds( $obj ) 
{
   $utc   = $obj.PSChildName.Replace( "Source OS (Updated on ", "" ).Replace( ")", "" );
   $tz    = GetBuildTimeZone(  $obj );
   $dt    = [datetime]( "$utc" );
   $epoch = ( Get-Date -Year 1970 -Month 1 -Day 1 -Hour 0 -Minute 0 -Second 0 );### CONST
   $dt | % { $Seconds = [math]::truncate( $_.ToUniversalTime().Subtract( $epoch ).TotalSeconds ) };
   if ( $tz -ne "" )
   {
      $s1 = [int]$CurrentTIMEZONESeconds;
      $s2 = [int]$tz;
      $Seconds += ( $s1 - $s2 );
   }
   return $Seconds;
}
function buildCSS( $colors )
{
<#
P.A: borders are always this solid black for any other then Flowers themes
$dark  is used as text color, dark background 
$lightis used as text color on dark and background for rows
$body less intensive then light
$hover intermediate between light and dark
#>
   $dark  = $colors[0];# is used as text color, dark background 
   $light = $colors[1];# is used as text color on dark and background for rows
   $body  = $colors[2];# less intensive then light
   $hover = $colors[3];# intermediate between light and dark
   $css = @(
   ".theme  { color:#ffffff!important; background-color:$dark!important; }"
   "a { background-color:transparent; -webkit-text-decoration-skip: objects; color:$light; }"
   ".navbtn_content {" 
   "color: $dark;"
   "border: 2px solid black; border-top: none;"
   "background-color: $light;}"
   ".white,.hover-white:hover{color:$dark!important; background-color:#ffffff!important;}"#$light
   ".ContentItem:hover{background:$hover;color:#ffffff;}" #$light;
   "body, #expandtable, #tablecontainer{background-color:$body;}"  
   "#tablecontainer{background: $light;}"
   "#expandable{color:$dark;}"
   ".divcell { float: left; border: 1px solid black; box-sizing: border-box; border-bottom:none;}"
   ".colname { float: left; border: 1px solid black; box-sizing: border-box; border-bottom:none;}"
   ".divcell:hover{background:$hover; color:#ffffff;}" #$light;
   ".topbarClass,.footbarClass,.colname{background:$dark;color:$light;}" 
   "#navbtn_*:hover{ color:$light; }"
   "#navbtn_debug,#navbtn_debug a,#navbtn_debug:hover{color:gray!important;background-color:$dark!important;cursor:default;}"
   );
   $css = $css -join "";
   $css = CodeToString( $css );
   return $css;
}
<#
------------------------------------------------------------------------------
Function receives an array of the Builds objects and return HTML code which
presents objects properties.
------------------------------------------------------------------------------
#>
function BuldHTML( $arr )
{
   $short = ("CurrentBuild,InstallDateString,UpgradeDateString,ProductName," +`
   "BuildBranch,UBR,Minutes") -split ",";

   Set-Variable -Name RowProps -Scope Global -Value $short -Force;

   [string]$n = ([char]0x0d)+([char]0x0a);
   
   Set-Variable -Name NL  -Scope Global -Value $n;
   Set-Variable -Name FSZ -Scope Global -Value 17;
   Set-Variable -Name px  -Scope Global -Value "px";

   <#
   ----------------------------------------------------------------------
     Argument $style is dummy and is not referenced by BuildHead code.
     Function uses globally defined $HeadTag prepared by GBHColorSChemes 
     and then updates geometry settings parmeters
   ----------------------------------------------------------------------
   #>
   function BuildHead( $style ) 
   {
      $Head = "$HeadTag"; 
      $P2N = @{
         CurrentBuild      = "Build";
         InstallDateString = "Date1";
         UpgradeDateString = "Date2";
         ProductName       = "Name";
         BuildBranch       = "Branch";
         UBR               = "UBR";
         Minutes           = "mmss";
      };
      #
      # PropertyName To Column width
      #
      $P2W   = @{
         Build  = "045px";# 45->46;
         Date1  = "180px";  
         Date2  = "180px"; 
         Name   = "250px"; 
         Branch = "140px";  
         UBR    = "100px";# 95 without font-weight:bold;
         mmss   = "071px";# 070->071, sum = 967;
      };# 45 + 180 + 180 + 250 + 140 + 100 + 70 = 965;
      
      for ( $i = 0; $i -lt $RowProps.Length; $i++ )
      {
         $snm   = $RowProps[$i];
         $tnm   = $P2N.$snm;
         $trg   = $P2W.$tnm;
         $Head = $Head.Replace( "%$tnm%", "$trg" );
      }

      $t = $Global:Title;
      $Head = $Head.Replace( "Builds History", "$t" );
      return $Head;

   }# End-of-function BuildHead

   function BuildMainTable( $arr )
   {
      function GetClass( $p )
      {
         $P2C = @{
            CurrentBuild      = "Build";
            InstallDateString = "Date1";
            UpgradeDateString = "Date2";
            ProductName       = "Name";
            BuildBranch       = "Branch";
            UBR               = "UBR";
            Minutes           = "mmss";
         };
         return $P2C.$p;
      }       
      function BuildTH( $obj )
      {   
         $tds      = "";
         $lang     = "en";
  
         $Translate = @{
            CurrentBuild      = "Build";
            InstallDateString = "Install Date";
            UpgradeDateString = "Upgrade Date";
            ProductName       = "Product Name";
            BuildBranch       = "Branch";
            UBR               = "Service pack";
            Minutes           = "Minutes";
         }

         $CellOpenPattern = "<div class=""colname %pn%"">";
         $RowOpenTag      = "<div class=""topbarClass"" id=""topBar"" title=""%tooltip%"">$NL";
         $CellCloseTag    = $RowCloseTag =  "</div>$N";
         if ( $obj -eq $null )
         {
            $RowOpenTag = $RowOpenTag.Replace( "topBar", "footBar" );
         }
    
         $p = $RowProps;
         $tds = "";
         for ( $i = 0; $i -lt $p.Length; $i++ )
         {
            $q = $p[ $i ];
            $a = GetClass( "$q" );
            $CellOpenTag = $CellOpenPattern.Replace( "%pn%", "$a" );
            if ( $obj -eq $null )
            {
               $cpy = "&copy;&nbsp;sysprg&`#64;live.ru`,&nbsp;liza.shakh&`#64;gmail`.com"+
                       "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+`
                       "This page was generated by GetBuildsHistory.ps1&nbsp"              
               $tds = "<div class=""colname copyr"">&nbsp;$cpy&nbsp;</div>$NL";                      
               break;
            }
            else
            {
               $v = $Translate.$q;
#http://stackoverflow.com/questions/2011142/how-to-change-the-style-of-title-attribute-inside-the-anchor-tag
            }
            $x1 = "<!--EndOfHeader-->";
            if ( $i -eq 0 ){$x1 = "<!--EndOfFooter-->";}
            $tds += "$CellOpenTag&nbsp;$v&nbsp;$CellCloseTag";
         }
         return "$RowOpenTag$tds$RowCloseTag$x1$NL$BreakLine$NL";      
      }
      function BuildTD( $tobj )
      {
         $CellOpenPattern = "<div class=""divcell %pn%"">";
         $CellCloseTag = "</div>$NL";
         $p = $tobj.PropName;
         $a = GetClass( "$p" );
         $CellOpenTag = $CellOpenPattern.Replace( "%pn%", "$a" ); 
         $v = $tobj.Value.ToString().trim();
         if ( $a -and $a.Contains( "Date" ) )
         {
            if ( $v.Contains( "," ) )
            {
               $v  = $v -split ",";
               $v0 = ($v[0]).trim();
               $v1 = ($v[1]).trim();
               $v  = "$v1&nbsp;&nbsp;&nbsp;$v0";
            }
         }
         return "$CellOpenTag&nbsp;$v&nbsp;$CellCloseTag";
      }
      function BuildRow( $obj )
      {   
         $tds = "";
         $p   = $RowProps;

         for ( $i = 0; $i -lt $p.Length; $i++ )
         {
            $q    = $p[ $i ];
            $v    = $obj.$q;
            $tds += BuildTD( @{PropName="$q";Value="$v";} );
         }
         
         $id = TagIdFromObjDate( $obj );
         return "<div class=""mr divcell"" id=""$id"" onclick=""ShowDetails(this)"">$NL"+`
         "$tds</div><!--EndOfMR-->$NL";     
      }

      $th1  = BuildTH( $RowProps );   
      $rows = $arr | %{BuildRow( $_ )};
      $th2  = BuildTH( $null );
      
      return "<div id=""Main"" class=""Main"">$NL"+`
      "<div id=""tablecontainer"">$th1<div id=""expandable"">"+`
      "$NL$rows</div><!--Expandable-->$NL"+`
      "$th2</div><!--tablecontainer-->$NL</div><!--Main-->$NL";
   } 
   function BuildBottomTable
   {
      $sz = $FSZ - 2;
      $comp = "";
      for ( $i = 0; $i -lt $CompInfo.Length; $i++ )
      {
         $lr = $CompInfo[$i] -split ":";
         $l  = $lr[0].trim();
         $r  = $lr[1].trim();
         $comp += "<tr><td>&nbsp;$l&nbsp;</td><td>&nbsp;$r&nbsp;</td></tr>$NL";
      }
      $sz = $FSZ - 2;
      $lcell =  "<table id=""Computer"" style=""font-size:$sz$px;"">$NL$comp</table>";
      $Global:Stamps += TimeStamp( "HTML creation is finished" );
      $stmp = "";
      for ( $i = 0; $i -lt $Global:Stamps.Length; $i++ )
      {
         $v = $Global:Stamps[$i] -Split "]";
         $stmp += "<tr><td>&nbsp;" + $v[0].Substring( 1 ) + "&nbsp;</td>" +`
                   "<td>&nbsp;" + $v[1] + "&nbsp;</td></tr>$NL"
      }
      $rcell = "<table id=""RunStamps"" style=""font-size:$sz$px;"">$stmp</table>"; 
      return "<table><tr><td>$lcell</td><td>$rcell</td></tr></table>";      
   }
 
   function BuildHidden( $obj )
   {
      $ShowProps = @(
      "CurrentBuild","InstallDateString","UpgradeDateString","Minutes","FullDuration","Description",`
      "ProductName","ProductId","ProductId2","BuildLabEx","ProductId3","LicensingProductID",`
      "EditionID","ProductKey","CurrentVersion","ReleaseId","UBR","InstallDate","InstallTime",`
      "UpgradeDate","PSParentPath","PSChildName","Unknown1","Unknown2","Unknown3","Unknown4" 
      ); 
      $ShowProps1 = @( 
      "CurrentBuild","InstallDateString","Minutes","Description","ProductName",`
      "ProductId","ProductId4","ProductId2","BuildLabEx","ProductId3","ProductId5",`
      "LicensingProductID","ApplicationID","DefaultProductKey","ProductKey","EditionID",`
      "CurrentVersion","ReleaseId","UBR","InstallDate","InstallTime","PSParentPath","PSChildName",
      "Unknown1","Unknown2","Unknown3","Unknown4"      
      );

      $p = $ShowProps;
      if ( $obj.PSChildName -eq "CurrentVersion" ){$p = $ShowProps1;}
      $tds = "";

      for ( $i = 0; $i -lt $p.Length; $i++ )
      {
         $q    = $p[$i];
         $v    = $obj.$q;
         if ( "$q" -eq "Description" )
         {
            $v = $v.Replace( "(R)", "&`#174;" );
         }

         if ( $v -ne $null )
         {
            if ( $q -eq "InstallDate" -or $q -eq "InstallTime" )
            {
               $v = FormatNumber( $v );
            }
            if ( $v -is [string] )
            {
               $v = $v.trim();
               $v = $v.Replace( " ", "&nbsp;" );
            }
            $cls  = "KeepBlanks";# 
            $tds += "<tr><td>&nbsp$q&nbsp;</td><td class=""$cls"">&nbsp;$v&nbsp;</td></tr>";
         }
      }
      $id  = TagIdFromObjDate( $obj );
      return "<div id=""div$id"" class=""h hc""><table><tbody>$tds</tbody></table></div>";
   }
   function BuildMenuTop()
   {
      $code = '
<ul class="navbar theme wide" id="MenuContainer">
 <li class="navbarbtns">
  <a class="hover-white padding-8" id="navbtn_file" href="#">FILE&nbsp;
  <span class="caret">6</span></a>
 </li>
 <li class="navbarbtns">
  <a class="hover-white padding-8" id="navbtn_view" href="#">VIEW&nbsp;
   <span class="caret">6</span></a>
 </li>
 <li class="navbarbtns">
  <a class="hover-white padding-8" id="navbtn_theme" href="#">THEME&nbsp;
   <span class="caret">6</span></a>
 </li>
 <li class="navbarbtns">
  <a class="hover-white padding-8" id="navbtn_lang" href="#">LANGUAGE&nbsp;
   <span class="caret">6</span></a>
 </li>
 <li class="navbarbtns">
  <a class="hover-white padding-8 disabled" id="navbtn_debug" href="#">DEBUGGERS&nbsp;
   <span class="caret">6</span></a>
 </li>
 <li class="right" id="About">
  <a class="hover-white padding-8 right" title="%version%" href="#">
   <i>About</i></a>
 </li>
</ul>
<!--<br/>-->
';
      return $code.Replace( "%version%", "$Version" );
   }
   function BuildMenuHidden()
   {
      return '
<div class="navbtn_content" id="navbtn_file_content">
 <div class="ContentItem" onclick="MainTableToText();">&nbsp;SAVE VIEW AS TEXT FILE&nbsp;</div>
 <div class="ContentItem" onclick="window.close();">&nbsp;EXIT&nbsp;</div>
</div>
<div class="navbtn_content" id="navbtn_view_content">
 <div class="ContentItem" onclick="alert(this.innerText);">&nbsp;Default&nbsp;</div>
 <div class="ContentItem" onclick="alert(this.innerText);">&nbsp;Build,ProductId2,ProductId3,ProductId5&nbsp;</div>
 <div class="ContentItem" onclick="alert(this.innerText);">&nbsp;Build,Unkown1,Unkown2,Unkown3,Unkown4&nbsp;</div>
</div>
<div class="navbtn_content" id="navbtn_theme_content">
 <div class="ContentItem" onclick="setTheme(''Flowers'');">&nbsp;FLOWERS&nbsp;</div>
 <div class="ContentItem" onclick="setTheme(''Black'');">&nbsp;BLACK&nbsp;</div>
 <div class="ContentItem" onclick="setTheme(''Green'');">&nbsp;GREEN&nbsp;</div>
 <div class="ContentItem" onclick="setTheme(''Blue'');">&nbsp;BLUE&nbsp;</div>
 <div class="ContentItem" onclick="setTheme(''Brown'');">&nbsp;BROWN&nbsp;</div>
 <div class="ContentItem" onclick="setTheme(''Orange'');">&nbsp;ORANGE&nbsp;</div>
</div>
<div class="navbtn_content" id="navbtn_lang_content">
 <div class="ContentItem" onclick="setLang(''en'');">&nbsp;(EN-US)&nbsp;</div>
 <div class="ContentItem" onclick="setLang(''ru'');">&nbsp;(RU-RU)&nbsp;</div>
 <div class="ContentItem" onclick="setLang(''uk'');">&nbsp;(UK-UA)&nbsp;</div>
 <div class="ContentItem" onclick="setLang(''ge'');">&nbsp;(GE-GE)&nbsp;</div> 
</div>
<div class="navbtn_content" id="navbtn_debug_content">
 <div class="ContentItem" onclick="createDebugWin();">&nbsp;ColorPicker&nbsp;</div>
 <div class="ContentItem" onclick="alert(this.innerText);">&nbsp;Drevoloz&nbsp;</div>
</div>
';
   }
   $Default   = "RoseFlowers"; ### should be defined by INI file !
   $Scheme    = $ColorSchemes.$Default;
   $ColorScheme = "<style id=""ColorScheme"">$Scheme</style>";
   $head      = BuildHead; # uses $HeadTag prepared by GBHColorSChemes and updates geometry 
   $MainTable = BuildMainTable( $arr );
   $bottom    = BuildBottomTable;
   $hidd      = $arr | %{BuildHidden( $_ ); };
   $Container = "<div id=""MainContainer"">";
   $menuTop   = BuildMenuTop;
   $menuHidd  = BuildMenuHidden;
   return "<!DOCTYPE html><html>$head$NL"+`
   "<body>$NL$ColorScheme$NL"+`
   "$menuTop$menuHidd<div id=""MainContainer"">$MainTable$bottom$hidd</div>$NL"+`
   "<!--MainContainer-->$NL</body></html>";  
}
  
