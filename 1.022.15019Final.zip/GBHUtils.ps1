<#
-------------------------------------------------------------------- 
 Project: GetBuildsHistory, part GBHUtils                                               
 Version: 1.0                                                        
 FileId:  e:\Delme\!Projects\BuildsHistory\GBHUtils.ps1                    
 When:    13 Dec 2016,  Tuesday,  09:53:54                           
 ©        Oleg Kulikov, sysprg@live.ru                               
-------------------------------------------------------------------- 
 Collection of the GetBuildsHistory project functions.                                                           
--------------------------------------------------------------------
Tuesday, December 13, 2016. Have improved Details presentation:
dates now are vertically aligned. textlog
--------------------------------------------------------------------
#>
### Common global for ALL views, contains all fields names
$Global:currentView = "V1";
$Global:P2N = @{
   CurrentBuild      = "Build";
   InstallDateString = "Date1";
   UpgradeDateString = "Date2";
   ProductName       = "Name";
   BuildBranch       = "Branch";
   UBR               = "UBR";
   Minutes           = "mmss";
   ProductId2        = "ProductId2"; # [Blue]res-v2600
   ProductId         = "ProductId";  # 00260-00709-22436-AA664
   ProductId3        = "ProductId3"; # 00000-02600-070-922436-00-1033-9200.0000-3102015  (Fri, 06.11.2015)
   Unknown1          = "Unknown1"; 
   Unknown2          = "Unknown2"; 
   Unknown3          = "Unknown3";
   Unknown4          = "Unknown4";
};

$Global:Translate = @{
   CurrentBuild      = "Build";
   InstallDateString = "Install Date";
   UpgradeDateString = "Upgrade Date";
   ProductName       = "Product Name";
   BuildBranch       = "Branch";
   UBR               = "Service pack";
   Minutes           = "Minutes";
   ProductId2        = "ProductId2";  
   ProductId         = "ProductId";  
   ProductId3        = "ProductId3";  
   Unknown1          = "Unknown1"; 
   Unknown2          = "Unknown2"; 
   Unknown3          = "Unknown3";
   Unknown4          = "Unknown4";
}

$l1 = ("CurrentBuild,InstallDateString,UpgradeDateString,ProductName," +`
"BuildBranch,UBR,Minutes") -split ",";
$l2 = ("CurrentBuild,ProductId2,ProductId,ProductId3") -split ",";
$l3 = ("CurrentBuild,Unknown1,Unknown2,Unknown3") -split ",";
$l4 = ("CurrentBuild,InstallDateString,UpgradeDateString,ProductName,"+`
"BuildBranch,UBR,Minutes,ProductId2,ProductId,ProductId3,Unknown1,Unknown2,Unknown3") -split ",";
Set-Variable -Name V1RowProps -Scope Global -Value $l4;

function Global:TagIdFromObjDate( $o )
{# Jan 27, 2017, simplified ID excluding Date and including Index of the row
   $v   = $Global:currentView;
   $i   = "{0:D3}{1:X0}" -f $o.Index, [int]$o.CurrentBuild;  
   return "$v$i"; # "VnIIIBBBB" Build# is necessary for Details Window Title 
}
function Global:FormatNumber( [int64]$num )
{
   if ( $num -lt 13071694150 )
   {
      return ("{0,-19} (0x{0:X0})" -f $num);
   }      
   return ("{0,-19} (0x0{0:X0})" -f $num);
} 
function GetBuildTimeZone( $obj )
{
   $build = $obj.CurrentBuild;
   for ( $i = 0; $i -lt $TimeZoneDefs.Length )
   {
      $def = ($TimeZoneDefs[ $i ]) -split "=";
      if ( $def[0] -eq $build ){return $def[1];}
      elseif( $def[0].IndexOf( "-" ) -eq -1 ) {return "";}
      $lr = $def[0] -split "-";
      if ( [int]$lr[0] -gt [int]$build ){return "";}
      if ( [int]$lr[1] -lt [int]$build ){return "";}
      return $def[1];      
   }
}
function DateStringToSeconds( $obj ) 
{
   $utc   = $obj.PSChildName.Replace( "Source OS (Updated on ", "" ).Replace( ")", "" );
   $tz    = GetBuildTimeZone(  $obj );
   $dt    = [datetime]( "$utc" );
   $epoch = ( Get-Date -Year 1970 -Month 1 -Day 1 -Hour 0 -Minute 0 -Second 0 );### CONST
   $dt | % { $Seconds = [math]::truncate( $_.ToUniversalTime().Subtract( $epoch ).TotalSeconds ) };
   if ( $tz -ne "" )
   {
      $s1 = [int]$CurrentTIMEZONESeconds;
      $s2 = [int]$tz;
      $Seconds += ( $s1 - $s2 );
   }
   return $Seconds;
}
<#
---------------------------------------------------------------------------------
This function is called from GetBuildsHistory.js main code to build Black theme
CSS code. All other themes are built by JS code on base of the Black theme CSS
replacing 4 colors used in Black theme css.
---------------------------------------------------------------------------------
#>
function buildCSS( $colors )
{
   $brdr  = "#999";#"#e5e5e5";
   $dark  = $colors[0];# is used as text color, dark background 
   $light = $colors[1];# is used as text color on dark and background for rows
   $body  = $colors[2];# less intensive then light
   $hover = $colors[3];# intermediate between light and dark

   $css = @(
".theme {color:#ffffff; background-color:$dark;}"
"a { background-color:transparent; -webkit-text-decoration-skip: objects; color:$light; }"
".navbtn_content {color: $dark;border: 2px solid $brdr; border-top: none;background-color: $light;}"
".white,.hover-white:hover{color:$dark; background-color:#ffffff;}"
".ContentItem:hover{background:$hover;color:#ffffff;}"
"body,#V1expandtable,#V2expandtable,#V3expandable,#V1tablecontainer,#V2tablecontainer,#V3tablecontainer{background-color:$body;}"  
"#V1tablecontainer,#V2tablecontainer,#V3tablecontainer{background: $light;}"
"#V1expandable,#V2expandable,#V3expandable{color:$dark;}"
".divcell,.colname { float: left; border: 1px solid $brdr; box-sizing: border-box; border-bottom:none;}"
".divcell:hover{background:$hover; color:#ffffff;}"
"#V1footBar{border:1px solid $brdr; box-sizing: border-box; border-bottom:2px solid $brdr;}"
".colname{background:$dark;color:$light;}" 
"#navbtn_*:hover{ color:$light; }"
"#navbtn_edit,#navbtn_edit a,#navbtn_edit:hover{color:gray;background-color:$dark;cursor:default;}"
   );
   $css = $css -join "";
   $css = CodeToString( $css );
   return $css;
}
<#
---------------------------------------------------------------------------------
This function is called from GetBuildsHistory.js main code to set some global
variables used later to generate HTML-code and returns updated input argument
updated with values kept in BuildHead code.
---------------------------------------------------------------------------------
#>
function SetGlobals() 
{
   $Global:RowProps = $V1RowProps;

   [string]$n = ([char]0x0d)+([char]0x0a);
   
   Set-Variable -Name NL  -Scope Global -Value $n;
   Set-Variable -Name FSZ -Scope Global -Value 17;
   Set-Variable -Name px  -Scope Global -Value "px";
}# End-of-function SetGlobals

<#
------------------------------------------------------------------------------
Function builds objects for converting long properties name to short ones in PS
and otherwise in JS. PS converter is $Global:l2s and is used when building 
hidden divs to save some space. JS convers is used when building Details page
html code.
------------------------------------------------------------------------------
#>
function PSArrToJSArr( $arr )
{
   function buildDiv( $obj )
   {
      $l2s = $Global:l2s;
      $p   = $AllProperties;
      $tds = "";
      for ( $i = 0; $i -lt $p.Length; $i++ )
      {
         $q    = $p[$i];
         $v    = $obj.$q;
         if ( "$q" -eq "Description" )
         {
            $v = "%c4;";
         }

         if ( $v -ne $null )
         {
            if ( "InstallDate,InstallTime,UpgradeDate".IndexOf( $q ) -gt -1 )
            {
               $v = FormatNumber( $v );
            }
            if ( $v -is [string] )
            {
               $v = $v.trim();
               $v = $v.Replace( " ", "&n;" );
               if ( $v.IndexOf( "\" ) -gt -1 ){$v=$v.Replace( "\", "\\" );}
            }
            $q = $l2s.$q;
            $tds += "%c1;$q%c2;$v%c3;";
         }
         else
         {
            $q = $l2s.$q;
            $tds += "%c1;$q%c2;%c3;";
         }
      }
      return "%c5;$tds%c6;";
   }
   $Props = $AllProperties;
   [psobject]$l2s = "" | Select $Props; 
   $jsn = @();
   $chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
   for ( $i = 0; $i -lt $Props.Length; $i++ )
   {
      $n = $Props[$i];
      $c = $chars[$i];
      $l2s.$n = "%$c;";
      $jsn += "replace( /%$c;/m,""$n"")"; 
   }

   $Global:l2s = $l2s;

   $c1 = "<tr><td>&nbsp;";                     # "%c1%"
   $c2 = "&nbsp;</td><td class='KB'>&nbsp;";   # "%c2%"
   $c3 = "&nbsp;</td></tr>";                   # "%c3%"
   $c4 = "Microsoft&#174;&nbsp;Windows&#174;&nbsp;Operating&nbsp;System,&nbsp;Retail&nbsp;channel";# "%c4%"
   $c5 = "<div class='h hc'><table><tbody>";   # "%c5%"
   $c6 = "</tbody></table></div>";             # "%c6%"   
   $jsn += "replace( /&n;/gm,""&nbsp;"")";
   $jsn += "replace( /%c1;/gm,""$c1"")";
   $jsn += "replace( /%c2;/gm,""$c2"")";
   $jsn += "replace( /%c3;/gm,""$c3"")";
   $jsn += "replace( /%c4;/gm,""$c4"")";
   $jsn += "replace( /%c5;/gm,""$c5"")";
   $jsn += "replace( /%c6;/gm,""$c6"")";

   $jst = "function s2l(obj){return obj."+( $jsn -join "." )+";}`n";
   $jst += "var DC=[];`n";
   
   for ( $i = 0; $i -lt $arr.Length; $i++ )
   {
      $o    = $arr[$i];
      $id   = "I"+( TagIdFromObjDate( $o ) ).Substring(2);
      $code = buildDiv( $o );
      $jst += "DC[DC.length]=""$code"";`n";
   }

   return $jst;
}
<#
------------------------------------------------------------------------------
Function receives an array of the Builds objects and return HTML-Body code 
which presents objects properties. Header part of the same HTML code is built
by the GetBuildsHistory and written to the disk.
------------------------------------------------------------------------------
#>
function BuldHTML( $arr )
{
   function BuildMainTable( $arr )
   {
      function GetClass( $p )
      {
         $P2C = $Global:P2N;
         return $P2C.$p;
      }       
      function BuildTH( $obj )
      {   
         $tds        = "";
         $lang       = "en";
         $Translate = $Global:Translate;
         $VC         = $Global:currentView; 
         $c1         = "topBar"; 
         $c2         = "footBar"; 
         
         if ( $Global:currentView -eq "V1" )
         {
            $tooltip = "title=""%tooltip%""";
         }
         $RowOpenTag      = "<div class=""mr colname"" id=""$VC$c1"" $tooltip>$NL";
         $CellCloseTag    = $RowCloseTag =  "</div>$N";

         if ( $obj -eq $null )
         {
            $RowOpenTag = $RowOpenTag.Replace( "$VC$c1", "$VC$c2" );
         }
    
         $p = $Global:RowProps;
         $tds = "";
         for ( $i = 0; $i -lt $p.Length; $i++ )
         {
            $CellOpenPattern = "<div class=""colname %pn%"">";
            $q = $p[ $i ];
            $a = GetClass( "$q" );
            $CellOpenTag = $CellOpenPattern.Replace( "%pn%", "$a" );
            if ( $obj -eq $null )
            {
               $cpy = "&copy;&nbsp;sysprg&`#64;live.ru`,&nbsp;liza.shakh&`#64;gmail`.com"+
                       "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+`
                       "This page was generated by GetBuildsHistory.ps1, $version&nbsp"              
               $tds = "<div class=""colname copyr"">&nbsp;$cpy&nbsp;</div>$NL";                      
               break;
            }         
            elseif ( $q -eq "Unknown3" )
            {
               $v1 = "Unknown3";
               $v2 = "Unknown4";
               $v  = "<div style=""float:left;"" onclick=""switchUnknowns();"">&nbsp;$v1&nbsp;</div>"+`
               "<div style=""float:right;"" onclick=""switchUnknowns();"">&nbsp;$v2&nbsp;</div>";
            }             
            else
            {
               $v = $Translate.$q;
            }
            $x1 = "<!--EndOfHeader-->";
            if ( $i -eq 0 ){$x1 = "<!--EndOfFooter-->";}
            $tds += "$CellOpenTag&nbsp;$v&nbsp;$CellCloseTag";
         }
         return "$RowOpenTag$tds$RowCloseTag$x1$NL$BreakLine$NL";      
      }
      function BuildTD( $tobj )
      {
         $CellOpenPattern = "<div class=""divcell %pn%"">";
         $CellCloseTag = "</div>$NL";
         $p = $tobj.PropName;
         $a = GetClass( "$p" );
         $CellOpenTag = $CellOpenPattern.Replace( "%pn%", "$a" ); 
         $v = $tobj.Value.ToString().trim();
         if ( $a -and $a.Contains( "Date" ) )
         {
            if ( $v.Contains( "," ) )
            {
               $v  = $v -split ",";
               $v0 = ($v[0]).trim();
               $v1 = ($v[1]).trim();
               $v  = "$v1&nbsp;&nbsp;&nbsp;$v0";
            }
         }
         elseif ( $p -eq "ProductId3" )
         {
            $p  = $v.IndexOf( " " );
            $v0 = $v.Substring( 0, $p ).trim();
            $v1 = $v.Substring( $p + 1 ).trim();
            $fill = "&nbsp;&nbsp;&nbsp;";
            if ( $v0.Length -lt "55041-01781-051-124375-01-1033-10049.0000-0902015".Length )
            {
               $fill += "&nbsp;&nbsp;";
            }
            $v = "&nbsp;$v0$fill<span>&nbsp;$v1&nbsp;</span>";
         }
         elseif ( $p -eq "Unknown1" -or $p -eq "Unknown2" )# Jan 25, 2017
         {
            $v = "<span class=""fw"">$v</span>";
         }            
         elseif ( $p -eq "Unknown3" )
         {
            $v1 = $v;
            $v2 = ($Global:currentObj).Unknown4;#$fixed
            $v  = "<div>&nbsp;<span class=""fw"">$v1</span>&nbsp;</div>"+`
            "<div>&nbsp;<span class=""fw"">$v2</span>&nbsp;</div>";
         }
         
         return "$CellOpenTag&nbsp;$v&nbsp;$CellCloseTag";
      }
      function BuildRow( $obj )
      { 
         $Global:currentObj = $obj;
         $tds = "";
         $p   = $V1RowProps;
         for ( $i = 0; $i -lt $p.Length; $i++ )
         {
            $q    = $p[ $i ];
            $v    = $obj.$q;
            $tds += BuildTD( @{PropName="$q";Value="$v";} );
         }
         
         $id = TagIdFromObjDate( $obj );# divcell
         return "<div class=""mr divcell"" id=""$id"">$NL$tds</div><!--EndOfMR-->$NL";     
      }
      $V1th1  = BuildTH( $V1RowProps );   
      $V1rows = $arr | %{BuildRow( $_ )};
      $V1th2  = BuildTH( $null );
      $V1vid  = $Global:currentView; 
      $c1 = "tablecontainer"; 
      $c2 = "expandable";
      
      return "<div id=""Main"" class=""Main"">$NL"+`
      "<div id=""$V1vid$c1"">$V1th1<div id=""$V1vid$c2"">"+`
      "$NL$V1rows</div><!--V1Expandable-->$NL"+`
      "$V1th2</div><!--V1tablecontainer-->$NL";
  
   }# End-Of-BuildMainTable( $arr ), central function
   
   function BuildBottomTable
   {
      $sz = $FSZ - 2;
      $comp = "";
      for ( $i = 0; $i -lt $CompInfo.Length; $i++ )
      {
         $lr = $CompInfo[$i] -split ":";
         $l  = $lr[0].trim();
         $r  = $lr[1].trim();
         $comp += "<tr><td>&nbsp;$l&nbsp;</td><td>&nbsp;$r&nbsp;</td></tr>$NL";
      }
      $sz = $FSZ - 2;
      $lcell =  "<table id=""Computer"" style=""font-size:$sz$px;"">$NL$comp</table>";
      $Global:Stamps += TimeStamp( "HTML creation is finished" );
      $stmp = "";
      for ( $i = 0; $i -lt $Global:Stamps.Length; $i++ )
      {
         $v = $Global:Stamps[$i] -Split "]";
         $stmp += "<tr><td>&nbsp;" + $v[0].Substring( 1 ) + "&nbsp;</td>" +`
                   "<td>&nbsp;" + $v[1] + "&nbsp;</td></tr>$NL"
      }
      $rcell = "<table id=""RunStamps"" style=""font-size:$sz$px;"">$stmp</table>"; 
      return "<table><tr><td>$lcell</td><td>$rcell</td></tr></table>";      
   }

   function BuildMenuTop()
   {
      $code = '
<ul class="navbar theme wide" id="MenuContainer">
 <li class="navbarbtns">
  <a class="hover-white padding-8" id="navbtn_file" href="#">FILE&nbsp;
  <span class="caret">6</span></a>
 </li>
 <li class="navbarbtns">
  <a class="hover-white padding-8" id="navbtn_view" href="#">VIEW&nbsp;
   <span class="caret">6</span></a>
 </li>
 <li class="navbarbtns">
  <a class="hover-white padding-8" id="navbtn_theme" href="#">THEME&nbsp;
   <span class="caret">6</span></a>
 </li>
 <li class="navbarbtns">
  <a class="hover-white padding-8" id="navbtn_lang" href="#">LANGUAGE&nbsp;
   <span class="caret">6</span></a>
 </li>
 <li class="navbarbtns" id="IgnoreMe">
  <a class="hover-white padding-8 disabled" id="navbtn_edit" href="#">EDIT&nbsp;
   <span class="caret">6</span></a>
 </li>
 <li class="right" id="About">
  <a class="hover-white padding-8 right" title="%version%" href="#">
   <i>About</i></a>
 </li>
</ul>
<!--<br/>-->
';
      return $code.Replace( "%version%", "$Version" );
   }
   function BuildMenuHidden()
   {
      $ret = '
<div class="navbtn_content" id="navbtn_file_content">
 <div class="ContentItem">&nbsp;SAVE CURRENT SETTINGS&nbsp;</div> 
 <div class="ContentItem">&nbsp;SAVE VIEW AS TEXT FILE&nbsp;</div>
 <div class="ContentItem">&nbsp;EXIT&nbsp;</div>
</div>
<div class="navbtn_content" id="navbtn_view_content">
 <div class="ContentItem">&nbsp;Default&nbsp;</div>
 <div class="ContentItem">&nbsp;Build,ProductId2,ProductId,ProductId3&nbsp;</div>
 <div class="ContentItem">&nbsp;Build,Unkown1,Unkown2,Unkown3,Unknown4&nbsp;</div>
</div>
<div class="navbtn_content" id="navbtn_theme_content">
 <div class="ContentItem" id="Black">&nbsp;BLACK&nbsp;</div>
 <div class="ContentItem" id="Green">&nbsp;GREEN&nbsp;</div>
 <div class="ContentItem" id="Blue">&nbsp;BLUE&nbsp;</div>
 <div class="ContentItem" id="Brown">&nbsp;BROWN&nbsp;</div>
 <div class="ContentItem" id="Orange">&nbsp;ORANGE&nbsp;</div>
 <div class="ContentItem" id="Flowers">&nbsp;FLOWERS&nbsp;</div>
</div>
<div class="navbtn_content" id="navbtn_lang_content">
';
   $arr = $Global:LangMenu;
   for ( $i = 0; $i -lt $arr.length; $i++ )
   {
      $l = $arr[$i];
      $ret += "<div class=""ContentItem"">&nbsp;$l&nbsp;</div>$NL";
   }
   $ret += '
</div>
<div class="navbtn_content" id="navbtn_edit_content">
 <div class="ContentItem" onclick="createDebugWin();">&nbsp;ColorPicker&nbsp;</div>
 <div class="ContentItem" onclick="alert(this.innerText);">&nbsp;Drevoloz&nbsp;</div>
</div>
';
      return $ret;
   }
   $visible   = $Global:DefaultView;
   $Default   = "RoseFlowers"; ### should be defined by INI file !
   $Scheme    = $ColorSchemes.$Default;
   $ColorScheme = "<style id=""ColorScheme"">$Scheme</style>";
   $Visibility = "<style id=""Visibility"">$visible</style>";
   $MainTable = BuildMainTable( $arr );
   $bottom    = BuildBottomTable;
   $Container = "<div id=""MainContainer"">";
   $menuTop   = BuildMenuTop;
   $menuHidd  = BuildMenuHidden;
  
   return "<body>$NL$ColorScheme$NL$Visibility$NL"+`
   "$menuTop$menuHidd<div id=""MainContainer"">$MainTable$bottom</div>$NL"+`
   "<!--MainContainer-->$NL</body></html>";  
}
################### Part parseIniUtils.ps1 #####################################
<#
---------------------------------------------------------------------------- 
 Project: GetBuildsHistory, part parseIniUtils                                               
 Version: 1.0                                                        
 FileId:  e:\Delme\!Projects\BuildsHistory\parseIniUtils.ps1                    
 When:    09 Jan 2017,  Monday,  12:36:11                           
 ©        Oleg Kulikov, sysprg@live.ru                               
---------------------------------------------------------------------------- 
#>

function TestBuildNumber( $build )
{
   $reg1 = "\d{4,5}";#"[0-9]{4,5}";
   if ( ! $build -match $reg1 )
   {
      $INILog += "TIMEZONE definition parser: Incorrect Build number $build";
      return $false;
   }
   if ( [int]$build -lt 7601 )
   {
      $INILog += "TIMEZONE definition parser: Build number .$build. is too small";
      return $false;
   }
   if ( [int]$build -gt 15999 )
   {
      $INILog += "TIMEZONE definition parser: Build number .$build. is too big";
      return $false;
   }
   return $true;
}
# is called from GetBuildsHistory, if ( Test-Path $fn ), line ~ 213
function GetIniSettings()
{
   [byte[]]$enc = get-content -Encoding byte -ReadCount 4 -TotalCount 4 $fn
   $data = @();
   # $config = [io.file]::ReadAllLines($fn)
   $config = Get-Content $fn;
   if ( $enc[0] -ne 35 -or $enc[1] -ne 45 -or $enc[2] -ne 45 -or $enc[3] -ne 45 )
   {
      $config | Set-Content -Encoding "Ascii" $fn;
      $config = Get-Content $fn;
   }
   for( $i = 0; $i -lt $config.Length; $i++ )
   {
      $line = ( $config[$i] -split "`#" )[0];
      if ( $line.Length )
      {
         $data += $line;
      }
   }
   return $data;
}

function ParseTimeZoneDefinition( $d )
{
   # TIMEZONE.7601-10576.IsInsider = +03:00
   $lr   = $d -split "=";
   $zone = ($lr[1]).Replace( "utc", "" ).trim();
   $reg1 = "[+-]\d{1,2}";#"[+-][0-9]{1,2}";
   $reg2 = "$reg1\:[03]0";
   $znh  = ( $zone.Substring( 1 ) -split ":" )[0];
   if ( !  ( $zone -match $reg1 -or `
              $zone -match $reg2 -or `
              $znh -gt 12 ) )
   {
      return "*Incorrect TIMEZONE value $zone";         
   }
   $lr   = ($lr[0]).trim();     
   $def  = $lr -split "\.";
   if ( ! $def -is [system.array] ){return "";}
   if ( $def.Length -lt 2 )
   {
      return "*Incorrect TIMEZONE definition $lr (def.Length<2)";
   }      
   if ( $def.Length -eq 3 )
   {
      if ( "Insider,Stable".IndexOf( $def[ 2 ] ) -eq -1 )
      {
        return "*Only ""Insider, Stable"" are permitted in TIMEZONE definition $lr";
      }
      if ( $def[ 2 ] -eq "Insider"  -and ! $IsInsider )
      {
         return "*Definition is ignored as runnnig Stable system";
      }
      if ( $def[ 2 ] -eq "Stable" -and   $IsInsider )
      {
         return "*Definition is ignored as running Insider system";
      }
   }      
   $region = $def[ 1 ] -split "-"; 
   $t = TestBuildNumber( $region[0] );
   if ( ! $t  ){return "";}
   elseif ( $region.Length -eq 2 )
   {
      $t = TestBuildNumber( $region[1] );
      if( ! $t ){return "*???";}        
      if( [int]$region[1] -lt [int]$region[0] )
      { 
         return "*Incorrect Builds region $region";
      }
   }
   $seconds = ( zone2seconds( $zone ) ).ToString();
   return $def[ 1 ] + "=$seconds";           
}
function BuildJS()
{
   $fn  = "GetBuildsHistory.Langs.txt";
   [string[]]$arr = Get-Content $fn;
   [string[]]$langs = @();
   $js = '
var LangStrings={};
LangStrings.en={};
';
   [string[]]$LangMenu = @();
   $sNames = "LC,NativeName,FileCreated,FileUpdated,Title,Details,Tooltip,ReRunSaveSettings,SaveView,"+`
   "Exit,File,View,Theme,Language,Default,Edit,Flowers,Black,Green,Blue,Brown,Orange";
   $pcl = "";
   for ( $i = 0; $i -lt $arr.Length; $i++ )
   {
      $line = ($arr[$i] -split "`#" )[0].trim();
      if ( ! $line.Length ) {continue;}

      $ll   = $line.ToLower();

      if ( $line.IndexOf( "=" ) -gt -1 )
      {
         $lr = $line -split "=";
         $ls = $lr[0].trim();
         $rs = $lr[1].trim();
      }

      if ( $ll.StartsWith( "[lang-" ) )
      {
         $langdef = "";
         $cl = $ll.Substring( 6, $ll.Length - 7 );
         if ( $cl -and $cl.Length -eq 2 )
         {
            $langs += "`"$cl`"";
            $js += "LangStrings.$cl={};$NL";
            continue;
         }
      }
      elseif ( $sNames.IndexOf( $ls ) -gt -1 )
      {
         if ( $ls -eq "LC" )
         {
            $langdef += "[$rs] ";
         }
         elseif( $ls -eq "NativeName" )
         {
            $langdef += "$rs";
            $langdef = $langdef.Replace( '"', "" );
            if ( $pcl -ne $cl )
            {
               $LangMenu += $langdef;
               $pcl = $cl;
            }
         }
         $js += "LangStrings.$cl.$ls=$rs;$NL";
      }
      elseif ( $ll.StartsWith( "[" ) )
      {
         break;
      }
   }#End-Of-For-loop
   $Global:LangMenu = $LangMenu;
   $allLangs = ( $langs -join "," );
   $js = "var LangsPresent=[$allLangs];$NL$js";
   return $js;
}
################### Part Utils.ps1         #####################################
<#
-------------------------------------------------------------------- 
 Project: Utils                                               
 Version: 1.0                                                        
 FileId:  e:\Delme\!Projects\BuildsHistory\                    
 When:    13 Dec 2016,  Tuesday,  09:53:54                           
 (c)      Oleg Kulikov, sysprg@live.ru                               
-------------------------------------------------------------------- 
 Collection of the project independent small functions.                                                           
--------------------------------------------------------------------
#>
function Global:zone2seconds( $zone )
{
   $parts   = $zone -split ":";
   $hours   = [int]( $parts[0] );
   $seconds = $hours * 3600;
   if ( $parts.Length -eq 2 -and "00" -ne $parts[1] )
   {
      $seconds += 60 * ( [int]( $part[1] ) );
   }
   return $seconds;
}

function Global:FileTimeToString( [int64]$qw )
{
   return ( [datetime]::fromFileTime( $qw ) ).ToString( "ddd, dd.MM.yyyy HH:mm:ss" );
}

<#
---------------------------------------------------------------------------------
Function converts Reg_DWORD DateTime which presents number of the seconds since 
01.01.1970 00:00:00 into QWORD FileTime number. Constant which is used in
calculations is the number of the 100 nanosecond intervals since 01.01.1601 
till 01.01.1970. 
1 second = 1000 milliseconds = 10000 of 100-ns intervals
---------------------------------------------------------------------------------
the UNIX Epoch is January 1st, 1970 at 12:00 AM (midnight) UTC
#>
function Global:RegDWDateToFileTime( [int32]$dw )
{  
   return [int64]( ( 1000 * $dw + 11644473600000 ) * 10000 );
}
function Global:FiletimeToDWDate( [int64]$ft )
{
   return [int32]([math]::truncate( $ft - 116444736000000000 ) / 10000000 );
}
function Global:TicksToFileTime( [int64] $ticks )
{
   return $ticks - 504911376000000000;
}
function Global:TicksToString( [int64]$ticks )
{
   return FileTimeToString( TicksToFileTime( $ticks ) );
}
function Global:TimeStamp( $action )
{
   $dt = (get-date);
   $ms = ($dt.Millisecond).ToString().PadLeft(3,"0");
   $dt = $dt.ToString( "dd.MM.yyyy HH:mm:ss" );
   return "[$dt.$ms] $action";
}
function Global:GetCompInfo
{ 
   function GetRAMSize 
   {
      $q = "select Capacity From Win32_PhysicalMemory";
      $dimms = gwmi -Query $q | select @( "Capacity" );
      $ram = 0;
      $dimms | % { $ram += $_.Capacity };
      $ram = $ram / 1024 / 1024 / 1024;
      return [string]$ram + " GB";
   } 
   # detect current video resolution
   <#   
   $d = (Get-ItemProperty -Path "hklm:\SYSTEM\CurrentControlSet\Enum\DISPLAY\*\1&8713bca&0&UID0").HardwareID
   $d = $d.substring( "MONITOR\".Length );
   $d = (Get-ItemProperty -Path "hklm:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Configuration\$d*\00\00");
   $r = [string]($d."ActiveSize.cx")+"x"+[string]($d."ActiveSize.cy");
   #>
   $d = (gwmi Win32_VideoController).VideoModeDescription -split " X ";
   $r = $d[0] + " x " + $d[1];

   $Comp  = Get-ItemProperty -Path "HKLM:\HARDWARE\DESCRIPTION\System\BIOS"; 
   $stone = Get-ItemProperty -Path "HKLM:\HARDWARE\DESCRIPTION\System\CentralProcessor\0";
   $Disk0 = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Disk\Enum").0;
   $d     = (Get-ItemProperty -Path "hklm:\system\CurrentControlSet\Enum\$disk0").FriendlyName;
   
   [string]$CompID = "";
   if ( $Comp.BaseBoardManufacturer  -ne $null ) { $CompID += $Comp.BaseBoardManufacturer + " "; }
   elseif ( $Comp.SystemManufacturer -ne $null ) { $CompID += $Comp.SystemManufacturer    + " "; }
   if ( $Comp.SystemVersion          -ne $null ) { $CompID += $Comp.SystemVersion         + " "; }
   elseif ( $Comp.SystemFamily       -ne $null ) { $CompID += $Comp.SystemFamily          + " "; }  
   if ( $Comp.SystemProductName      -ne $null ) { $CompID += $Comp.SystemProductName; }
   
   $Platform  = ( $CompID  -replace "\s\s*", " " );
   $Processor = ( $stone.ProcessorNameString.trim() -replace "\s\s*", " " ); 
   $DiskDrive = ( $d  -replace "\s\s*", " " );
   $RAMSize   = GetRAMSize;
   $Monitor   = "$r ( Current resolution )";

   $ML   = "DiskDrive".Length;
   $ret  = @();
   $ret += "{0,-$ML}: {1}" -f "Platform",  $Platform;
   $ret += "{0,-$ML}: {1}" -f "Processor", $Processor;
   $ret += "{0,-$ML}: {1}" -f "DiskDrive", $DiskDrive;
   $ret += "{0,-$ML}: {1}" -f "RAMSize",   $RAMSize;
   $ret += "{0,-$ML}: {1}" -f "Monitor",   $Monitor;
   
   return $ret;
}
function Global:GetRidOfBlanks( [string] $code )
{
   $s = $code -replace '([0-9a-zA-Z"]) ([0-9a-zA-Z"])','$1%%$2';
   $s = $s -replace " `#", "%%#";
   <#
   ----------------------------------------------------------------------
   "margin:           5px 0 9 0px;" => "margin:           5px%%0 9%%0px;"
   Thus following replace is necessary
   ----------------------------------------------------------------------
   #>
   $s = $s    -replace '([0-9])\s([0-9])','$1%%$2'
   return $s -replace "%%"," ";
}
function Global:CodeToString( [string] $code )
{
   $s = $code -replace '([0-9a-zA-Z"]) ([0-9a-zA-Z"])','$1%%$2';
   $s = $s -replace " `#", "%%#";
   <#
   ----------------------------------------------------------------------
   "margin:           5px 0 9 0px;" => "margin:           5px%%0 9%%0px;"
   Thus following replace is necessary
   ----------------------------------------------------------------------
   #>
   $s = $s    -replace '([0-9])\s([0-9])','$1%%$2'
   $s = $s -replace '\s*','';
   return $s -replace "%%"," ";
}
<#--End-of-File-DTConverters------------------------------------------#>

################### Part CreateTextLog.ps1 #####################################  
<#
---------------------------------------------------------------------------- 
 Project: GetBuildsHistory, part CreateTextLog.ps1                                               
 Version: 1.0                                                        
 FileId:  e:\Delme\!Projects\BuildsHistory\GBHColorSchemes.ps1                    
 When:    09 Jan 2017,  Monday,  22:11:09                           
 ©        Oleg Kulikov, sysprg@live.ru                               
---------------------------------------------------------------------------- 
Function: 
receives an array of the builds objects
returns an array of the strings
Former name of this function - Show. It was used in the
archives till December 13, 2016.
-----------------------------------------------------------------------------
#>
function BuildTextLog( $arr )
{
<#
CurrentBuild       : 14986
InstallDateStrin   : Thu, 08.12.2016 14:50:58
Minutes            : 111:08
Description        : Microsoft(R) Windows(R) Operating System, Retail channel
ProductName        : Windows 10 Pro Insider Preview
ProductId          : 00330-80000-00000-AA633
ProductId4         : 00330-80000-00000-AA380
ProductId2         : [TH]X19-98841
BuildLabEx         : 14986.1000.amd64fre.rs_prerelease.161202-1928     (Fri, 02.12.2016)
ProductId3         : 55041-03308-000-000000-00-1033-14986.0000-3432016 (Thu, 08.12.2016)
ProductId5         : 00000-03308-000-000000-00-1033-14393.0000-3372016 (Fri, 02.12.2016)
DefaultProductKey  : VK7JG-NPHTM-C97JM-9MPGT-3V66T
ProductKey         : VK7JG-NPHTM-C97JM-9MPGT-3V66T
EditionID          : Professional
CurrentVersion     : 6.3
ReleaseId          : 1607
UBR                : 1000
LicensingProductID : 4de7cb65-cdf1-4de9-8ae8-e3cce27b9f2c
ApplicationID      : {55c92734-d682-4d71-983e-d6ec3f16059f}
InstallDate        : 1481194258          (0x58493B12)
InstallTime        : 131256678582433859  (0x01D25140F54DB843)
UpgradeDate        : 
PSParentPath       : SOFTWARE\Microsoft\Windows NT
PSChildName        : CurrentVersion
#>
   $ShowProps = $AllProperties;
   $MaxL = "LicensingProductID".Length;
   $Derived = "InstallDateS,InstallTimeS,UpgradeDateS";
   $out = @();              
   for ( $i = 0; $i -lt $arr.Length; $i++ )
   {
      $o = $arr[ $i ];     
    
      for ( $j = 0; $j -lt $ShowProps.Length; $j++ )
      {
         $p = $ShowProps[ $j ];
         $v = $o.$p;

         if ( "InstallDate,InstallTime,UpgradeDate".IndexOf( $p ) -gt -1 )
         {
            if ( $v )
            {
               $v  = FormatNumber( [int64]$v );
            }
         }
         if ( $o.$p -ne $null )
         {
            $out += "{0,-$MaxL} : {1}" -f $p, $v;
         }
      }
      $out += "$NL$NL";
   }
   $out += $CompInfo+"$NL$NL";
   return $out;
}
